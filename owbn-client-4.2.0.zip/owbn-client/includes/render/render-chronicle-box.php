<?php

/**
 * OWBN-Client Chronicle Box Render
 * location: includes/render/render-chronicle-box.php
 * @package OWBN-Client

 */

defined('ABSPATH') || exit;
