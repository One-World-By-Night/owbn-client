<?php

/**
 * OWBNClient Hooks Init
 * 
 * @package OWBNClient

 */

defined('ABSPATH') || exit;

// Hook files will be loaded here
// require_once __DIR__ . '/cache-hooks.php';