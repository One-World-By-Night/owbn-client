/**
 * OWBNClient Scripts
 *
 * @package OWBNClient

 */

// Client-side functionality will go here
