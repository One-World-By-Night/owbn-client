<?php

/**
 * OAT Reports Page
 *
 * Admin-side reporting dashboard. Restricted to:
 *   chronicle/<slug>/hst|cm|staff
 *   coordinator/<slug>/coordinator|sub-coordinator
 *   exec/<slug>/coordinator
 *   exec/archivist/staff
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check if current user has report access via ASC roles.
 *
 * @return bool
 */
function owc_oat_reports_has_access() {
    if ( current_user_can( 'manage_options' ) ) {
        return true;
    }
    if ( ! function_exists( 'owc_oat_get_user_asc_roles' ) ) {
        return false;
    }
    $roles = owc_oat_get_user_asc_roles( get_current_user_id() );
    foreach ( $roles as $role ) {
        if ( preg_match( '#^chronicle/[^/]+/(hst|cm|staff)$#', $role ) ) {
            return true;
        }
        if ( preg_match( '#^coordinator/[^/]+/(coordinator|sub-coordinator)$#', $role ) ) {
            return true;
        }
        if ( preg_match( '#^exec/[^/]+/coordinator$#', $role ) || preg_match( '#^exec/archivist/staff$#i', $role ) ) {
            return true;
        }
    }
    return false;
}

/**
 * Get the user's scoped filters based on their ASC roles.
 *
 * Returns arrays of chronicle slugs and coordinator genres
 * the user has access to. Site admins, exec/archivist/staff and the Archivist, Web, Head Coordinator, AHC1, AHC2,
 * Admin and Membership coordinators see all, as on OAT's Details page.
 *
 * @return array { 'chronicles' => string[], 'genres' => string[], 'is_global' => bool }
 */
function owc_oat_reports_user_scope() {
    if ( current_user_can( 'manage_options' ) ) {
        return array( 'chronicles' => array(), 'genres' => array(), 'is_global' => true );
    }
    $roles      = function_exists( 'owc_oat_get_user_asc_roles' ) ? owc_oat_get_user_asc_roles( get_current_user_id() ) : array();
    $chronicles = array();
    $genres     = array();
    $is_global  = false;

    foreach ( $roles as $role ) {
        if ( preg_match( '#^exec/(archivist|web|head-coordinator|ahc1|ahc2|admin|membership)/coordinator$#i', $role ) || preg_match( '#^exec/archivist/staff$#i', $role ) ) {
            $is_global = true;
            break;
        }
        if ( preg_match( '#^chronicle/([^/]+)/(hst|cm|staff)$#', $role, $m ) ) {
            $chronicles[] = $m[1];
        }
        if ( preg_match( '#^coordinator/([^/]+)/(coordinator|sub-coordinator)$#', $role, $m ) ) {
            $genres[] = $m[1];
        }
        if ( preg_match( '#^exec/([^/]+)/coordinator$#', $role, $m ) ) {
            $genres[] = $m[1];
        }
    }

    return array(
        'chronicles' => array_unique( $chronicles ),
        'genres'     => array_unique( $genres ),
        'is_global'  => $is_global,
        'da_global'  => true, // Binary: any qualifying role sees ALL DAs.
    );
}

/**
 * Returns a chronicle title in "City, ST, US: Name" form. "New York City, NY - USA, Kings of New York" (any dash) becomes "New York City, NY, US: Kings of New York"; "Metarie, LA: Louisiana Revolt" becomes "Metarie, LA, US: Louisiana Revolt" when a country is given; any other title is returned unchanged.
 *
 * @param string $title   Chronicle title as stored.
 * @param string $country Country code from the chronicle's location, used when the title has none.
 * @return string
 */
function owc_oat_chronicle_report_label( $title, $country = '' ) {
    $title = trim( (string) $title );
    if ( preg_match( '/^(.*?)\s+[-–—]\s+([^,]+),\s*(.+)$/u', $title, $m ) ) {
        $place   = rtrim( trim( $m[1] ), ', ' );
        $country = trim( $m[2] );
        if ( 'USA' === $country ) {
            $country = 'US';
        }
        return $place . ', ' . $country . ': ' . trim( $m[3] );
    }
    $country = trim( (string) $country );
    if ( '' !== $country && preg_match( '/^([^:]+,[^:]+):\s*(.+)$/u', $title, $m ) ) {
        return rtrim( trim( $m[1] ), ', ' ) . ', ' . ( 'USA' === $country ? 'US' : $country ) . ': ' . trim( $m[2] );
    }
    return $title;
}

/**
 * Returns every chronicle's report label and lowercase filter text (title, label, region, state and city, slug), keyed by slug.
 *
 * @return array<string,array{known:bool,label:string,search:string}>
 */
function owc_oat_chronicle_report_index() {
    static $index = null;
    if ( null !== $index ) {
        return $index;
    }
    $index = array();
    $list  = function_exists( 'owc_get_chronicles' ) ? owc_get_chronicles() : array();
    if ( is_wp_error( $list ) ) {
        $list = array();
    }
    foreach ( (array) $list as $chronicle ) {
        $chronicle = (array) $chronicle;
        $slug      = isset( $chronicle['slug'] ) ? (string) $chronicle['slug'] : '';
        if ( '' === $slug ) {
            continue;
        }
        $title    = isset( $chronicle['title'] ) ? (string) $chronicle['title'] : $slug;
        $location = isset( $chronicle['ooc_locations'] ) && is_array( $chronicle['ooc_locations'] ) ? $chronicle['ooc_locations'] : array();
        $label    = owc_oat_chronicle_report_label( $title, isset( $location['country'] ) ? (string) $location['country'] : '' );
        $index[ $slug ] = array(
            'known'  => true,
            'label'  => $label,
            'search' => strtolower( implode( ' ', array_filter( array(
                $title,
                $label,
                isset( $chronicle['chronicle_region'] ) ? (string) $chronicle['chronicle_region'] : '',
                isset( $location['region'] ) ? (string) $location['region'] : '',
                isset( $location['city'] ) ? (string) $location['city'] : '',
                $slug,
            ) ) ) ),
        );
    }
    return $index;
}

/**
 * Returns the report label, filter text and whether the chronicle is in the chronicle list, for one chronicle slug: from the index, else from its entity title, else the slug itself.
 *
 * @param string $slug  Chronicle slug.
 * @param array  $index Result of owc_oat_chronicle_report_index().
 * @return array{known:bool,label:string,search:string}
 */
function owc_oat_chronicle_report_meta( $slug, $index ) {
    if ( isset( $index[ $slug ] ) ) {
        return $index[ $slug ];
    }
    if ( '' === (string) $slug ) {
        return array( 'known' => false, 'label' => 'No chronicle recorded', 'search' => 'no chronicle recorded' );
    }
    $title = function_exists( 'owc_entity_get_title' ) ? owc_entity_get_title( 'chronicle', $slug ) : '';
    $label = $title ? owc_oat_chronicle_report_label( $title ) : $slug . ' (not in the chronicle list)';
    return array( 'known' => false, 'label' => $label, 'search' => strtolower( $label . ' ' . $slug ) );
}

/**
 * Returns the Chronicle Reports visible to this scope, newest first, or only the undecided (pending) ones, oldest first.
 *
 * @param array $scope        Result of owc_oat_reports_user_scope().
 * @param array $filters      Report filters; 'chronicle' narrows to one chronicle slug.
 * @param bool  $pending_only True for pending reports only.
 * @return array Rows with id, chronicle_slug, status, current_step, created_at, submitter_name, game_dates, approx_attendance.
 */
function owc_oat_chronicle_report_rows( $scope, $filters, $pending_only ) {
    global $wpdb;
    $prefix = $wpdb->prefix;
    $where  = "e.domain = 'chronicle_actions' AND e.form_slug = 'ca_reporting'";
    if ( empty( $scope['is_global'] ) ) {
        // Own chronicles' reports, plus reports that flagged one of the viewer's Coordinator offices.
        $in_scope = array();
        if ( ! empty( $scope['chronicles'] ) ) {
            $in_scope[] = "e.chronicle_slug IN ('" . implode( "','", array_map( 'esc_sql', $scope['chronicles'] ) ) . "')";
        }
        if ( ! empty( $scope['genres'] ) ) {
            $flags = array();
            foreach ( $scope['genres'] as $office ) {
                $flags[] = $wpdb->prepare( 'm_flag.meta_value LIKE %s', '%' . $wpdb->esc_like( '"' . strtolower( $office ) . '"' ) . '%' );
            }
            $in_scope[] = "EXISTS (SELECT 1 FROM {$prefix}oat_entry_meta m_flag WHERE m_flag.entry_id = e.id AND m_flag.meta_key = 'notify_coordinators' AND (" . implode( ' OR ', $flags ) . '))';
        }
        if ( empty( $in_scope ) ) {
            return array();
        }
        $where .= ' AND (' . implode( ' OR ', $in_scope ) . ')';
    }
    if ( ! empty( $filters['chronicle'] ) ) {
        $where .= $wpdb->prepare( ' AND e.chronicle_slug = %s', $filters['chronicle'] );
    }
    if ( $pending_only ) {
        $where .= " AND e.status = 'pending'";
    }
    $order = $pending_only ? 'ASC' : 'DESC';
    return $wpdb->get_results(
        "SELECT e.id, e.chronicle_slug, e.status, e.current_step, e.created_at,
                m_sub.meta_value   AS submitter_name,
                m_dates.meta_value AS game_dates,
                m_att.meta_value   AS approx_attendance
         FROM {$prefix}oat_entries e
         LEFT JOIN {$prefix}oat_entry_meta m_sub   ON e.id = m_sub.entry_id   AND m_sub.meta_key = 'submitter_name'
         LEFT JOIN {$prefix}oat_entry_meta m_dates ON e.id = m_dates.entry_id AND m_dates.meta_key = 'game_dates'
         LEFT JOIN {$prefix}oat_entry_meta m_att   ON e.id = m_att.entry_id   AND m_att.meta_key = 'approx_attendance'
         WHERE {$where}
         ORDER BY e.created_at {$order}, e.id {$order}"
    );
}

/**
 * Returns a report's submitted date as text.
 *
 * @param int|string $created_at Unix timestamp.
 * @return string
 */
function owc_oat_chronicle_report_date( $created_at ) {
    if ( ! $created_at ) {
        return '—';
    }
    return function_exists( 'owc_oat_format_date' ) ? owc_oat_format_date( $created_at ) : gmdate( 'Y-m-d', (int) $created_at );
}

/**
 * Returns a report's workflow state as a label and colour: approved, denied, awaiting archivist, or sent back to the submitter.
 *
 * @param object $row Report row with status and current_step.
 * @return array{label:string,color:string}
 */
function owc_oat_chronicle_report_state( $row ) {
    if ( 'approved' === $row->status ) {
        return array( 'label' => 'Approved', 'color' => '#00a32a' );
    }
    if ( 'denied' === $row->status ) {
        return array( 'label' => 'Denied', 'color' => '#d63638' );
    }
    if ( 'pending' === $row->status ) {
        if ( 'submit' === $row->current_step ) {
            return array( 'label' => 'Sent back to submitter', 'color' => '#b26200' );
        }
        return array( 'label' => 'Awaiting archivist', 'color' => '#b26200' );
    }
    return array( 'label' => ucfirst( (string) ( $row->status ?: 'unknown' ) ), 'color' => '#666' );
}

/**
 * Render the OAT Reports page.
 */
function owc_oat_page_reports() {
    if ( ! owc_oat_reports_has_access() ) {
        echo '<div class="wrap"><h1>OAT Reports</h1><p>You do not have permission to view reports.</p></div>';
        return;
    }

    $scope   = owc_oat_reports_user_scope();
    $report  = isset( $_GET['report'] ) ? sanitize_text_field( $_GET['report'] ) : 'entries_by_domain';
    $filters = array(
        'chronicle' => isset( $_GET['chronicle'] ) ? sanitize_text_field( $_GET['chronicle'] ) : '',
        'genre'     => isset( $_GET['genre'] ) ? sanitize_text_field( $_GET['genre'] ) : '',
        'status'    => isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '',
        'domain'    => isset( $_GET['domain'] ) ? sanitize_text_field( $_GET['domain'] ) : '',
        'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( $_GET['date_from'] ) : '',
        'date_to'   => isset( $_GET['date_to'] ) ? sanitize_text_field( $_GET['date_to'] ) : '',
    );

    $reports = array(
        'chronicle_reports'       => 'Chronicle Reports',
        'chronicle_reports_pending' => 'Pending Reports',
        'entries_by_domain'       => 'Entries by Domain',
        'entries_by_status'       => 'Entries by Status',
        'entries_by_coordinator'  => 'Entries by Coordinator',
        'custom_content_by_type'  => 'Custom Content by Type',
        'disciplinary_actions'    => 'Disciplinary Actions',
        'da_by_level'             => 'DA by Level',
        'recent_activity'         => 'Recent Activity',
    );

    ?>
    <div class="wrap">
        <h1>OAT Reports</h1>

        <nav class="nav-tab-wrapper">
            <?php foreach ( $reports as $key => $label ) :
                $url    = admin_url( 'admin.php?page=owc-oat-reports&report=' . $key );
                $active = ( $key === $report ) ? ' nav-tab-active' : '';
            ?>
                <a href="<?php echo esc_url( $url ); ?>" class="nav-tab<?php echo $active; ?>">
                    <?php echo esc_html( $label ); ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <?php
        $show_all     = ! empty( $_GET['show_all'] );
        $can_show_all = ! $scope['is_global'] && ! empty( $scope['genres'] );
        if ( $can_show_all ) :
            $base = admin_url( 'admin.php?page=owc-oat-reports&report=' . urlencode( $report ) );
            foreach ( $filters as $fk => $fv ) {
                if ( '' !== $fv ) {
                    $base .= '&' . $fk . '=' . urlencode( $fv );
                }
            }
            $toggle_url = $base . ( $show_all ? '' : '&show_all=1' );
        ?>
            <div style="background:#fcf9e8;border:1px solid #dba617;border-radius:4px;padding:8px 14px;margin:12px 0;">
                <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;margin:0;">
                    <input type="checkbox" <?php echo $show_all ? 'checked' : ''; ?> onclick="window.location.href='<?php echo esc_js( $toggle_url ); ?>';return false;">
                    <strong>Show All</strong>
                    <span style="color:#646970;">— include R&U items owned by other coordinators on characters you can see</span>
                </label>
            </div>
        <?php endif; ?>

        <div style="margin-top:15px;">
            <?php owc_oat_render_report( $report, $filters, $scope ); ?>
        </div>
    </div>
    <?php
}

/**
 * Render a specific report.
 */
function owc_oat_render_report( $report, $filters, $scope ) {
    global $wpdb;
    $prefix = $wpdb->prefix;

    // Free-text search term — applied server-side (before pagination) so it
    // matches across ALL rows/pages, not just the currently visible page.
    $q = isset( $_GET['q'] ) ? trim( sanitize_text_field( wp_unslash( $_GET['q'] ) ) ) : '';

    // Build scope WHERE clause for characters.
    $char_scope = '';
    if ( ! $scope['is_global'] ) {
        $conditions = array();
        if ( ! empty( $scope['chronicles'] ) ) {
            $slugs = implode( "','", array_map( 'esc_sql', $scope['chronicles'] ) );
            $conditions[] = "c.chronicle_slug IN ('{$slugs}')";
        }
        if ( ! empty( $scope['genres'] ) ) {
            $slugs = implode( "','", array_map( 'esc_sql', $scope['genres'] ) );
            $conditions[] = "LOWER(c.creature_type) IN ('{$slugs}')";
        }
        $char_scope = ! empty( $conditions ) ? ' AND (' . implode( ' OR ', $conditions ) . ')' : ' AND 1=0';
    }

    // Build scope WHERE for entries.
    $entry_scope = '';
    if ( ! $scope['is_global'] ) {
        $conditions = array();
        if ( ! empty( $scope['chronicles'] ) ) {
            $slugs = implode( "','", array_map( 'esc_sql', $scope['chronicles'] ) );
            $conditions[] = "e.chronicle_slug IN ('{$slugs}')";
        }
        if ( ! empty( $scope['genres'] ) ) {
            $slugs    = implode( "','", array_map( 'esc_sql', array_map( 'strtolower', $scope['genres'] ) ) );
            $ec       = $prefix . 'oat_entry_coordinators';
            $ra       = $prefix . 'oat_registry_access';
            $now      = time();
            $show_all = ! empty( $_GET['show_all'] );
            if ( $show_all ) {
                // Show All: any entry on a character this coordinator office can see (via grants).
                $conditions[] = "e.character_id IN (SELECT character_id FROM {$ra} WHERE grant_type='coordinator' AND LOWER(grant_value) IN ('{$slugs}') AND (starts_at IS NULL OR starts_at <= {$now}) AND (expires_at IS NULL OR expires_at >= {$now}))";
            } else {
                // Owned only: the entry's controlling-authority set includes this office.
                $conditions[] = "EXISTS (SELECT 1 FROM {$ec} ec WHERE ec.entry_id = e.id AND ec.coordinator_slug IN ('{$slugs}'))";
            }
        }
        $entry_scope = ! empty( $conditions ) ? ' AND (' . implode( ' OR ', $conditions ) . ')' : ' AND 1=0';
    }

    // DA visibility is binary: any qualifying role sees ALL DAs.
    $da_entry_scope = ! empty( $scope['da_global'] ) ? '' : $entry_scope;

    // Optional filters.
    $f_chronicle = '';
    if ( $filters['chronicle'] ) {
        $f_chronicle = $wpdb->prepare( ' AND c.chronicle_slug = %s', $filters['chronicle'] );
    }
    $f_entry_chronicle = '';
    if ( $filters['chronicle'] ) {
        $f_entry_chronicle = $wpdb->prepare( ' AND e.chronicle_slug = %s', $filters['chronicle'] );
    }

    echo '<div style="padding:0;">';

    switch ( $report ) {

        case 'chronicle_reports':
            echo '<h2>Chronicle Reports</h2>';
            echo '<p style="color:#666;font-size:13px;">Click a chronicle to see its reports, newest first. Type in the box to narrow the list, e.g. a chronicle name, city, state or region.</p>';
            $cr_rows = owc_oat_chronicle_report_rows( $scope, $filters, false );
            if ( empty( $cr_rows ) ) {
                echo '<p>No chronicle reports found for your chronicle(s).</p>';
                break;
            }
            $index  = owc_oat_chronicle_report_index();
            $groups = array();
            foreach ( $cr_rows as $r ) {
                $groups[ (string) $r->chronicle_slug ][] = $r;
            }
            $ordered = array();
            foreach ( $groups as $slug => $reports_for ) {
                $ordered[] = array( 'slug' => $slug, 'meta' => owc_oat_chronicle_report_meta( $slug, $index ), 'rows' => $reports_for );
            }
            usort( $ordered, function ( $a, $b ) {
                if ( $a['meta']['known'] !== $b['meta']['known'] ) {
                    return $a['meta']['known'] ? -1 : 1;
                }
                return strnatcasecmp( $a['meta']['label'], $b['meta']['label'] );
            } );
            $open_all = '' !== $filters['chronicle'];
            echo '<p><input type="search" id="oat-cr-filter" placeholder="Filter chronicles…" style="width:320px;max-width:100%;" autocomplete="off"> ';
            echo '<span id="oat-cr-count" style="color:#666;">' . esc_html( sprintf( '%d chronicles', count( $ordered ) ) ) . '</span></p>';
            echo '<div id="oat-cr-list">';
            foreach ( $ordered as $g ) {
                $pending = 0;
                foreach ( $g['rows'] as $r ) {
                    if ( 'pending' === $r->status ) {
                        $pending++;
                    }
                }
                $latest = owc_oat_chronicle_report_date( $g['rows'][0]->created_at );
                echo '<details class="oat-cr-chronicle" data-search="' . esc_attr( $g['meta']['search'] ) . '" style="border:1px solid #dcdcde;border-radius:4px;margin:0 0 6px;background:#fff;"' . ( $open_all ? ' open' : '' ) . '>';
                echo '<summary style="cursor:pointer;padding:8px 12px;"><strong>' . esc_html( $g['meta']['label'] ) . '</strong>';
                echo ' <span style="color:#666;">— ' . esc_html( sprintf( _n( '%d report', '%d reports', count( $g['rows'] ), 'owbn-archivist' ), count( $g['rows'] ) ) ) . ', latest ' . esc_html( $latest ) . '</span>';
                if ( $pending ) {
                    echo ' <span style="color:#b26200;font-weight:600;">· ' . esc_html( sprintf( '%d pending', $pending ) ) . '</span>';
                }
                echo '</summary>';
                echo '<table class="widefat striped" style="border:0;border-top:1px solid #dcdcde;"><thead><tr><th>Submitted</th><th>Submitted By</th><th>Games Played</th><th style="text-align:right;">Avg Att</th><th>Status</th></tr></thead><tbody>';
                foreach ( $g['rows'] as $r ) {
                    $dates = wp_strip_all_tags( preg_replace( '#<br\s*/?>#i', ', ', (string) $r->game_dates ) );
                    $dates = trim( preg_replace( '/(\\\\n|\R)+/', ', ', $dates ), ', ' );
                    if ( strlen( $dates ) > 60 ) {
                        $dates = substr( $dates, 0, 57 ) . '…';
                    }
                    $state = owc_oat_chronicle_report_state( $r );
                    echo '<tr>';
                    echo '<td><a href="' . esc_url( admin_url( 'admin.php?page=owc-oat-entry&entry_id=' . (int) $r->id ) ) . '">' . esc_html( owc_oat_chronicle_report_date( $r->created_at ) ) . '</a></td>';
                    echo '<td>' . esc_html( $r->submitter_name ?: '—' ) . '</td>';
                    echo '<td>' . esc_html( $dates ?: '—' ) . '</td>';
                    echo '<td style="text-align:right;">' . esc_html( ( null !== $r->approx_attendance && '' !== $r->approx_attendance ) ? $r->approx_attendance : '—' ) . '</td>';
                    echo '<td><span style="color:' . esc_attr( $state['color'] ) . ';font-weight:600;">' . esc_html( $state['label'] ) . '</span></td>';
                    echo '</tr>';
                }
                echo '</tbody></table></details>';
            }
            echo '</div>';
            echo '<p id="oat-cr-none" style="display:none;">No chronicles match that filter.</p>';
            ?>
            <script>
            (function () {
                var input = document.getElementById('oat-cr-filter');
                var items = document.querySelectorAll('#oat-cr-list .oat-cr-chronicle');
                var count = document.getElementById('oat-cr-count');
                var none = document.getElementById('oat-cr-none');
                input.addEventListener('input', function () {
                    var words = input.value.toLowerCase().split(/\s+/).filter(Boolean);
                    var shown = 0;
                    items.forEach(function (el) {
                        var text = el.getAttribute('data-search');
                        var match = words.every(function (w) { return text.indexOf(w) !== -1; });
                        el.style.display = match ? '' : 'none';
                        if (match) { shown++; }
                    });
                    count.textContent = shown + (shown === 1 ? ' chronicle' : ' chronicles');
                    none.style.display = shown ? 'none' : '';
                });
            })();
            </script>
            <?php
            break;

        case 'chronicle_reports_pending':
            echo '<h2>Pending Reports</h2>';
            echo '<p style="color:#666;font-size:13px;">Chronicle Reports not yet approved or denied, oldest first.</p>';
            $pending_rows = owc_oat_chronicle_report_rows( $scope, $filters, true );
            if ( empty( $pending_rows ) ) {
                echo '<p>No pending chronicle reports.</p>';
                break;
            }
            $index = owc_oat_chronicle_report_index();
            echo '<table class="widefat striped"><thead><tr><th>Chronicle</th><th>Report Date</th><th>Status</th><th>Submitted By</th></tr></thead><tbody>';
            foreach ( $pending_rows as $r ) {
                $meta  = owc_oat_chronicle_report_meta( (string) $r->chronicle_slug, $index );
                $state = owc_oat_chronicle_report_state( $r );
                echo '<tr>';
                echo '<td><a href="' . esc_url( admin_url( 'admin.php?page=owc-oat-entry&entry_id=' . (int) $r->id ) ) . '">' . esc_html( $meta['label'] ) . '</a></td>';
                echo '<td>' . esc_html( owc_oat_chronicle_report_date( $r->created_at ) ) . '</td>';
                echo '<td><span style="color:' . esc_attr( $state['color'] ) . ';font-weight:600;">' . esc_html( $state['label'] ) . '</span></td>';
                echo '<td>' . esc_html( $r->submitter_name ?: '—' ) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '<p style="color:#666;margin-top:8px;">' . esc_html( sprintf( '%d pending', count( $pending_rows ) ) ) . '</p>';
            break;

        case 'ru_active':
            echo '<h2>R&U Active</h2>';
            echo '<p style="color:#666;font-size:13px;">Active approved character_lifecycle entries grouped by R&U classification, split by PC/NPC.</p>';
            // R&U data lives in item_description meta on approved character_lifecycle entries.
            // Group by the item_description (which is the R&U classification text) and pc_npc.
            $page    = isset( $_GET['rpg'] ) ? max( 0, (int) $_GET['rpg'] ) : 0;
            $per     = 50;
            $offset  = $page * $per;
            $f_genre = '';
            if ( $filters['genre'] ) {
                $f_genre = $wpdb->prepare( ' AND e.coordinator_genre = %s', $filters['genre'] );
            }
            $ru_search = $q !== '' ? $wpdb->prepare( " AND m.meta_value LIKE %s", '%' . $wpdb->esc_like( $q ) . '%' ) : '';
            $total_rows = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM (
                    SELECT m.meta_value, c.pc_npc
                    FROM {$prefix}oat_entries e
                    JOIN {$prefix}oat_entry_meta m ON e.id = m.entry_id AND m.meta_key = 'item_description' AND m.meta_value != ''
                    LEFT JOIN {$prefix}oat_characters c ON e.character_id = c.id
                    WHERE e.domain = 'character_lifecycle' AND e.status = 'approved' {$entry_scope} {$f_genre} {$ru_search}
                    GROUP BY m.meta_value, IFNULL(c.pc_npc, 'pc')
                ) sub"
            );
            $rows = $wpdb->get_results(
                "SELECT m.meta_value as classification, IFNULL(c.pc_npc, 'pc') as pc_npc, COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 JOIN {$prefix}oat_entry_meta m ON e.id = m.entry_id AND m.meta_key = 'item_description' AND m.meta_value != ''
                 LEFT JOIN {$prefix}oat_characters c ON e.character_id = c.id
                 WHERE e.domain = 'character_lifecycle' AND e.status = 'approved' {$entry_scope} {$f_genre} {$ru_search}
                 GROUP BY m.meta_value, IFNULL(c.pc_npc, 'pc')
                 ORDER BY m.meta_value ASC, pc_npc ASC
                 LIMIT {$per} OFFSET {$offset}"
            );
            echo owc_oat_report_search_form( 'ru_active', $filters, $q, 'oat-rpt-ru' );
            if ( empty( $rows ) ) {
                echo '<p>' . esc_html( $q !== '' ? 'No R&U classifications match your search.' : 'No R&U data found.' ) . '</p>';
            } else {
                echo '<table id="oat-rpt-ru" class="widefat striped oat-rpt-table"><thead><tr>';
                echo '<th data-col="0" style="cursor:pointer;">R&U Classification <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th data-col="1" style="text-align:right;cursor:pointer;">Total <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th data-col="2" style="cursor:pointer;">PC or NPC <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '</tr></thead><tbody>';
                foreach ( $rows as $r ) {
                    echo '<tr>';
                    echo '<td>' . esc_html( $r->classification ) . '</td>';
                    echo '<td style="text-align:right;">' . number_format( $r->cnt ) . '</td>';
                    echo '<td>' . esc_html( strtoupper( $r->pc_npc ) ) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                $base = admin_url( 'admin.php?page=owc-oat-reports&report=ru_active' );
                if ( $filters['genre'] ) {
                    $base .= '&genre=' . urlencode( $filters['genre'] );
                }
                if ( $q !== '' ) { $base .= '&q=' . urlencode( $q ); }
                owc_oat_render_pagination( $total_rows, $per, $page, $base );
            }
            break;

        case 'ru_by_classification':
            echo '<h2>R&U by Classification (Summary)</h2>';
            echo '<p style="color:#666;font-size:13px;">Top-level R&U classification categories with total counts.</p>';
            // Extract the part before the first colon as the category.
            $rows = $wpdb->get_results(
                "SELECT
                    CASE
                        WHEN m.meta_value LIKE 'Custom %' THEN 'Custom Content'
                        WHEN m.meta_value LIKE '%:%' THEN TRIM(SUBSTRING_INDEX(m.meta_value, ':', 1))
                        ELSE m.meta_value
                    END as category,
                    COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 JOIN {$prefix}oat_entry_meta m ON e.id = m.entry_id AND m.meta_key = 'item_description' AND m.meta_value != ''
                 WHERE e.domain = 'character_lifecycle' AND e.status = 'approved' {$entry_scope}
                 GROUP BY category
                 ORDER BY cnt DESC"
            );
            owc_oat_report_table( array( 'Classification', 'Count' ), $rows, function( $r ) {
                return array( $r->category, number_format( $r->cnt ) );
            } );
            $total = array_sum( wp_list_pluck( $rows, 'cnt' ) );
            echo '<p style="color:#666;margin-top:8px;"><strong>Total: ' . number_format( $total ) . '</strong></p>';
            break;

        case 'characters_by_status':
            echo '<h2>Characters by Status</h2>';
            $rows = $wpdb->get_results(
                "SELECT c.status, COUNT(*) as cnt
                 FROM {$prefix}oat_characters c
                 WHERE 1=1 {$char_scope} {$f_chronicle}
                 GROUP BY c.status ORDER BY cnt DESC"
            );
            owc_oat_report_table( array( 'Status', 'Count' ), $rows, function( $r ) {
                return array( ucfirst( $r->status ?: 'unknown' ), number_format( $r->cnt ) );
            } );
            $total = array_sum( wp_list_pluck( $rows, 'cnt' ) );
            echo '<p style="color:#666;margin-top:8px;"><strong>Total: ' . number_format( $total ) . '</strong></p>';
            break;

        case 'characters_by_chronicle':
            echo '<h2>Characters by Chronicle</h2>';
            $rows = $wpdb->get_results(
                "SELECT c.chronicle_slug, c.status, COUNT(*) as cnt
                 FROM {$prefix}oat_characters c
                 WHERE c.chronicle_slug != '' {$char_scope}
                 GROUP BY c.chronicle_slug, c.status
                 ORDER BY c.chronicle_slug, c.status"
            );
            // Pivot: chronicle → status → count.
            $pivoted = array();
            $statuses = array();
            foreach ( $rows as $r ) {
                $pivoted[ $r->chronicle_slug ][ $r->status ] = (int) $r->cnt;
                $statuses[ $r->status ] = true;
            }
            $status_keys = array_keys( $statuses );
            sort( $status_keys );
            $headers = array_merge( array( 'Chronicle' ), array_map( 'ucfirst', $status_keys ), array( 'Total' ) );
            echo '<table class="widefat striped"><thead><tr>';
            foreach ( $headers as $i => $h ) {
                $align = ( $i > 0 ) ? ' style="text-align:right;"' : '';
                echo '<th' . $align . '>' . esc_html( $h ) . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ( $pivoted as $slug => $counts ) {
                $title = function_exists( 'owc_entity_get_title' ) ? owc_entity_get_title( 'chronicle', $slug ) : $slug;
                echo '<tr><td>' . esc_html( $title ?: $slug ) . '</td>';
                $row_total = 0;
                foreach ( $status_keys as $s ) {
                    $v = isset( $counts[ $s ] ) ? $counts[ $s ] : 0;
                    $row_total += $v;
                    echo '<td style="text-align:right;">' . number_format( $v ) . '</td>';
                }
                echo '<td style="text-align:right;font-weight:bold;">' . number_format( $row_total ) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            break;

        case 'characters_by_creature':
            echo '<h2>Characters by Creature Type</h2>';
            $rows = $wpdb->get_results(
                "SELECT IFNULL(NULLIF(c.creature_type,''), 'Unknown') as creature, COUNT(*) as cnt
                 FROM {$prefix}oat_characters c
                 WHERE 1=1 {$char_scope} {$f_chronicle}
                 GROUP BY creature ORDER BY cnt DESC"
            );
            owc_oat_report_table( array( 'Creature Type', 'Count' ), $rows, function( $r ) {
                return array( $r->creature, number_format( $r->cnt ) );
            } );
            break;

        case 'entries_by_domain':
            echo '<h2>Entries by Domain</h2>';
            $rows = $wpdb->get_results(
                "SELECT e.domain, e.status, COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 WHERE 1=1 {$entry_scope} {$f_entry_chronicle}
                 GROUP BY e.domain, e.status ORDER BY e.domain, e.status"
            );
            $pivoted = array();
            $statuses = array();
            foreach ( $rows as $r ) {
                $pivoted[ $r->domain ][ $r->status ] = (int) $r->cnt;
                $statuses[ $r->status ] = true;
            }
            $status_keys = array_keys( $statuses );
            sort( $status_keys );
            $headers = array_merge( array( 'Domain' ), array_map( 'ucfirst', $status_keys ), array( 'Total' ) );
            echo '<table class="widefat striped"><thead><tr>';
            foreach ( $headers as $i => $h ) {
                $align = ( $i > 0 ) ? ' style="text-align:right;"' : '';
                echo '<th' . $align . '>' . esc_html( $h ) . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ( $pivoted as $dom => $counts ) {
                $label = class_exists( 'OAT_Domain_Registry' ) ? OAT_Domain_Registry::get_label( $dom ) : $dom;
                echo '<tr><td>' . esc_html( $label ?: ucfirst( str_replace( '_', ' ', $dom ) ) ) . '</td>';
                $row_total = 0;
                foreach ( $status_keys as $s ) {
                    $v = isset( $counts[ $s ] ) ? $counts[ $s ] : 0;
                    $row_total += $v;
                    echo '<td style="text-align:right;">' . number_format( $v ) . '</td>';
                }
                echo '<td style="text-align:right;font-weight:bold;">' . number_format( $row_total ) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            break;

        case 'entries_by_status':
            echo '<h2>Entries by Status</h2>';
            $rows = $wpdb->get_results(
                "SELECT e.status, COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 WHERE 1=1 {$entry_scope} {$f_entry_chronicle}
                 GROUP BY e.status ORDER BY cnt DESC"
            );
            owc_oat_report_table( array( 'Status', 'Count' ), $rows, function( $r ) {
                return array( ucfirst( str_replace( '_', ' ', $r->status ) ), number_format( $r->cnt ) );
            } );
            $total = array_sum( wp_list_pluck( $rows, 'cnt' ) );
            echo '<p style="color:#666;margin-top:8px;"><strong>Total: ' . number_format( $total ) . '</strong></p>';
            break;

        case 'entries_by_coordinator':
            echo '<h2>Entries by Coordinator</h2>';
            $rows = $wpdb->get_results(
                "SELECT IFNULL(NULLIF(e.coordinator_genre,''), 'Unassigned') as coord, COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 WHERE 1=1 {$entry_scope} {$f_entry_chronicle}
                 GROUP BY coord ORDER BY cnt DESC"
            );
            owc_oat_report_table( array( 'Coordinator', 'Count' ), $rows, function( $r ) {
                $title = ( $r->coord !== 'Unassigned' && function_exists( 'owc_entity_get_title' ) )
                    ? owc_entity_get_title( 'coordinator', $r->coord )
                    : $r->coord;
                return array( $title ?: ucfirst( $r->coord ), number_format( $r->cnt ) );
            } );
            break;

        case 'custom_content_by_type':
            echo '<h2>Custom Content by Type</h2>';
            $rows = $wpdb->get_results(
                "SELECT m.meta_value as content_type, COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 JOIN {$prefix}oat_entry_meta m ON e.id = m.entry_id AND m.meta_key = 'content_type'
                 WHERE e.domain = 'custom_content' {$entry_scope}
                 GROUP BY m.meta_value ORDER BY cnt DESC"
            );
            owc_oat_report_table( array( 'Content Type', 'Count' ), $rows, function( $r ) {
                return array( $r->content_type ?: '(none)', number_format( $r->cnt ) );
            } );
            $total = array_sum( wp_list_pluck( $rows, 'cnt' ) );
            echo '<p style="color:#666;margin-top:8px;"><strong>Total: ' . number_format( $total ) . '</strong></p>';
            break;

        case 'disciplinary_actions':
            echo '<h2>Disciplinary Actions</h2>';
            $page    = isset( $_GET['rpg'] ) ? max( 0, (int) $_GET['rpg'] ) : 0;
            $per     = 50;
            $offset  = $page * $per;
            $f_status = '';
            if ( $filters['status'] ) {
                $f_status = $wpdb->prepare( " AND m_status.meta_value = %s", $filters['status'] );
            }
            // Server-side search across ALL rows (recipient, chronicle, details).
            $da_search = '';
            if ( $q !== '' ) {
                $like = '%' . $wpdb->esc_like( $q ) . '%';
                $da_search = $wpdb->prepare( " AND ( m_name.meta_value LIKE %s OR e.chronicle_slug LIKE %s OR m_details.meta_value LIKE %s )", $like, $like, $like );
            }
            $total_rows = (int) $wpdb->get_var(
                "SELECT COUNT(DISTINCT e.id)
                 FROM {$prefix}oat_entries e
                 LEFT JOIN {$prefix}oat_entry_meta m_status  ON e.id = m_status.entry_id  AND m_status.meta_key = 'da_status'
                 LEFT JOIN {$prefix}oat_entry_meta m_name    ON e.id = m_name.entry_id    AND m_name.meta_key = 'player_name'
                 LEFT JOIN {$prefix}oat_entry_meta m_details ON e.id = m_details.entry_id AND m_details.meta_key = 'da_details'
                 WHERE e.domain = 'disciplinary_actions' {$da_entry_scope} {$f_entry_chronicle} {$f_status} {$da_search}"
            );
            $rows = $wpdb->get_results(
                "SELECT e.id, e.chronicle_slug, e.created_at, e.form_slug,
                    m_name.meta_value as player_name,
                    m_level.meta_value as da_level,
                    m_action.meta_value as da_action,
                    m_details.meta_value as da_details,
                    m_date.meta_value as da_date,
                    m_type.meta_value as da_type,
                    IFNULL(m_status.meta_value, 'active') as da_status
                 FROM {$prefix}oat_entries e
                 LEFT JOIN {$prefix}oat_entry_meta m_name ON e.id = m_name.entry_id AND m_name.meta_key = 'player_name'
                 LEFT JOIN {$prefix}oat_entry_meta m_level ON e.id = m_level.entry_id AND m_level.meta_key = 'da_level'
                 LEFT JOIN {$prefix}oat_entry_meta m_action ON e.id = m_action.entry_id AND m_action.meta_key = 'da_action'
                 LEFT JOIN {$prefix}oat_entry_meta m_details ON e.id = m_details.entry_id AND m_details.meta_key = 'da_details'
                 LEFT JOIN {$prefix}oat_entry_meta m_date ON e.id = m_date.entry_id AND m_date.meta_key = 'da_date'
                 LEFT JOIN {$prefix}oat_entry_meta m_type ON e.id = m_type.entry_id AND m_type.meta_key = 'da_type'
                 LEFT JOIN {$prefix}oat_entry_meta m_status ON e.id = m_status.entry_id AND m_status.meta_key = 'da_status'
                 WHERE e.domain = 'disciplinary_actions' {$da_entry_scope} {$f_entry_chronicle} {$f_status} {$da_search}
                 ORDER BY m_name.meta_value ASC, m_date.meta_value DESC
                 LIMIT {$per} OFFSET {$offset}"
            );
            // Level label map.
            $level_labels = array(
                'chronicle_ban' => 'Chronicle Ban', 'chronicle_strike' => 'Chronicle Strike',
                'chronicle_probation' => 'Chronicle Probation', 'temporary_suspension' => 'Temporary Suspension',
                'warning' => 'Warning', 'loss_of_xp' => 'Loss of XP',
                'gnc_of_character' => 'GNC of Character', 'removal_from_staff' => 'Removal from Staff',
                'owbn_strike' => 'OWBN Strike', 'owbn_censure' => 'OWBN Censure',
                'owbn_condemnation' => 'OWBN Condemnation', 'owbn_warning' => 'OWBN Warning',
                'owbn_temporary_ban' => 'OWBN Temporary Ban', 'owbn_indefinite_ban' => 'OWBN Indefinite Ban',
                'owbn_permanent_ban' => 'OWBN Permanent Ban', 'other' => 'Other',
            );
            echo owc_oat_report_search_form( 'disciplinary_actions', $filters, $q, 'oat-rpt-da' );
            if ( empty( $rows ) ) {
                echo '<p>' . esc_html( $q !== '' ? 'No disciplinary actions match your search.' : 'No disciplinary action records found.' ) . '</p>';
            } else {
                echo '<table id="oat-rpt-da" class="widefat striped oat-rpt-table"><thead><tr>';
                echo '<th data-col="0" style="cursor:pointer;">Recipient <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th data-col="1" style="cursor:pointer;">Chronicle <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th data-col="2" style="cursor:pointer;">Date <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th data-col="3" style="cursor:pointer;">Level <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th data-col="4" style="cursor:pointer;">Status <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
                echo '<th>Details</th>';
                echo '</tr></thead><tbody>';
                foreach ( $rows as $r ) {
                    $chron_title = $r->chronicle_slug
                        ? ( function_exists( 'owc_entity_get_title' ) ? owc_entity_get_title( 'chronicle', $r->chronicle_slug ) : $r->chronicle_slug )
                        : 'OWBN-Wide';
                    if ( 'da_global' === $r->form_slug && $r->da_action ) {
                        // Global DAs record their level in the Action taken dropdown.
                        $level_lbl = $r->da_action;
                    } elseif ( $r->da_level ) {
                        $level_lbl = isset( $level_labels[ $r->da_level ] ) ? $level_labels[ $r->da_level ] : $r->da_level;
                    } else {
                        $level_lbl = '—';
                    }
                    $status_color = $r->da_status === 'active' ? '#d63638' : ( $r->da_status === 'lifted' ? '#00a32a' : '#666' );
                    $detail_url = admin_url( 'admin.php?page=owc-oat-entry&entry_id=' . $r->id );
                    echo '<tr>';
                    echo '<td><a href="' . esc_url( $detail_url ) . '">' . esc_html( $r->player_name ?: '—' ) . '</a></td>';
                    echo '<td>' . esc_html( $chron_title ?: '—' ) . '</td>';
                    echo '<td>' . esc_html( $r->da_date ?: '—' ) . '</td>';
                    echo '<td>' . esc_html( $level_lbl ) . '</td>';
                    echo '<td><span style="color:' . $status_color . ';font-weight:600;">' . esc_html( ucfirst( $r->da_status ) ) . '</span></td>';
                    echo '<td style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html( wp_trim_words( wp_strip_all_tags( $r->da_details ), 20 ) ) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
                $base = admin_url( 'admin.php?page=owc-oat-reports&report=disciplinary_actions' );
                if ( $filters['status'] ) {
                    $base .= '&status=' . urlencode( $filters['status'] );
                }
                if ( $q !== '' ) { $base .= '&q=' . urlencode( $q ); }
                owc_oat_render_pagination( $total_rows, $per, $page, $base );
            }
            break;

        case 'da_by_level':
            echo '<h2>Disciplinary Actions by Level</h2>';
            $rows = $wpdb->get_results(
                "SELECT CASE WHEN e.form_slug = 'da_global' AND m_act.meta_value <> '' THEN m_act.meta_value ELSE IFNULL(m.meta_value, 'unknown') END as da_level, COUNT(*) as cnt
                 FROM {$prefix}oat_entries e
                 LEFT JOIN {$prefix}oat_entry_meta m ON e.id = m.entry_id AND m.meta_key = 'da_level'
                 LEFT JOIN {$prefix}oat_entry_meta m_act ON e.id = m_act.entry_id AND m_act.meta_key = 'da_action'
                 WHERE e.domain = 'disciplinary_actions' {$da_entry_scope}
                 GROUP BY da_level ORDER BY cnt DESC"
            );
            $level_labels = array(
                'chronicle_ban' => 'Chronicle Ban', 'chronicle_strike' => 'Chronicle Strike',
                'chronicle_probation' => 'Chronicle Probation', 'temporary_suspension' => 'Temporary Suspension',
                'warning' => 'Warning', 'loss_of_xp' => 'Loss of XP',
                'gnc_of_character' => 'GNC of Character', 'removal_from_staff' => 'Removal from Staff',
                'owbn_strike' => 'OWBN Strike', 'owbn_censure' => 'OWBN Censure',
                'owbn_condemnation' => 'OWBN Condemnation', 'owbn_warning' => 'OWBN Warning',
                'owbn_temporary_ban' => 'OWBN Temporary Ban', 'owbn_indefinite_ban' => 'OWBN Indefinite Ban',
                'owbn_permanent_ban' => 'OWBN Permanent Ban', 'other' => 'Other',
            );
            owc_oat_report_table( array( 'Level', 'Count' ), $rows, function( $r ) use ( $level_labels ) {
                $label = isset( $level_labels[ $r->da_level ] ) ? $level_labels[ $r->da_level ] : $r->da_level;
                return array( $label, number_format( $r->cnt ) );
            } );
            $total = array_sum( wp_list_pluck( $rows, 'cnt' ) );
            echo '<p style="color:#666;margin-top:8px;"><strong>Total: ' . number_format( $total ) . '</strong></p>';
            break;

        case 'recent_activity':
            echo '<h2>Recent Activity (Last 30 Days)</h2>';
            $cutoff = time() - ( 30 * DAY_IN_SECONDS );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT DATE(FROM_UNIXTIME(t.created_at)) as day, t.action_type, COUNT(*) as cnt
                 FROM {$prefix}oat_timeline t
                 JOIN {$prefix}oat_entries e ON t.entry_id = e.id
                 WHERE t.created_at >= %d {$entry_scope}
                 GROUP BY day, t.action_type
                 ORDER BY day DESC, cnt DESC",
                $cutoff
            ) );
            if ( empty( $rows ) ) {
                echo '<p>No activity in the last 30 days.</p>';
            } else {
                $by_day = array();
                $actions = array();
                foreach ( $rows as $r ) {
                    $by_day[ $r->day ][ $r->action_type ] = (int) $r->cnt;
                    $actions[ $r->action_type ] = true;
                }
                $action_keys = array_keys( $actions );
                sort( $action_keys );
                $headers = array_merge( array( 'Date' ), array_map( function( $a ) {
                    return ucfirst( str_replace( '_', ' ', $a ) );
                }, $action_keys ), array( 'Total' ) );
                echo '<table class="widefat striped"><thead><tr>';
                foreach ( $headers as $h ) {
                    echo '<th>' . esc_html( $h ) . '</th>';
                }
                echo '</tr></thead><tbody>';
                foreach ( $by_day as $day => $counts ) {
                    echo '<tr><td>' . esc_html( $day ) . '</td>';
                    $row_total = 0;
                    foreach ( $action_keys as $a ) {
                        $v = isset( $counts[ $a ] ) ? $counts[ $a ] : 0;
                        $row_total += $v;
                        echo '<td style="text-align:right;">' . number_format( $v ) . '</td>';
                    }
                    echo '<td style="text-align:right;font-weight:bold;">' . number_format( $row_total ) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            break;

        default:
            echo '<p>Unknown report.</p>';
    }

    echo '</div>';
}

/**
 * Render a simple two+ column report table with client-side sort/filter.
 */
function owc_oat_report_table( $headers, $rows, $row_fn ) {
    if ( empty( $rows ) ) {
        echo '<p>No data.</p>';
        return;
    }
    static $table_id = 0;
    $table_id++;
    $tid = 'oat-rpt-' . $table_id;

    echo '<input type="text" class="oat-rpt-search" data-table="' . $tid . '" placeholder="Filter rows..." style="margin-bottom:8px;width:250px;padding:4px 8px;">';
    echo '<table id="' . $tid . '" class="widefat striped oat-rpt-table"><thead><tr>';
    foreach ( $headers as $i => $h ) {
        $align = ( $i > 0 ) ? ' style="text-align:right;cursor:pointer;"' : ' style="cursor:pointer;"';
        echo '<th data-col="' . $i . '"' . $align . '>' . esc_html( $h ) . ' <span style="color:#999;font-size:10px;">&#x25B4;&#x25BE;</span></th>';
    }
    echo '</tr></thead><tbody>';
    foreach ( $rows as $r ) {
        $cells = $row_fn( $r );
        echo '<tr>';
        foreach ( $cells as $i => $cell ) {
            $align = ( $i > 0 ) ? ' style="text-align:right;"' : '';
            echo '<td' . $align . '>' . esc_html( $cell ) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table>';
}

/**
 * Render the report search box as a GET form. Submitting (Enter or the button)
 * reloads the report with ?q=… so search runs SERVER-SIDE across all rows, not
 * just the visible page. Preserves report + active filters. The client-side
 * live filter (class oat-rpt-search) still refines the visible page as you type.
 */
function owc_oat_report_search_form( $report, $filters, $q, $table_id ) {
    $out  = '<form method="get" style="display:inline-block;margin:0 0 8px;">';
    $out .= '<input type="hidden" name="page" value="owc-oat-reports">';
    $out .= '<input type="hidden" name="report" value="' . esc_attr( $report ) . '">';
    foreach ( array( 'chronicle', 'genre', 'status' ) as $fk ) {
        if ( ! empty( $filters[ $fk ] ) ) {
            $out .= '<input type="hidden" name="' . esc_attr( $fk ) . '" value="' . esc_attr( $filters[ $fk ] ) . '">';
        }
    }
    $out .= '<input type="search" name="q" class="oat-rpt-search" data-table="' . esc_attr( $table_id ) . '" value="' . esc_attr( $q ) . '" placeholder="Search all pages — press Enter" style="width:280px;padding:4px 8px;">';
    $out .= ' <button type="submit" class="button button-small">Search</button>';
    if ( $q !== '' ) {
        $clear = 'admin.php?page=owc-oat-reports&report=' . rawurlencode( $report );
        foreach ( array( 'chronicle', 'genre', 'status' ) as $fk ) {
            if ( ! empty( $filters[ $fk ] ) ) { $clear .= '&' . $fk . '=' . rawurlencode( $filters[ $fk ] ); }
        }
        $out .= ' <a href="' . esc_url( admin_url( $clear ) ) . '">clear search</a>';
    }
    $out .= '</form>';
    return $out;
}

/**
 * Render windowed pagination: « ‹ 1 2 3 ... 76 77 › »
 */
function owc_oat_render_pagination( $total_rows, $per_page, $current_page, $base_url ) {
    $total_pages = (int) ceil( $total_rows / $per_page );
    if ( $total_pages <= 1 ) {
        return;
    }
    echo '<div style="margin-top:12px;display:flex;align-items:center;gap:4px;flex-wrap:wrap;">';

    // Prev.
    if ( $current_page > 0 ) {
        echo '<a href="' . esc_url( $base_url . '&rpg=' . ( $current_page - 1 ) ) . '" style="padding:4px 8px;text-decoration:none;">&lsaquo;</a>';
    }

    // Window: show pages around current, plus first and last.
    $window = 3;
    for ( $i = 0; $i < $total_pages; $i++ ) {
        if ( $i === 0 || $i === $total_pages - 1 || abs( $i - $current_page ) <= $window ) {
            if ( $i === $current_page ) {
                echo '<strong style="padding:4px 8px;background:#2271b1;color:#fff;border-radius:3px;">' . ( $i + 1 ) . '</strong>';
            } else {
                echo '<a href="' . esc_url( $base_url . '&rpg=' . $i ) . '" style="padding:4px 8px;text-decoration:none;">' . ( $i + 1 ) . '</a>';
            }
        } elseif ( $i === 1 || $i === $total_pages - 2 ) {
            echo '<span style="padding:4px;">…</span>';
        }
    }

    // Next.
    if ( $current_page < $total_pages - 1 ) {
        echo '<a href="' . esc_url( $base_url . '&rpg=' . ( $current_page + 1 ) ) . '" style="padding:4px 8px;text-decoration:none;">&rsaquo;</a>';
    }

    echo '<span style="color:#666;margin-left:8px;">(' . number_format( $total_rows ) . ' rows)</span>';
    echo '</div>';
}

/**
 * Client-side sort and filter JS for report tables.
 * Enqueued once at end of page.
 */
function owc_oat_reports_inline_js() {
    ?>
    <script>
    (function() {
        // Filter
        document.querySelectorAll('.oat-rpt-search').forEach(function(input) {
            input.addEventListener('input', function() {
                var term = this.value.toLowerCase();
                var table = document.getElementById(this.getAttribute('data-table'));
                if (!table) return;
                table.querySelectorAll('tbody tr').forEach(function(tr) {
                    tr.style.display = tr.textContent.toLowerCase().indexOf(term) >= 0 ? '' : 'none';
                });
            });
        });
        // Sort
        document.querySelectorAll('.oat-rpt-table th[data-col]').forEach(function(th) {
            th.addEventListener('click', function() {
                var col = parseInt(this.getAttribute('data-col'));
                var table = this.closest('table');
                var tbody = table.querySelector('tbody');
                var rows = Array.from(tbody.querySelectorAll('tr'));
                var asc = this.getAttribute('data-sort-dir') !== 'asc';
                this.setAttribute('data-sort-dir', asc ? 'asc' : 'desc');
                rows.sort(function(a, b) {
                    var ca = a.children[col], cb = b.children[col];
                    var va = (ca && ca.getAttribute('data-sort') !== null) ? ca.getAttribute('data-sort') : ((ca || {}).textContent || '');
                    var vb = (cb && cb.getAttribute('data-sort') !== null) ? cb.getAttribute('data-sort') : ((cb || {}).textContent || '');
                    var na = parseFloat(String(va).replace(/,/g, '')), nb = parseFloat(String(vb).replace(/,/g, ''));
                    if (!isNaN(na) && !isNaN(nb)) return asc ? na - nb : nb - na;
                    return asc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
                });
                rows.forEach(function(r) { tbody.appendChild(r); });
            });
        });
    })();
    </script>
    <?php
}
add_action( 'admin_footer', 'owc_oat_reports_inline_js' );
