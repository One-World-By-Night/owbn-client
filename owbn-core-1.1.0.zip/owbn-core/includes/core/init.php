<?php
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/client-register.php';
require_once __DIR__ . '/client-api.php';
require_once __DIR__ . '/entity-resolution.php';
