<?php

/**
 * OWBN-Client Coordinator Box Render
 * location: includes/render/render-coordinator-box.php
 * @package OWBN-Client
 * @version 2.1.0
 */

defined('ABSPATH') || exit;
