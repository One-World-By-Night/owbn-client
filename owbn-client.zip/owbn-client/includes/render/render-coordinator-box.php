<?php

/**
 * OWBN-Client Coordinator Box Render
 * location: includes/render/render-coordinator-box.php
 * @package OWBN-Client

 */

defined('ABSPATH') || exit;
