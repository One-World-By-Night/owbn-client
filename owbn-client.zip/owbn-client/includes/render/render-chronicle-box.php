<?php

/**
 * OWBN-Client Chronicle Box Render
 * location: includes/render/render-chronicle-box.php
 * @package OWBN-Client
 * @version 2.1.0
 */

defined('ABSPATH') || exit;
