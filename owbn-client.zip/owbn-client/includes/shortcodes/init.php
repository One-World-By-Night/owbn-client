<?php

/**
 * OWBNClient Shortcodes Init
 * 
 * @package OWBNClient

 */

defined('ABSPATH') || exit;

// Shortcode files will be loaded here
require_once __DIR__ . '/shortcodes.php';
require_once __DIR__ . '/shortcodes-chronicle.php';
require_once __DIR__ . '/shortcodes-coordinator.php';
