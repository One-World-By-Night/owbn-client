<?php

/**
 * OWBN-CC-Client Shortcodes Init
 * 
 * @package OWBN-CC-Client
 * @version 1.1.0
 */

defined('ABSPATH') || exit;

// Shortcode files will be loaded here
require_once __DIR__ . '/shortcodes.php';
// require_once __DIR__ . '/chronicle-detail.php';
// require_once __DIR__ . '/chronicles-list.php';
// require_once __DIR__ . '/coordinator-detail.php';
// require_once __DIR__ . '/coordinators-list.php';
