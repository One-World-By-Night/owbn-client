<?php

/**
 * OWBN-CC-Client Hooks Init
 * 
 * @package OWBN-CC-Client
 * @version 1.1.0
 */

defined('ABSPATH') || exit;

// Hook files will be loaded here
// require_once __DIR__ . '/cache-hooks.php';