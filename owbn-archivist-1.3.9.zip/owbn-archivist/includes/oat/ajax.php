<?php

/**
 * OAT Client AJAX Handlers
 *
 * AJAX endpoints for OAT client pages. All calls proxy through
 * the api.php layer which handles local/remote mode switching.
 *
 */

defined( 'ABSPATH' ) || exit;

add_action( 'wp_ajax_owc_oat_search_rules', 'owc_oat_ajax_search_rules' );
add_action( 'wp_ajax_owc_oat_search_cchub', 'owc_oat_ajax_search_cchub' );
add_action( 'wp_ajax_owc_oat_process_action', 'owc_oat_ajax_process_action' );
add_action( 'wp_ajax_owc_oat_toggle_watch', 'owc_oat_ajax_toggle_watch' );
add_action( 'wp_ajax_owc_oat_get_domain_fields', 'owc_oat_ajax_get_domain_fields' );
add_action( 'wp_ajax_owc_oat_get_domain_forms', 'owc_oat_ajax_get_domain_forms' );
add_action( 'wp_ajax_owc_oat_search_characters', 'owc_oat_ajax_search_characters' );
add_action( 'wp_ajax_owc_oat_create_character', 'owc_oat_ajax_create_character' );
add_action( 'wp_ajax_owc_oat_lookup_hst', 'owc_oat_ajax_lookup_hst' );
add_action( 'wp_ajax_owc_oat_search_users', 'owc_oat_ajax_search_users' );
add_action( 'wp_ajax_owc_oat_get_coordinators_for_rules', 'owc_oat_ajax_get_coordinators_for_rules' );
add_action( 'wp_ajax_owc_oat_submit_entry_frontend', 'owc_oat_ajax_submit_entry_frontend' );
add_action( 'wp_ajax_owc_oat_get_recent_activity', 'owc_oat_ajax_get_recent_activity' );
add_action( 'wp_ajax_owc_oat_registry_sections', 'owc_oat_ajax_registry_sections' );
add_action( 'wp_ajax_owc_oat_registry_section', 'owc_oat_ajax_registry_section' );
add_action( 'wp_ajax_owc_oat_registry_search', 'owc_oat_ajax_registry_search' );
add_action( 'wp_ajax_owc_oat_save_registry_columns', 'owc_oat_ajax_save_registry_columns' );
add_action( 'wp_ajax_owc_cchub_get_entry', 'owc_cchub_ajax_get_entry' );
add_action( 'wp_ajax_owc_oat_lookup_wp_user', 'owc_oat_ajax_lookup_wp_user' );
add_action( 'wp_ajax_nopriv_owc_cchub_get_entry', 'owc_cchub_ajax_get_entry' );

/**
 * AJAX: Search regulation rules for autocomplete.
 *
 * @return void
 */
function owc_oat_ajax_search_rules() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $term = isset( $_GET['term'] ) ? sanitize_text_field( $_GET['term'] ) : '';
    if ( strlen( $term ) < 2 ) {
        wp_send_json( array() );
    }

    $results = owc_oat_search_rules( $term );

    if ( is_wp_error( $results ) ) {
        wp_send_json_error( $results->get_error_message() );
    }

    wp_send_json( $results );
}

/**
 * AJAX: Search approved custom content entries (ccHub) for the cchub_picker field.
 *
 * @return void
 */
function owc_oat_ajax_search_cchub() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $term = isset( $_GET['term'] ) ? sanitize_text_field( $_GET['term'] ) : '';
    if ( strlen( $term ) < 2 ) {
        wp_send_json( array() );
    }

    global $wpdb;
    $prefix = $wpdb->prefix;
    $like   = '%' . $wpdb->esc_like( $term ) . '%';

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT e.id, m_name.meta_value AS content_name, m_type.meta_value AS content_type, e.coordinator_genre
         FROM {$prefix}oat_entries e
         JOIN {$prefix}oat_entry_meta m_name ON e.id = m_name.entry_id AND m_name.meta_key = 'content_name'
         LEFT JOIN {$prefix}oat_entry_meta m_type ON e.id = m_type.entry_id AND m_type.meta_key = 'content_type'
         WHERE e.domain = 'custom_content' AND e.status = 'approved'
           AND m_name.meta_value LIKE %s
         ORDER BY m_name.meta_value ASC
         LIMIT 20",
        $like
    ) );

    $results = array();
    foreach ( $rows as $r ) {
        $label = $r->content_type ? 'Custom ' . $r->content_type . ': ' . $r->content_name : $r->content_name;
        if ( $r->coordinator_genre && function_exists( 'owc_entity_get_title' ) ) {
            $coord_title = owc_entity_get_title( 'coordinator', $r->coordinator_genre );
            if ( $coord_title ) {
                $label .= ' — ' . $coord_title;
            }
        }
        $results[] = array(
            'id'    => (int) $r->id,
            'label' => $label,
            'value' => $r->content_name,
        );
    }

    wp_send_json( $results );
}

/**
 * AJAX: Execute a workflow action on an entry.
 *
 * @return void
 */
function owc_oat_ajax_process_action() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $entry_id    = isset( $_POST['entry_id'] ) ? absint( $_POST['entry_id'] ) : 0;
    $action_type = isset( $_POST['action_type'] ) ? sanitize_text_field( $_POST['action_type'] ) : '';
    $note        = isset( $_POST['note'] ) ? sanitize_textarea_field( $_POST['note'] ) : '';

    if ( ! $entry_id || ! $action_type ) {
        wp_send_json_error( 'Missing entry_id or action_type.' );
    }

    // Collect extra data for specific actions.
    $extra_data = array();
    if ( ! empty( $_POST['vote_reference'] ) ) {
        $extra_data['vote_reference'] = sanitize_text_field( $_POST['vote_reference'] );
    }
    if ( ! empty( $_POST['additional_seconds'] ) ) {
        $extra_data['additional_seconds'] = absint( $_POST['additional_seconds'] );
    }
    if ( ! empty( $_POST['new_user_id'] ) ) {
        $extra_data['target_user_id'] = absint( $_POST['new_user_id'] );
    }
    if ( ! empty( $_POST['delegate_user_id'] ) ) {
        $extra_data['target_user_id'] = absint( $_POST['delegate_user_id'] );
    }

    $result = owc_oat_execute_action( $entry_id, $action_type, $note, $extra_data );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}

/**
 * AJAX: Toggle watch on an entry.
 *
 * @return void
 */
function owc_oat_ajax_toggle_watch() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $entry_id     = isset( $_POST['entry_id'] ) ? absint( $_POST['entry_id'] ) : 0;
    $watch_action = isset( $_POST['watch_action'] ) ? sanitize_text_field( $_POST['watch_action'] ) : 'toggle';

    if ( ! $entry_id ) {
        wp_send_json_error( 'Missing entry_id.' );
    }

    $result = owc_oat_toggle_watch( $entry_id, $watch_action );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}

/**
 * AJAX: Get rendered form fields for a domain.
 *
 * Returns server-rendered HTML so the client can insert it directly
 * into #owc-oat-domain-fields without client-side field rendering.
 *
 * @return void
 */
function owc_oat_ajax_get_domain_fields() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $domain    = isset( $_REQUEST['domain'] ) ? sanitize_text_field( $_REQUEST['domain'] ) : '';
    $form_slug = isset( $_REQUEST['form_slug'] ) ? sanitize_text_field( $_REQUEST['form_slug'] ) : '';

    if ( empty( $domain ) && empty( $form_slug ) ) {
        wp_send_json_error( 'Missing domain or form_slug.' );
    }

    $slug   = $form_slug ? $form_slug : $domain;
    $fields = owc_oat_get_form_fields( $slug, 'submit' );

    if ( is_wp_error( $fields ) ) {
        wp_send_json_error( $fields->get_error_message() );
    }

    if ( empty( $fields ) ) {
        wp_send_json_success( array( 'html' => '' ) );
    }

    ob_start();
    owc_oat_render_fields( $fields );
    if ( class_exists( '_WP_Editors', false ) ) {
        _WP_Editors::editor_js();
    }
    $html = ob_get_clean();

    wp_send_json_success( array( 'html' => $html ) );
}

function owc_oat_ajax_get_domain_forms() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $domain_slug = isset( $_REQUEST['domain_slug'] ) ? sanitize_text_field( $_REQUEST['domain_slug'] ) : '';
    if ( empty( $domain_slug ) ) {
        wp_send_json_error( 'Missing domain_slug.' );
    }

    $forms = owc_oat_get_forms_for_domain( $domain_slug );
    wp_send_json_success( $forms );
}

/**
 * AJAX: Search characters by name for autocomplete (D-056).
 *
 * @return void
 */
function owc_oat_ajax_search_characters() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $term = isset( $_GET['term'] ) ? sanitize_text_field( $_GET['term'] ) : '';
    if ( strlen( $term ) < 2 ) {
        wp_send_json( array() );
    }

    if ( ! class_exists( 'OAT_Character' ) ) {
        wp_send_json( array() );
    }

    global $wpdb;
    $table = $wpdb->prefix . 'oat_characters';
    $like  = '%' . $wpdb->esc_like( $term ) . '%';

    // Role-based scope filtering (P4a / CC-002).
    $scope           = isset( $_GET['scope'] ) ? sanitize_text_field( $_GET['scope'] ) : '';
    $chronicle_slug  = isset( $_GET['chronicle_slug'] ) ? sanitize_text_field( $_GET['chronicle_slug'] ) : '';
    $where_extra     = '';
    $prepare_args    = array( $like );

    if ( $scope === 'player' ) {
        $user = wp_get_current_user();
        if ( $user && $user->user_email ) {
            $where_extra = ' AND player_email = %s';
            $prepare_args[] = $user->user_email;
        }
    } elseif ( $scope === 'staff' && $chronicle_slug ) {
        $where_extra = ' AND chronicle_slug = %s';
        $prepare_args[] = $chronicle_slug;
    }
    // 'coordinator' and 'archivist' scopes have no filter — all characters.

    $sql = "SELECT uuid, character_name, chronicle_slug, player_name, pc_npc FROM {$table} WHERE character_name LIKE %s{$where_extra} ORDER BY character_name ASC LIMIT 15";
    $rows = $wpdb->get_results( $wpdb->prepare( $sql, $prepare_args ) );

    $results = array();
    foreach ( $rows as $row ) {
        $chron_title = '';
        if ( $row->chronicle_slug && function_exists( 'owc_entity_get_title' ) ) {
            $chron_title = owc_entity_get_title( 'chronicle', $row->chronicle_slug );
        }
        $results[] = array(
            'uuid'            => $row->uuid,
            'character_name'  => $row->character_name,
            'chronicle_slug'  => $row->chronicle_slug ? $row->chronicle_slug : '',
            'chronicle_title' => $chron_title ? $chron_title : ( $row->chronicle_slug ? $row->chronicle_slug : '' ),
            'player_name'     => $row->player_name,
            'pc_npc'          => isset( $row->pc_npc ) ? $row->pc_npc : 'pc',
        );
    }

    wp_send_json( $results );
}

/**
 * AJAX: Create a new character inline (D-056).
 *
 * @return void
 */
function owc_oat_ajax_create_character() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    if ( ! owc_oat_can_create_character() ) {
        wp_send_json_error( 'You do not have permission to create characters.' );
    }

    if ( ! class_exists( 'OAT_Character' ) ) {
        wp_send_json_error( 'OAT_Character model not available.' );
    }

    $char_name      = isset( $_POST['character_name'] ) ? sanitize_text_field( $_POST['character_name'] ) : '';
    $chronicle_slug = isset( $_POST['chronicle_slug'] ) ? sanitize_text_field( $_POST['chronicle_slug'] ) : '';
    $pc_npc         = isset( $_POST['pc_npc'] ) ? sanitize_text_field( $_POST['pc_npc'] ) : 'pc';

    if ( empty( $char_name ) ) {
        wp_send_json_error( 'Character name is required.' );
    }

    $user = wp_get_current_user();
    if ( ! $user || ! $user->ID ) {
        wp_send_json_error( 'You must be logged in.' );
    }

    $creature_genre    = isset( $_POST['creature_genre'] ) ? sanitize_text_field( $_POST['creature_genre'] ) : '';
    $creature_type     = isset( $_POST['creature_type'] ) ? sanitize_text_field( $_POST['creature_type'] ) : '';
    $creature_sub_type = isset( $_POST['creature_sub_type'] ) ? sanitize_text_field( $_POST['creature_sub_type'] ) : '';
    $creature_variant  = isset( $_POST['creature_variant'] ) ? sanitize_text_field( $_POST['creature_variant'] ) : '';

    $create_data = array(
        'character_name' => $char_name,
        'chronicle_slug' => $chronicle_slug,
        'player_email'   => $user->user_email,
        'player_name'    => $user->display_name,
        'wp_user_id'     => $user->ID,
    );
    if ( in_array( $pc_npc, array( 'pc', 'npc' ), true ) ) {
        $create_data['pc_npc'] = $pc_npc;
    }
    if ( $creature_genre ) {
        $create_data['creature_genre'] = $creature_genre;
    }
    if ( $creature_type ) {
        $create_data['creature_type'] = $creature_type;
    }
    if ( $creature_sub_type ) {
        $create_data['creature_sub_type'] = $creature_sub_type;
    }
    if ( $creature_variant ) {
        $create_data['creature_variant'] = $creature_variant;
    }

    $id = OAT_Character::create( $create_data );

    if ( ! $id ) {
        wp_send_json_error( 'Failed to create character.' );
    }

    $char = OAT_Character::find( $id );
    if ( ! $char ) {
        wp_send_json_error( 'Character created but could not be retrieved.' );
    }

    wp_send_json_success( array(
        'uuid'           => $char->uuid,
        'character_name' => $char->character_name,
        'chronicle_slug' => $char->chronicle_slug ? $char->chronicle_slug : '',
        'pc_npc'         => isset( $char->pc_npc ) ? $char->pc_npc : 'pc',
    ) );
}

/**
 * AJAX: Look up HST display name for a chronicle slug (D-058).
 *
 * Resolves `chronicle/{slug}/hst` role via accessSchema to find the HST.
 *
 * @return void
 */
function owc_oat_ajax_lookup_hst() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $slug = isset( $_GET['chronicle_slug'] ) ? sanitize_text_field( $_GET['chronicle_slug'] ) : '';
    if ( empty( $slug ) ) {
        wp_send_json_error( 'Missing chronicle_slug.' );
    }

    // Build the role path: chronicle/{slug}/hst
    $role_path = 'chronicle/' . $slug . '/hst';

    // Try to find who holds this role via ASC.
    if ( ! function_exists( 'owc_asc_get_all_roles' ) ) {
        wp_send_json_success( array( 'found' => false, 'name' => '' ) );
    }

    $data = owc_asc_get_all_roles( 'owc' );
    if ( is_wp_error( $data ) || ! is_array( $data ) || ! isset( $data['roles'] ) ) {
        wp_send_json_success( array( 'found' => false, 'name' => '' ) );
    }

    // Search for the HST role and find who holds it.
    $hst_name = '';
    foreach ( $data['roles'] as $role ) {
        $role = (array) $role;
        $path = isset( $role['path'] ) ? strtolower( (string) $role['path'] ) : '';
        if ( $path === strtolower( $role_path ) ) {
            $hst_name = isset( $role['name'] ) ? (string) $role['name'] : '';
            break;
        }
    }

    if ( $hst_name ) {
        wp_send_json_success( array( 'found' => true, 'name' => $hst_name ) );
    }

    wp_send_json_success( array( 'found' => false, 'name' => '' ) );
}

/**
 * AJAX: Search users by name for reassign/delegate autocomplete.
 *
 * Returns users matching display_name or user_login, plus ASC role path
 * matches if the term looks like a role path (contains '/').
 *
 * @return void
 */
function owc_oat_ajax_search_users() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $term = isset( $_GET['term'] ) ? sanitize_text_field( $_GET['term'] ) : '';
    if ( strlen( $term ) < 2 ) {
        wp_send_json( array() );
    }

    $results = array();

    // Search WordPress users by display_name or user_login.
    $users = get_users( array(
        'search'         => '*' . $term . '*',
        'search_columns' => array( 'user_login', 'display_name', 'user_email' ),
        'number'         => 15,
        'orderby'        => 'display_name',
    ) );

    foreach ( $users as $user ) {
        $results[] = array(
            'id'           => $user->ID,
            'label'        => $user->display_name . ' (' . $user->user_login . ')',
            'value'        => $user->display_name,
            'type'         => 'user',
            'display_name' => $user->display_name,
            'email'        => $user->user_email,
        );
    }

    // If term contains '/' it might be an ASC role path — resolve to user(s).
    if ( strpos( $term, '/' ) !== false && function_exists( 'owc_asc_get_users_by_role' ) ) {
        // Exact role path match first.
        $role_users = owc_asc_get_users_by_role( 'oat', $term );

        // No exact match — try prefix match (e.g. "coordinator/tremere" matches
        // users with "coordinator/tremere/coordinator").
        if ( empty( $role_users ) || is_wp_error( $role_users ) ) {
            $role_users = owc_oat_search_users_by_role_prefix( $term );
        }

        if ( is_array( $role_users ) ) {
            $seen_ids = array();
            foreach ( $results as $r ) {
                $seen_ids[ $r['id'] ] = true;
            }
            foreach ( $role_users as $ru ) {
                $ru  = (array) $ru;
                $uid = isset( $ru['user_id'] ) ? (int) $ru['user_id'] : 0;
                if ( ! $uid || isset( $seen_ids[ $uid ] ) ) {
                    continue;
                }
                $name = isset( $ru['display_name'] ) ? $ru['display_name'] : '';
                $path = isset( $ru['role_path'] ) ? $ru['role_path'] : $term;
                $user_obj = get_userdata( $uid );
                $email    = $user_obj ? $user_obj->user_email : '';
                $results[] = array(
                    'id'           => $uid,
                    'label'        => $name . ' (via ' . $path . ')',
                    'value'        => $name,
                    'type'         => 'role',
                    'display_name' => $name,
                    'email'        => $email,
                );
                $seen_ids[ $uid ] = true;
            }
        }
    }

    wp_send_json( $results );
}

/**
 * Search users whose cached ASC roles start with a given prefix.
 *
 * E.g. prefix "coordinator/tremere" matches users holding
 * "coordinator/tremere/coordinator" or "coordinator/tremere/sub-coordinator".
 *
 * @param string $prefix Role path prefix.
 * @return array Array of arrays with user_id, display_name, role_path.
 */
function owc_oat_search_users_by_role_prefix( $prefix ) {
    if ( ! defined( 'OWC_ASC_CACHE_KEY' ) ) {
        return array();
    }

    global $wpdb;
    $prefix = sanitize_text_field( $prefix );
    $like   = '%' . $wpdb->esc_like( $prefix ) . '%';

    $user_ids = $wpdb->get_col( $wpdb->prepare(
        "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value LIKE %s",
        OWC_ASC_CACHE_KEY,
        $like
    ) );

    if ( empty( $user_ids ) ) {
        return array();
    }

    $results    = array();
    $prefix_low = strtolower( $prefix );

    foreach ( $user_ids as $uid ) {
        $cached_roles = get_user_meta( (int) $uid, OWC_ASC_CACHE_KEY, true );
        if ( ! is_array( $cached_roles ) ) {
            continue;
        }
        foreach ( $cached_roles as $cached_path ) {
            if ( strpos( strtolower( $cached_path ), $prefix_low ) === 0 ) {
                $user = get_user_by( 'id', (int) $uid );
                if ( $user ) {
                    $results[] = array(
                        'user_id'      => $user->ID,
                        'display_name' => $user->display_name,
                        'role_path'    => $cached_path,
                    );
                }
                break;
            }
        }
    }

    return $results;
}

/**
 * AJAX: Get controlling coordinator(s) for a set of regulation rule IDs.
 *
 * Accepts a JSON array of rule IDs, queries OAT_Regulation_Rule for each,
 * and returns unique coordinator genre slugs with human-readable names.
 *
 * @return void
 */
function owc_oat_ajax_get_coordinators_for_rules() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $rule_ids_raw = isset( $_GET['rule_ids'] ) ? sanitize_text_field( $_GET['rule_ids'] ) : '[]';
    $rule_ids     = json_decode( $rule_ids_raw, true );
    // D3: PC/NPC determines which level column to use.
    $pc_npc       = isset( $_GET['pc_npc'] ) ? sanitize_text_field( $_GET['pc_npc'] ) : 'pc';

    if ( ! is_array( $rule_ids ) || empty( $rule_ids ) ) {
        wp_send_json_success( array( 'coordinators' => array(), 'requires_coord' => false ) );
    }

    $rule_ids = array_map( 'absint', $rule_ids );
    $seen     = array();
    $results  = array();

    // D3: Track highest regulation level for requires_coord determination.
    $priority = array(
        'council_vote'         => 4,
        'disallowed'           => 3,
        'coordinator_approval' => 2,
        'coordinator_notify'   => 1,
    );
    $highest = 0;

    foreach ( $rule_ids as $rid ) {
        if ( ! $rid ) {
            continue;
        }

        // Resolve rule data: prefer local DB (archivist), fall back to remote cache.
        $genre     = '';
        $pc_level  = '';
        $npc_level = '';

        if ( class_exists( 'OAT_Regulation_Rule' ) ) {
            $rule = OAT_Regulation_Rule::find( $rid );
            if ( ! $rule || empty( $rule->genre ) ) {
                continue;
            }
            $genre     = $rule->genre;
            $pc_level  = $rule->pc_level;
            $npc_level = $rule->npc_level;
        } elseif ( function_exists( 'owc_oat_find_cached_rule' ) ) {
            $rule = owc_oat_find_cached_rule( $rid );
            if ( ! $rule || empty( $rule['coordinator'] ) ) {
                continue;
            }
            $genre     = $rule['coordinator'];
            $pc_level  = isset( $rule['pc_level'] ) ? $rule['pc_level'] : '';
            $npc_level = isset( $rule['npc_level'] ) ? $rule['npc_level'] : '';
        } else {
            continue;
        }

        // D3: Use pc_level or npc_level based on character type.
        $level = ( 'npc' === $pc_npc && ! empty( $npc_level ) ) ? $npc_level : $pc_level;
        if ( $level && isset( $priority[ $level ] ) && $priority[ $level ] > $highest ) {
            $highest = $priority[ $level ];
        }

        if ( isset( $seen[ $genre ] ) ) {
            continue;
        }
        $seen[ $genre ] = true;

        $name = $genre;
        if ( function_exists( 'owc_entity_get_title' ) ) {
            $title = owc_entity_get_title( 'coordinator', $genre );
            if ( $title ) {
                $name = $title;
            }
        }

        $results[] = array(
            'genre' => $genre,
            'name'  => $name,
        );
    }

    wp_send_json_success( array(
        'coordinators'   => $results,
        'requires_coord' => $highest >= 2,
    ) );
}

/**
 * AJAX: Frontend entry submission from Elementor Submit Form widget.
 *
 * Collects POST data, strips framework fields, passes meta to owc_oat_submit().
 * Returns entry_id on success.
 *
 * @return void
 */
function owc_oat_ajax_submit_entry_frontend() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( __( 'You must be logged in to submit.', 'owbn-archivist' ) );
    }

    $domain    = isset( $_POST['oat_domain'] ) ? sanitize_key( $_POST['oat_domain'] ) : '';
    $form_slug = isset( $_POST['oat_form_slug'] ) ? sanitize_key( $_POST['oat_form_slug'] ) : '';

    if ( ! $domain ) {
        wp_send_json_error( __( 'Please select a domain.', 'owbn-archivist' ) );
    }

    $skip = array( 'action', 'nonce', '_wpnonce', 'oat_domain', 'oat_form_slug' );
    $meta = array();
    foreach ( $_POST as $key => $value ) {
        if ( in_array( $key, $skip, true ) ) {
            continue;
        }
        // Strip oat_meta_ prefix so keys match domain field names.
        $clean_key = sanitize_key( $key );
        if ( strpos( $clean_key, 'oat_meta_' ) === 0 ) {
            $clean_key = substr( $clean_key, 9 );
        }
        if ( '' === $clean_key ) {
            continue;
        }
        if ( is_array( $value ) ) {
            $meta[ $clean_key ] = array_map( 'sanitize_text_field', array_map( 'wp_unslash', $value ) );
        } else {
            $meta[ $clean_key ] = sanitize_text_field( wp_unslash( $value ) );
        }
    }

    // Parse rules from meta.
    $parsed_rules = array();
    foreach ( array( 'regulation_rules', 'ru_rules' ) as $rk ) {
        if ( ! empty( $meta[ $rk ] ) ) {
            $decoded = is_string( $meta[ $rk ] ) ? json_decode( $meta[ $rk ], true ) : $meta[ $rk ];
            if ( is_array( $decoded ) && ! empty( $decoded ) ) {
                $parsed_rules = $decoded;
            }
            break;
        }
    }

    // Batch split: character_lifecycle with multiple rules → one entry per rule.
    $is_cl    = ( 'character_lifecycle' === $domain );
    $do_split = $is_cl && count( $parsed_rules ) > 1;

    $batches = array();
    if ( $do_split ) {
        foreach ( $parsed_rules as $rule ) {
            $entry_meta = $meta;
            foreach ( array( 'regulation_rules', 'ru_rules' ) as $rk ) {
                if ( isset( $entry_meta[ $rk ] ) ) {
                    $entry_meta[ $rk ] = wp_json_encode( array( $rule ) );
                }
            }
            // Build item_description from the rule.
            if ( is_array( $rule ) && isset( $rule['text'] ) ) {
                $entry_meta['item_description'] = sanitize_text_field( $rule['text'] );
            } elseif ( is_numeric( $rule ) && class_exists( 'OAT_Regulation_Rule' ) ) {
                $rule_obj = OAT_Regulation_Rule::find( (int) $rule );
                if ( $rule_obj ) {
                    $parts = array_filter( array( $rule_obj->category, $rule_obj->subcategory, $rule_obj->condition_name ) );
                    $entry_meta['item_description'] = implode( ': ', $parts );
                }
            }
            $batches[] = array( 'meta' => $entry_meta, 'rules' => array( $rule ) );
        }
    } else {
        $batches[] = array( 'meta' => $meta, 'rules' => $parsed_rules );
    }

    $created_ids = array();
    foreach ( $batches as $batch ) {
        $data = array(
            'domain' => $domain,
            'meta'   => $batch['meta'],
            'rules'  => $batch['rules'],
        );
        if ( $form_slug ) {
            $data['form_slug'] = $form_slug;
        }
        if ( ! empty( $batch['meta']['chronicle_slug'] ) ) {
            $data['chronicle_slug'] = $batch['meta']['chronicle_slug'];
        }
        if ( ! empty( $batch['meta']['coordinator_genre'] ) ) {
            $data['coordinator_genre'] = $batch['meta']['coordinator_genre'];
        }

        $result = owc_oat_submit( $data );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        $eid = is_array( $result ) && isset( $result['entry_id'] ) ? (int) $result['entry_id'] : (int) $result;
        $created_ids[] = $eid;
    }

    if ( count( $created_ids ) === 1 ) {
        wp_send_json_success( array( 'entry_id' => $created_ids[0] ) );
    } else {
        wp_send_json_success( array(
            'entry_id' => $created_ids[0],
            'batch'    => true,
            'count'    => count( $created_ids ),
            'ids'      => $created_ids,
        ) );
    }
}

/**
 * AJAX: Recent activity feed for Elementor Activity Feed widget auto-refresh.
 *
 * @return void
 */
function owc_oat_ajax_get_recent_activity() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( 'Not logged in.' );
    }

    $user_id = get_current_user_id();
    $limit   = isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 10;
    $domain  = isset( $_POST['domain'] ) ? sanitize_key( $_POST['domain'] ) : '';

    $items = owc_oat_get_recent_activity( $user_id, $limit, $domain );

    if ( is_wp_error( $items ) ) {
        wp_send_json_error( $items->get_error_message() );
    }

    // Render HTML for AJAX refresh using the Activity widget's static method.
    $detail_url = '/oat-entry/';
    if ( class_exists( 'OWC_OAT_Activity_Widget' ) ) {
        $html = OWC_OAT_Activity_Widget::render_items( $items, $detail_url );
        wp_send_json_success( array( 'html' => $html ) );
    }

    wp_send_json_success( array( 'items' => $items ) );
}

/**
 * AJAX: Get a single custom content entry for the ccHub modal.
 */
function owc_cchub_ajax_get_entry() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $entry_id = absint( $_REQUEST['entry_id'] ?? 0 );
    if ( ! $entry_id ) {
        wp_send_json_error( 'No entry ID.' );
    }

    if ( ! function_exists( 'owc_oat_get_cchub_entry' ) ) {
        wp_send_json_error( 'ccHub API not available.' );
    }

    $data = owc_oat_get_cchub_entry( $entry_id );

    if ( is_wp_error( $data ) ) {
        wp_send_json_error( $data->get_error_message() );
    }

    // Build modal HTML server-side and translate it via TP for the requested
    // language. The frontend reads `data.html` directly so the modal mirrors
    // whatever language the page is currently showing. Falls back to the raw
    // data fields for any caller that hasn't been updated yet.
    $lang_slug   = isset( $_REQUEST['lang'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['lang'] ) ) : '';
    $lang_prefix = $lang_slug ? '/' . $lang_slug : '';

    if ( function_exists( 'owc_cchub_render_entry_html' ) ) {
        $html = owc_cchub_render_entry_html( $data, $lang_prefix );
        if ( function_exists( 'owc_cchub_translate_html' ) && function_exists( 'owc_oat_resolve_trp_language' ) ) {
            $target_locale = owc_oat_resolve_trp_language( $lang_slug );
            $html = owc_cchub_translate_html( $html, $target_locale );
        }
        $data['html'] = $html;
    }

    wp_send_json_success( $data );
}

/**
 * AJAX: Get registry section headers with counts for a scope.
 *
 * POST params: scope (mine|chronicles|coordinators|decommissioned)
 */
function owc_oat_ajax_registry_sections() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $scope = isset( $_POST['scope'] ) ? sanitize_text_field( $_POST['scope'] ) : 'mine';
    $valid = array( 'mine', 'chronicles', 'coordinators', 'decommissioned' );
    if ( ! in_array( $scope, $valid, true ) ) {
        wp_send_json_error( 'Invalid scope.' );
    }

    $data = owc_oat_get_registry_sections( $scope );
    if ( is_wp_error( $data ) ) {
        wp_send_json_error( $data->get_error_message() );
    }

    wp_send_json_success( $data );
}

/**
 * AJAX: Get characters for a single registry section.
 *
 * POST params: section_key (e.g. 'mine', 'chronicle-hartford', 'coordinator-vampire')
 */
function owc_oat_ajax_registry_section() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $section_key = isset( $_POST['section_key'] ) ? sanitize_text_field( $_POST['section_key'] ) : '';
    if ( ! $section_key ) {
        wp_send_json_error( 'Missing section_key.' );
    }

    $data = owc_oat_get_section_characters( $section_key );
    if ( is_wp_error( $data ) ) {
        wp_send_json_error( $data->get_error_message() );
    }

    wp_send_json_success( $data );
}

/**
 * AJAX: Search registry characters by name or chronicle.
 *
 * POST params: q (search term, min 2 chars)
 * Returns scoped results — user only sees characters they have access to.
 */
function owc_oat_ajax_registry_search() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $q = isset( $_POST['q'] ) ? sanitize_text_field( $_POST['q'] ) : '';
    if ( strlen( $q ) < 2 ) {
        wp_send_json_error( 'Search term too short.' );
    }

    $data = owc_oat_registry_search( $q );
    if ( is_wp_error( $data ) ) {
        wp_send_json_error( $data->get_error_message() );
    }

    wp_send_json_success( $data );
}

/**
 * AJAX: Save registry column preferences for current user.
 */
function owc_oat_ajax_save_registry_columns() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    $columns = isset( $_POST['columns'] ) ? json_decode( stripslashes( $_POST['columns'] ), true ) : array();
    if ( ! is_array( $columns ) ) {
        wp_send_json_error( 'Invalid columns.' );
    }

    // Sanitize — only allow known column keys.
    $allowed = array( 'character', 'player', 'chronicle', 'type', 'pcnpc', 'status', 'entries', 'my_entries', 'last_activity' );
    $columns = array_values( array_intersect( $columns, $allowed ) );

    // Ensure mandatory columns.
    foreach ( array( 'character', 'chronicle', 'status' ) as $mandatory ) {
        if ( ! in_array( $mandatory, $columns, true ) ) {
            $columns[] = $mandatory;
        }
    }

    update_user_meta( get_current_user_id(), 'owc_oat_registry_columns', $columns );
    wp_send_json_success();
}

/**
 * AJAX: Look up a WP user by email for character association.
 */
function owc_oat_ajax_lookup_wp_user() {
    check_ajax_referer( 'owc_oat_nonce', 'nonce' );

    if ( ! current_user_can( 'edit_users' ) && ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied.' );
    }

    $email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
    if ( ! $email ) {
        wp_send_json_error( 'No email provided.' );
    }

    $user = get_user_by( 'email', $email );
    if ( ! $user ) {
        wp_send_json_success( array( 'user_id' => 0 ) );
    }

    wp_send_json_success( array(
        'user_id'      => $user->ID,
        'display_name' => $user->display_name,
        'email'        => $user->user_email,
    ) );
}
