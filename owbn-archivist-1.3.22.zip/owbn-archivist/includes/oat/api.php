<?php

/**
 * OAT Client API
 *
 * Local/remote mode switching for OAT data access.
 * Local mode: calls OAT models directly (archivist.owbn.net).
 * Remote mode: HTTP POST to OAT gateway endpoints.
 *
 */

defined( 'ABSPATH' ) || exit;


/**
 * Check if OAT should use local mode.
 *
 * Local requires both: mode set to 'local' AND OAT plugin classes available.
 *
 * @return bool
 */
function owc_oat_is_local() {
    return owc_get_mode( 'oat' ) === 'local' && class_exists( 'OAT_Entry' );
}


/**
 * Prepend the current TranslatePress language prefix to a root-relative URL.
 *
 * Detects the language prefix from the current request URI (e.g. /pt/ from /pt/oat-registry/)
 * and prepends it to the given path so links opened in new tabs preserve the language.
 *
 * @param string $url Root-relative URL (e.g. /oat-registry-detail/).
 * @return string URL with language prefix if applicable.
 */
function owc_oat_localize_url( $url ) {
    // Detect language prefix from multiple sources.
    $lang = '';

    // 1. TranslatePress global.
    global $TRP_LANGUAGE;
    if ( ! empty( $TRP_LANGUAGE ) && class_exists( 'TRP_Translate_Press' ) ) {
        $trp      = TRP_Translate_Press::get_trp_instance();
        $settings = $trp->get_component( 'settings' )->get_settings();
        $default  = $settings['default-language'] ?? 'en_US';
        if ( $TRP_LANGUAGE !== $default ) {
            // Map locale to URL slug (e.g. pt_BR -> pt).
            $slugs = $settings['url-slugs'] ?? array();
            $lang  = isset( $slugs[ $TRP_LANGUAGE ] ) ? $slugs[ $TRP_LANGUAGE ] : '';
        }
    }

    // 2. Fallback: detect from REQUEST_URI.
    if ( ! $lang ) {
        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
        if ( preg_match( '#^/([a-z]{2}(?:-[a-z]{2})?)/#i', $request_uri, $m ) ) {
            $default_lang = apply_filters( 'owc_oat_default_language', 'en' );
            if ( $m[1] !== $default_lang ) {
                $lang = $m[1];
            }
        }
    }

    if ( $lang && strpos( $url, '/' . $lang . '/' ) !== 0 ) {
        $url = '/' . $lang . rtrim( $url, '/' ) . '/';
    }

    return $url;
}


/**
 * Format a Unix timestamp or datetime string for display.
 *
 * @param mixed $value Unix timestamp or datetime string.
 * @return string Formatted date or empty string.
 */
function owc_oat_format_date( $value ) {
    if ( empty( $value ) ) {
        return '';
    }
    if ( is_numeric( $value ) ) {
        return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $value );
    }
    return $value;
}

/**
 * Format known timestamp fields in a remote API response.
 *
 * Applies owc_oat_format_date() to standard timestamp fields so remote mode
 * data matches the formatting applied in local mode.
 *
 * @param array $data Response data from the gateway.
 * @return array Data with timestamps formatted.
 */
function owc_oat_format_remote_timestamps( $data ) {
    $ts_fields = array( 'created_at', 'updated_at', 'expires_at' );

    // Format top-level entry timestamps.
    if ( isset( $data['entry'] ) && is_array( $data['entry'] ) ) {
        foreach ( $ts_fields as $f ) {
            if ( isset( $data['entry'][ $f ] ) ) {
                $data['entry'][ $f ] = owc_oat_format_date( $data['entry'][ $f ] );
            }
        }
    }

    // Format timeline timestamps.
    if ( isset( $data['timeline'] ) && is_array( $data['timeline'] ) ) {
        foreach ( $data['timeline'] as &$t ) {
            foreach ( $ts_fields as $f ) {
                if ( isset( $t[ $f ] ) ) {
                    $t[ $f ] = owc_oat_format_date( $t[ $f ] );
                }
            }
        }
        unset( $t );
    }

    // Format the send-back note's time.
    if ( isset( $data['changes_note']['created_at'] ) ) {
        $data['changes_note']['created_at'] = owc_oat_format_date( $data['changes_note']['created_at'] );
    }

    // Format timer timestamps.
    if ( isset( $data['timer'] ) && is_array( $data['timer'] ) ) {
        foreach ( $ts_fields as $f ) {
            if ( isset( $data['timer'][ $f ] ) ) {
                $data['timer'][ $f ] = owc_oat_format_date( $data['timer'][ $f ] );
            }
        }
    }

    // Format assignments/watched/my_entries arrays.
    foreach ( array( 'assignments', 'watched', 'my_entries' ) as $list_key ) {
        if ( isset( $data[ $list_key ] ) && is_array( $data[ $list_key ] ) ) {
            foreach ( $data[ $list_key ] as &$item ) {
                foreach ( $ts_fields as $f ) {
                    if ( isset( $item[ $f ] ) ) {
                        $item[ $f ] = owc_oat_format_date( $item[ $f ] );
                    }
                }
            }
            unset( $item );
        }
    }

    return $data;
}


/**
 * Labels the read-only field renderer uses for characters and regulation rules when this site cannot look them up
 * itself; on sites other than archivist they arrive with the request from the gateway.
 *
 * @param array|null $bundle A request bundle from owc_oat_get_entry() to take the labels from, or null to read them.
 * @return array{characters: array<string,array>, rules: array<int,string>}
 */
function owc_oat_readonly_lookups( $bundle = null ) {
    static $lookups = array( 'characters' => array(), 'rules' => array() );
    if ( is_array( $bundle ) ) {
        $lookups = array( 'characters' => array(), 'rules' => array() );
        foreach ( (array) ( $bundle['characters'] ?? array() ) as $uuid => $character ) {
            $lookups['characters'][ (string) $uuid ] = (array) $character;
        }
        foreach ( (array) ( $bundle['rules'] ?? array() ) as $rule ) {
            $rule = (array) $rule;
            $id   = (int) ( $rule['rule_id'] ?? $rule['id'] ?? 0 );
            if ( $id ) {
                $condition                 = (string) ( $rule['condition'] ?? $rule['condition_name'] ?? '' );
                $label                     = sprintf( '%s — %s', $rule['genre'] ?? '', $rule['category'] ?? '' );
                $lookups['rules'][ $id ] = '' !== $condition ? $label . ' — ' . $condition : $label;
            }
        }
    }
    return $lookups;
}


/**
 * A submitted field value made safe to store: a list (ticked boxes) becomes a JSON array of plain strings; anything
 * else keeps the HTML a post may hold.
 *
 * @param mixed $value Submitted value.
 * @return string
 */
function owc_oat_clean_meta_value( $value ) {
    if ( is_array( $value ) ) {
        return (string) wp_json_encode( array_values( array_map( 'sanitize_text_field', array_filter( $value, 'is_scalar' ) ) ) );
    }
    return wp_kses_post( (string) $value );
}


/**
 * Make a remote OAT gateway request.
 *
 * Sends POST with API key + user email headers for authentication.
 *
 * @param string $endpoint  Endpoint path (e.g. 'inbox', 'entry/42').
 * @param array  $body      Request body.
 * @return array|WP_Error   Response data or error.
 */
function owc_oat_request( $endpoint, $body = array() ) {
    $base = owc_get_remote_base( 'oat' );
    if ( empty( $base ) ) {
        return new WP_Error( 'oat_no_remote', 'OAT remote gateway URL is not configured.' );
    }

    $api_key = owc_get_remote_key( 'oat' );
    if ( empty( $api_key ) ) {
        return new WP_Error( 'oat_no_key', 'OAT remote API key is not configured.' );
    }

    $url = $base . 'oat/' . ltrim( $endpoint, '/' );

    $current_user = wp_get_current_user();
    $email = $current_user && $current_user->ID ? $current_user->user_email : '';

    $headers = array(
        'Content-Type'      => 'application/json',
        'x-api-key'         => $api_key,
        'x-oat-user-email'  => $email,
    );

    // Include player_id if available (for JIT provisioning on remote).
    if ( defined( 'OWC_PLAYER_ID_META_KEY' ) && $current_user && $current_user->ID ) {
        $player_id = get_user_meta( $current_user->ID, OWC_PLAYER_ID_META_KEY, true );
        if ( $player_id ) {
            $headers['x-oat-player-id'] = $player_id;
        }
    }

    $response = wp_remote_post( $url, array(
        'timeout' => 30,
        'headers' => $headers,
        'body'    => wp_json_encode( $body ),
    ) );

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code = wp_remote_retrieve_response_code( $response );
    $raw  = wp_remote_retrieve_body( $response );
    $data = json_decode( $raw, true );

    if ( $code !== 200 ) {
        $message = isset( $data['message'] ) ? $data['message'] : 'OAT gateway request failed.';
        return new WP_Error( 'oat_api_error', $message, array( 'status' => $code ) );
    }

    if ( ! is_array( $data ) ) {
        return new WP_Error( 'oat_api_error', 'Invalid JSON response from OAT gateway.' );
    }

    return $data;
}


function owc_oat_get_domains() {
    if ( owc_oat_is_local() ) {
        $domains = OAT_Domain_Registry::get_all();
        $out = array();
        foreach ( $domains as $slug => $domain ) {
            $out[] = array(
                'slug'  => $slug,
                'label' => $domain['label'],
            );
        }
        return $out;
    }

    return owc_oat_request( 'domains' );
}

function owc_oat_get_forms_for_domain( $domain_slug ) {
    if ( owc_oat_is_local() ) {
        if ( ! class_exists( 'OAT_Domain_Registry' ) ) {
            return array();
        }
        $forms = OAT_Domain_Registry::get_forms( $domain_slug );
        $out = array();
        foreach ( $forms as $form ) {
            // Check form-level access restrictions
            if ( ! owc_oat_user_can_access_form( $form->slug ) ) {
                continue;
            }
            $out[] = array(
                'id'    => (int) $form->id,
                'slug'  => $form->slug,
                'label' => $form->label,
            );
        }
        return $out;
    }

    $result = owc_oat_request( 'domain-forms', array( 'domain' => $domain_slug ) );
    if ( is_wp_error( $result ) ) {
        return array();
    }
    return isset( $result['forms'] ) ? $result['forms'] : ( is_array( $result ) ? $result : array() );
}

/**
 * Check if the current user can access a specific form.
 *
 * Forms can define access rules via the owc_oat_form_access_rules filter.
 * Default: all forms are accessible.
 *
 * @param string $form_slug The form slug.
 * @return bool
 */
function owc_oat_user_can_access_form( $form_slug ) {
    // ca_manage_satellites: only HST/CM of non-probationary, non-satellite chronicles
    if ( $form_slug === 'ca_manage_satellites' ) {
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }
        if ( ! function_exists( '_owc_asc_get_user_entity_entries' ) ) {
            return false;
        }
        $entries = _owc_asc_get_user_entity_entries( 'chronicle', array( 'HST', 'CM' ) );
        if ( empty( $entries ) ) {
            return false;
        }
        // Check if any of the user's chronicles are non-probationary and non-satellite
        $chronicles = function_exists( 'owc_get_chronicles' ) ? owc_get_chronicles() : array();
        if ( is_wp_error( $chronicles ) || ! is_array( $chronicles ) ) {
            return false;
        }
        $chron_lookup = array();
        foreach ( $chronicles as $c ) {
            $chron_lookup[ $c['slug'] ] = $c;
        }
        foreach ( $entries as $entry ) {
            $slug = $entry['slug'];
            if ( ! isset( $chron_lookup[ $slug ] ) ) {
                continue;
            }
            $c = $chron_lookup[ $slug ];
            $is_probationary = ! empty( $c['chronicle_probationary'] ) && $c['chronicle_probationary'] !== '0';
            $is_satellite = ! empty( $c['chronicle_satellite'] ) && $c['chronicle_satellite'] !== '0';
            if ( ! $is_probationary && ! $is_satellite ) {
                return true;
            }
        }
        return false;
    }

    return true;
}


/**
 * Get the current user's inbox data.
 *
 * @param string $domain_filter Optional domain slug to filter assignments.
 * @return array|WP_Error { assignments, watched, my_entries, user_map }
 */
function owc_oat_get_inbox( $domain_filter = '' ) {
    if ( owc_oat_is_local() ) {
        $user_id = get_current_user_id();

        // Assigned to Me: the open requests waiting on this user.
        $waiting     = owc_oat_entries_waiting_on( $user_id, $domain_filter );
        $assignments = array();
        foreach ( $waiting as $we ) {
            $eid           = (int) $we->id;
            $assignments[] = array(
                'entry_id'      => $eid,
                'domain'        => $we->domain,
                'domain_label'  => OAT_Domain_Registry::get_label( $we->domain ) ?: $we->domain,
                'originator_id' => (int) $we->originator_id,
                'status'        => $we->status,
                'current_step'  => $we->current_step,
                'title'         => class_exists( 'OAT_Entry_Meta' ) ? (string) OAT_Entry_Meta::get( $eid, 'title' ) : '',
                'created_at'    => owc_oat_format_date( $we->created_at ),
            );
        }

        // Watched entries.
        $watched_raw = OAT_Watcher::for_user( $user_id );
        $watched = array();
        foreach ( $watched_raw as $w ) {
            $watched[] = array(
                'entry_id'      => (int) $w->entry_id,
                'domain'        => $w->domain,
                'domain_label'  => OAT_Domain_Registry::get_label( $w->domain ) ?: $w->domain,
                'originator_id' => isset( $w->originator_id ) ? (int) $w->originator_id : 0,
                'status'        => $w->status,
                'current_step'  => isset( $w->current_step ) ? $w->current_step : '',
                'title'         => isset( $w->title ) ? $w->title : '',
                'updated_at'    => owc_oat_format_date( isset( $w->updated_at ) ? $w->updated_at : '' ),
            );
        }

        // User's own entries (recent).
        $my_entries_raw = OAT_Entry::for_originator( $user_id );
        $my_entries = array();
        foreach ( $my_entries_raw as $e ) {
            $my_entries[] = array(
                'entry_id'      => (int) $e->id,
                'domain'        => $e->domain,
                'domain_label'  => OAT_Domain_Registry::get_label( $e->domain ) ?: $e->domain,
                'originator_id' => (int) $e->originator_id,
                'status'        => $e->status,
                'current_step'  => $e->current_step,
                'created_at'    => owc_oat_format_date( $e->created_at ),
            );
        }

        // Build user map.
        $user_ids = array();
        foreach ( $waiting as $we ) {
            $user_ids[] = (int) $we->originator_id;
        }
        foreach ( $watched_raw as $w ) {
            if ( isset( $w->originator_id ) ) {
                $user_ids[] = (int) $w->originator_id;
            }
        }
        $user_ids[] = $user_id;
        $user_ids = array_unique( array_filter( $user_ids ) );

        $user_map = array();
        foreach ( $user_ids as $uid ) {
            $u = get_userdata( $uid );
            if ( $u ) {
                $user_map[ $uid ] = $u->display_name;
            }
        }

        return array(
            'assignments' => $assignments,
            'watched'     => $watched,
            'my_entries'  => $my_entries,
            'user_map'    => $user_map,
        );
    }

    $body = array();
    if ( $domain_filter ) {
        $body['domain'] = $domain_filter;
    }
    $result = owc_oat_request( 'inbox', $body );
    return is_wp_error( $result ) ? $result : owc_oat_format_remote_timestamps( $result );
}


/**
 * Get paginated entry list.
 *
 * @param array $args { domain, status, page, per_page }
 * @return array|WP_Error { entries, total, page, per_page, user_map }
 */
function owc_oat_get_entries( $args = array() ) {
    if ( owc_oat_is_local() ) {
        $page     = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
        $per_page = isset( $args['per_page'] ) ? max( 1, min( 100, (int) $args['per_page'] ) ) : 20;
        $domain   = isset( $args['domain'] ) ? $args['domain'] : '';
        $status   = isset( $args['status'] ) ? $args['status'] : '';

        $offset = ( $page - 1 ) * $per_page;

        $query_args = array(
            'per_page' => $per_page,
            'offset'   => $offset,
        );
        if ( $domain ) {
            $query_args['domain'] = $domain;
        }
        if ( $status ) {
            $query_args['status'] = $status;
        }

        $entries_raw = OAT_Entry::all( $query_args );
        $total       = OAT_Entry::count( $query_args );

        $entries  = array();
        $user_ids = array();
        foreach ( $entries_raw as $e ) {
            $entries[] = array(
                'id'            => (int) $e->id,
                'domain'        => $e->domain,
                'domain_label'  => OAT_Domain_Registry::get_label( $e->domain ) ?: $e->domain,
                'status'        => $e->status,
                'current_step'  => $e->current_step,
                'originator_id' => (int) $e->originator_id,
                'created_at'    => owc_oat_format_date( $e->created_at ),
                'updated_at'    => owc_oat_format_date( $e->updated_at ),
            );
            $user_ids[] = (int) $e->originator_id;
        }

        $user_ids = array_unique( array_filter( $user_ids ) );
        $user_map = array();
        foreach ( $user_ids as $uid ) {
            $u = get_userdata( $uid );
            if ( $u ) {
                $user_map[ $uid ] = $u->display_name;
            }
        }

        return array(
            'entries'  => $entries,
            'total'    => (int) $total,
            'page'     => $page,
            'per_page' => $per_page,
            'user_map' => $user_map,
        );
    }

    $result = owc_oat_request( 'entries', $args );
    if ( is_wp_error( $result ) ) {
        return $result;
    }
    // Format timestamps in each entry row.
    if ( isset( $result['entries'] ) && is_array( $result['entries'] ) ) {
        foreach ( $result['entries'] as &$e ) {
            if ( isset( $e['created_at'] ) ) {
                $e['created_at'] = owc_oat_format_date( $e['created_at'] );
            }
            if ( isset( $e['updated_at'] ) ) {
                $e['updated_at'] = owc_oat_format_date( $e['updated_at'] );
            }
        }
        unset( $e );
    }
    return $result;
}


/**
 * Get full entry detail bundle.
 *
 * @param int $entry_id
 * @return array|WP_Error Full entry bundle.
 */
function owc_oat_get_entry( $entry_id ) {
    if ( owc_oat_is_local() ) {
        $entry = OAT_Entry::find( $entry_id );
        if ( ! $entry ) {
            return new WP_Error( 'oat_not_found', 'Entry not found.', array( 'status' => 404 ) );
        }

        $user_id = get_current_user_id();
        if ( ! owc_oat_user_can_view_entry( $entry, $user_id ) ) {
            return new WP_Error( 'oat_forbidden', 'You do not have access to this request.', array( 'status' => 403 ) );
        }

        // Meta.
        $meta_raw = OAT_Entry_Meta::all( $entry_id );
        $meta = array();
        foreach ( $meta_raw as $m ) {
            $meta[ $m->meta_key ] = $m->meta_value;
        }

        // Assignees.
        $assignees_raw = OAT_Assignee::for_entry( $entry_id );
        $assignees = array();
        foreach ( $assignees_raw as $a ) {
            $assignees[] = array(
                'user_id' => (int) $a->user_id,
                'step'    => $a->step,
                'status'  => $a->status,
            );
        }

        // Timeline: for the request's staff and up, to the tier their capabilities give them; players see none.
        $tier         = owc_oat_entry_timeline_tier( $entry, $user_id );
        $timeline_raw = '' === $tier ? array() : OAT_Timeline::for_entry( $entry_id, $tier );
        $timeline = array();
        foreach ( $timeline_raw as $t ) {
            $timeline[] = array(
                'action_type'     => $t->action_type,
                'actor_id'        => owc_oat_timeline_actor_id( $t ),
                'step'            => $t->step,
                'visibility_tier' => $t->visibility_tier,
                'note'            => $t->note,
                'created_at'      => owc_oat_format_date( $t->created_at ),
            );
        }

        // Rules.
        $rules = array_map( 'owc_oat_linked_rule_row', OAT_Entry_Rule::for_entry( $entry_id ) );

        // Timer.
        $timer_raw = OAT_Timer::active_for_entry( $entry_id );
        $timer = null;
        if ( $timer_raw ) {
            $timer = array(
                'type'          => (string) ( $timer_raw->auto_action ?? '' ),
                'auto_action'   => (string) ( $timer_raw->auto_action ?? '' ),
                'bump_count'    => (int) ( $timer_raw->bump_count ?? 0 ),
                'bump_required' => (int) ( $timer_raw->bump_required ?? 0 ),
                'expires_at'    => owc_oat_format_date( $timer_raw->expires_at ),
                'status'        => $timer_raw->status,
            );
        }

        // BBP eligible.
        $bbp_eligible = false;
        if ( (int) $entry->originator_id === $user_id ) {
            $bbp_eligible = OAT_Timer_Engine::check_bbp_eligible( $entry_id );
        }

        // Available actions.
        $available_actions = owc_oat_compute_available_actions( $entry, $user_id, $assignees_raw );

        // Is watching.
        $watchers_raw = OAT_Watcher::for_entry( $entry_id );
        $is_watching = false;
        foreach ( $watchers_raw as $w ) {
            if ( (int) $w->user_id === $user_id ) {
                $is_watching = true;
                break;
            }
        }

        // Step label.
        $step_config = OAT_Workflow_Engine::get_step_config( $entry );
        $step_label = $step_config && isset( $step_config['label'] ) ? $step_config['label'] : $entry->current_step;

        // User map.
        $user_ids = array( (int) $entry->originator_id, $user_id );
        foreach ( $assignees_raw as $a ) {
            $user_ids[] = (int) $a->user_id;
        }
        foreach ( $timeline_raw as $t ) {
            $user_ids[] = owc_oat_timeline_actor_id( $t );
        }
        foreach ( $watchers_raw as $w ) {
            $user_ids[] = (int) $w->user_id;
        }

        // The latest send-back note, for the filer and the request's staff, while the request is back at Submission.
        $changes_note = ( (int) $entry->originator_id === $user_id || '' !== $tier ) ? owc_oat_entry_changes_note( $entry ) : null;
        if ( $changes_note ) {
            $user_ids[]                 = $changes_note['actor_id'];
            $changes_note['created_at'] = owc_oat_format_date( $changes_note['created_at'] );
        }

        $user_ids = array_unique( array_filter( $user_ids ) );
        $user_map = array();
        foreach ( $user_ids as $uid ) {
            $u = get_userdata( $uid );
            if ( $u ) {
                $user_map[ $uid ] = $u->display_name;
            }
        }

        // D4: Relationships (me-too, parent/child links).
        $relationships = array( 'children' => array(), 'parents' => array() );
        if ( class_exists( 'OAT_Entry_Relationship' ) ) {
            $children_raw = OAT_Entry_Relationship::for_source( $entry_id );
            foreach ( $children_raw as $rel ) {
                $relationships['children'][] = array(
                    'entry_id' => (int) $rel->target_entry_id,
                    'type'     => $rel->relationship_type,
                );
            }
            $parents_raw = OAT_Entry_Relationship::for_target( $entry_id );
            foreach ( $parents_raw as $rel ) {
                $relationships['parents'][] = array(
                    'entry_id' => (int) $rel->source_entry_id,
                    'type'     => $rel->relationship_type,
                );
            }
        }

        return array(
            'entry'             => array(
                'id'              => (int) $entry->id,
                'domain'          => $entry->domain,
                'form_slug'       => isset( $entry->form_slug ) ? $entry->form_slug : '',
                'status'          => $entry->status,
                'current_step'    => $entry->current_step,
                'originator_id'   => (int) $entry->originator_id,
                'chronicle_slug'  => isset( $entry->chronicle_slug ) ? $entry->chronicle_slug : '',
                'coordinator_genre' => isset( $entry->coordinator_genre ) ? $entry->coordinator_genre : '',
                'character_id'    => isset( $entry->character_id ) ? (int) $entry->character_id : 0,
                'created_at'      => owc_oat_format_date( $entry->created_at ),
                'updated_at'      => owc_oat_format_date( $entry->updated_at ),
            ),
            'meta'              => $meta,
            'characters'        => owc_oat_entry_character_map( $meta ),
            'viewer_id'         => $user_id,
            'assignees'         => $assignees,
            'timeline'          => $timeline,
            'changes_note'      => $changes_note,
            'rules'             => $rules,
            'timer'             => $timer,
            'bbp_eligible'      => $bbp_eligible,
            'available_actions' => $available_actions,
            'is_watching'       => $is_watching,
            'domain_label'      => OAT_Domain_Registry::get_label( $entry->domain ) ?: $entry->domain,
            'step_label'        => $step_label,
            'user_map'          => $user_map,
            'relationships'     => $relationships,
        );
    }

    $result = owc_oat_request( 'entry/' . (int) $entry_id );
    return is_wp_error( $result ) ? $result : owc_oat_format_remote_timestamps( $result );
}


/**
 * Submit a new OAT entry.
 *
 * @param array $data {
 *     domain, title, description, chronicle_slug, coordinator_genre,
 *     rules (array of rule IDs), meta (array of key => value), note
 * }
 * @return array|WP_Error { entry_id, status, message }
 */
function owc_oat_submit( $data ) {
    if ( owc_oat_is_local() ) {
        $user_id = get_current_user_id();
        $domain_slug = isset( $data['domain'] ) ? sanitize_text_field( $data['domain'] ) : '';

        if ( empty( $domain_slug ) ) {
            return new WP_Error( 'oat_missing_domain', 'Domain is required.' );
        }

        $domain = OAT_Domain_Registry::get( $domain_slug );
        if ( ! $domain ) {
            return new WP_Error( 'oat_invalid_domain', 'Invalid domain: ' . $domain_slug );
        }

        $entry_data = array(
            'domain'        => $domain_slug,
            'status'        => 'pending',
            'current_step'  => 'submit',
            'originator_id' => $user_id,
        );

        if ( ! empty( $data['form_slug'] ) ) {
            $entry_data['form_slug'] = sanitize_text_field( $data['form_slug'] );
        }
        if ( ! empty( $data['chronicle_slug'] ) ) {
            $entry_data['chronicle_slug'] = sanitize_text_field( $data['chronicle_slug'] );
        }
        if ( ! empty( $data['coordinator_genre'] ) ) {
            $entry_data['coordinator_genre'] = sanitize_text_field( $data['coordinator_genre'] );
        }

        $entry_id = OAT_Entry::create( $entry_data );
        if ( ! $entry_id ) {
            return new WP_Error( 'oat_create_failed', 'Failed to create entry.' );
        }

        // Build meta.
        $meta = array();
        if ( ! empty( $data['title'] ) ) {
            $meta['title'] = sanitize_text_field( $data['title'] );
        }
        if ( ! empty( $data['description'] ) ) {
            $meta['description'] = wp_kses_post( $data['description'] );
        }
        if ( ! empty( $data['meta'] ) && is_array( $data['meta'] ) ) {
            foreach ( $data['meta'] as $key => $value ) {
                $safe_key = sanitize_key( $key );
                if ( $safe_key !== '' ) {
                    $meta[ $safe_key ] = owc_oat_clean_meta_value( $value );
                }
            }
        }

        // Resolve character UUID → character_id and coordinator_genre on the entry.
        if ( class_exists( 'OAT_Character' ) ) {
            $char_uuid = '';
            // Check common character field keys.
            foreach ( array( 'character_name', 'character' ) as $ck ) {
                if ( ! empty( $meta[ $ck ] ) ) {
                    $char_uuid = $meta[ $ck ];
                    break;
                }
            }
            if ( $char_uuid ) {
                $char = OAT_Character::find_by_uuid( $char_uuid );
                if ( $char ) {
                    $update_entry = array();
                    if ( empty( $entry_data['character_id'] ) ) {
                        $update_entry['character_id'] = (int) $char->id;
                    }
                    if ( empty( $entry_data['coordinator_genre'] ) ) {
                        // Use explicit coordinator_genre from meta if set, otherwise derive from creature type.
                        if ( ! empty( $meta['coordinator_genre'] ) ) {
                            $update_entry['coordinator_genre'] = strtolower( $meta['coordinator_genre'] );
                        } elseif ( ! empty( $char->creature_type ) ) {
                            $update_entry['coordinator_genre'] = strtolower( $char->creature_type );
                        }
                    }
                    if ( ! empty( $update_entry ) ) {
                        OAT_Entry::update( $entry_id, $update_entry );
                    }
                    // Also store character_id in meta for downstream use.
                    if ( empty( $meta['character_id'] ) ) {
                        $meta['character_id'] = (string) $char->id;
                    }
                }
            }
        }

        // Resolve coordinator_genre and item_description from linked custom content (Learn CC).
        if ( ! empty( $meta['learned_content'] ) && class_exists( 'OAT_Entry' ) ) {
            $cc_data = is_string( $meta['learned_content'] ) ? json_decode( $meta['learned_content'], true ) : $meta['learned_content'];
            if ( is_array( $cc_data ) && ! empty( $cc_data['entry_id'] ) ) {
                $cc_entry = OAT_Entry::find( (int) $cc_data['entry_id'] );
                if ( $cc_entry ) {
                    // Set coordinator_genre from the CC entry if not already set.
                    if ( ! empty( $cc_entry->coordinator_genre ) ) {
                        OAT_Entry::update( $entry_id, array( 'coordinator_genre' => $cc_entry->coordinator_genre ) );
                    }
                    // Set item_description from CC item label (fixes "form name" display).
                    if ( ! empty( $cc_data['label'] ) && empty( $meta['item_description'] ) ) {
                        $meta['item_description'] = sanitize_text_field( $cc_data['label'] );
                        OAT_Entry_Meta::set( $entry_id, 'item_description', $meta['item_description'] );
                    }
                }
            }
        }

        // Attach regulation rules.
        if ( ! empty( $data['rules'] ) && is_array( $data['rules'] ) ) {
            foreach ( $data['rules'] as $rule_id ) {
                if ( is_array( $rule_id ) ) {
                    // Free-text rule: store as item_description if not already set.
                    if ( isset( $rule_id['text'] ) && empty( $meta['item_description'] ) ) {
                        $meta['item_description'] = sanitize_text_field( $rule_id['text'] );
                        OAT_Entry_Meta::set( $entry_id, 'item_description', $meta['item_description'] );
                    }
                    continue;
                }
                $rule_id = (int) $rule_id;
                if ( $rule_id > 0 ) {
                    OAT_Entry_Rule::create( $entry_id, $rule_id );
                    // Auto-set item_description from the first linked rule if not already set.
                    if ( empty( $meta['item_description'] ) && class_exists( 'OAT_Regulation_Rule' ) ) {
                        $rule_obj = OAT_Regulation_Rule::find( $rule_id );
                        if ( $rule_obj ) {
                            $parts = array_filter( array( $rule_obj->category, $rule_obj->subcategory, $rule_obj->condition_name ) );
                            $meta['item_description'] = implode( ': ', $parts );
                            OAT_Entry_Meta::set( $entry_id, 'item_description', $meta['item_description'] );
                        }
                    }
                }
            }

            // Set regulation meta from rules.
            owc_oat_set_regulation_meta( $entry_id, $data['rules'] );
        }

        // Fire submit action through workflow engine.
        $result = OAT_Workflow_Engine::process_action( $entry_id, 'submit', $user_id, array(
            'note' => isset( $data['note'] ) ? sanitize_textarea_field( $data['note'] ) : '',
            'meta' => $meta,
        ) );

        if ( is_wp_error( $result ) ) {
            owc_oat_cancel_refused_submission( $entry_id, $user_id, $result );
            return $result;
        }

        // Auto-watch the originator.
        OAT_Watcher::add( $entry_id, $user_id, $user_id );

        $entry = OAT_Entry::find( $entry_id );
        return array(
            'entry_id' => $entry_id,
            'status'   => $entry ? $entry->status : 'pending',
            'message'  => 'Entry created successfully.',
        );
    }

    return owc_oat_request( 'submit', $data );
}


/**
 * Execute a workflow action on an entry.
 *
 * @param int    $entry_id
 * @param string $action_type
 * @param string $note
 * @param array  $extra_data  Optional extra data (vote_reference, additional_seconds, target_user_id).
 * @return array|WP_Error { entry_id, status, step, message }
 */
function owc_oat_execute_action( $entry_id, $action_type, $note = '', $extra_data = array() ) {
    if ( owc_oat_is_local() ) {
        $user_id = get_current_user_id();

        $entry = OAT_Entry::find( $entry_id );
        if ( ! $entry ) {
            return new WP_Error( 'oat_not_found', 'Entry not found.', array( 'status' => 404 ) );
        }
        if ( ! owc_oat_user_can_take_action( $entry, $user_id, $action_type ) ) {
            return new WP_Error( 'oat_forbidden', 'You cannot take that action on this request.', array( 'status' => 403 ) );
        }

        // Admin Edit: save meta fields without advancing workflow.
        if ( 'admin_edit' === $action_type ) {
            if ( ! function_exists( 'owc_oat_is_super_user' ) || ! owc_oat_is_super_user( $user_id ) ) {
                return new WP_Error( 'oat_forbidden', 'Admin edit requires archivist or admin privileges.' );
            }
            if ( empty( $note ) ) {
                return new WP_Error( 'oat_missing_note', 'A reason for the edit is required.' );
            }

            // Collect meta from POST.
            $updated_keys = array();
            foreach ( $_POST as $k => $v ) {
                if ( strpos( $k, 'oat_meta_' ) === 0 ) {
                    $meta_key = sanitize_key( substr( $k, 9 ) );
                    if ( $meta_key ) {
                        $old_val = OAT_Entry_Meta::get( $entry_id, $meta_key );
                        $new_val = wp_kses_post( $v );
                        if ( $old_val !== $new_val ) {
                            OAT_Entry_Meta::set( $entry_id, $meta_key, $new_val );
                            $updated_keys[] = $meta_key;
                        }
                    }
                }
            }

            // If character field was changed, re-resolve character_id on the entry.
            $char_changed = array_intersect( array( 'character_name', 'character' ), $updated_keys );
            if ( ! empty( $char_changed ) && class_exists( 'OAT_Character' ) ) {
                $char_key      = reset( $char_changed );
                $new_char_uuid = OAT_Entry_Meta::get( $entry_id, $char_key );
                if ( $new_char_uuid ) {
                    $new_char = OAT_Character::find_by_uuid( $new_char_uuid );
                    if ( $new_char && (int) $new_char->id !== (int) $entry->character_id ) {
                        OAT_Entry::update( $entry_id, array( 'character_id' => (int) $new_char->id ) );
                        $updated_keys[] = 'character_id';
                    }
                }
            }

            // Log timeline.
            $changes_note = $note;
            if ( ! empty( $updated_keys ) ) {
                $changes_note .= ' [Fields: ' . implode( ', ', $updated_keys ) . ']';
            }
            OAT_Timeline::append( array(
                'entry_id'        => $entry_id,
                'action_type'     => 'record',
                'actor_id'        => $user_id,
                'step'            => $entry->current_step,
                'visibility_tier' => OAT_Constants::TIER_ARCHIVIST,
                'note'            => 'Admin edit: ' . $changes_note,
            ) );

            // Touch entry timestamp via a status re-set (updated_at alone is not in allowed list).
            OAT_Entry::update_status( $entry_id, $entry->status, $entry->current_step );

            return array(
                'entry_id' => $entry_id,
                'status'   => $entry->status,
                'step'     => $entry->current_step,
                'message'  => 'Entry updated. ' . count( $updated_keys ) . ' field(s) changed.',
            );
        }

        $action_data = array_merge( $extra_data, array( 'note' => $note ) );
        $result = OAT_Workflow_Engine::process_action( $entry_id, $action_type, $user_id, $action_data );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $entry = OAT_Entry::find( $entry_id );
        return array(
            'entry_id' => $entry_id,
            'status'   => $entry ? $entry->status : '',
            'step'     => $entry ? $entry->current_step : '',
            'message'  => 'Action executed successfully.',
        );
    }

    $body = array(
        'entry_id' => (int) $entry_id,
        'action'   => $action_type,
        'note'     => $note,
    );
    if ( ! empty( $extra_data ) ) {
        $body['data'] = $extra_data;
    }
    return owc_oat_request( 'action', $body );
}


/**
 * Toggle watch on an entry.
 *
 * @param int    $entry_id
 * @param string $watch_action 'add' or 'remove'.
 * @return array|WP_Error { entry_id, watching }
 */
function owc_oat_toggle_watch( $entry_id, $watch_action = 'toggle' ) {
    if ( owc_oat_is_local() ) {
        $user_id = get_current_user_id();

        $entry = OAT_Entry::find( $entry_id );
        if ( ! $entry ) {
            return new WP_Error( 'oat_not_found', 'Entry not found.', array( 'status' => 404 ) );
        }

        // Auto-detect: if already watching, remove; otherwise add.
        if ( $watch_action === 'toggle' ) {
            $watch_action = OAT_Watcher::is_watching( $entry_id, $user_id ) ? 'remove' : 'add';
        }
        if ( 'remove' !== $watch_action && ! owc_oat_user_can_view_entry( $entry, $user_id ) ) {
            return new WP_Error( 'oat_forbidden', 'You do not have access to this request.', array( 'status' => 403 ) );
        }

        if ( $watch_action === 'remove' ) {
            OAT_Watcher::remove( $entry_id, $user_id );
            $watching = false;
        } else {
            OAT_Watcher::add( $entry_id, $user_id, $user_id );
            $watching = true;
        }

        return array(
            'entry_id' => $entry_id,
            'watching' => $watching,
        );
    }

    return owc_oat_request( 'watch', array(
        'entry_id' => (int) $entry_id,
        'action'   => $watch_action,
    ) );
}


/**
 * Search regulation rules for autocomplete.
 *
 * @param string $term  Search term (min 2 chars).
 * @param int    $limit Max results.
 * @return array|WP_Error List of rule results.
 */
function owc_oat_search_rules( $term, $limit = 20 ) {
    if ( owc_oat_is_local() ) {
        $results = OAT_Regulation_Rule::search( $term );
        $out = array();
        foreach ( $results as $rule ) {
            $ref   = isset( $rule->section_ref ) && $rule->section_ref ? $rule->section_ref : '';
            $name  = $rule->condition_name ? $rule->condition_name : $rule->subcategory;
            $label = $ref
                ? sprintf( '[%s] %s — %s — %s', $ref, $rule->genre, $rule->category, $name )
                : sprintf( '%s — %s — %s', $rule->genre, $rule->category, $name );
            $out[] = array(
                'id'          => (int) $rule->id,
                'label'       => $label,
                'value'       => $label,
                'section_ref' => $ref,
                'genre'       => $rule->genre,
                'category'    => $rule->category,
                'subcategory' => $rule->subcategory,
                'condition'   => $rule->condition_name,
                'pc_level'    => $rule->pc_level,
                'npc_level'   => $rule->npc_level,
                'coordinator' => $rule->controlling_coordinator,
                'elevation'   => (int) $rule->elevation,
            );
        }
        return $out;
    }

    return owc_oat_request( 'rules/search', array(
        'q'     => $term,
        'limit' => $limit,
    ) );
}


/**
 * Get form field definitions for a domain + context.
 *
 * Local mode: queries OAT_Form_Field model directly.
 * Remote mode: calls gateway /oat/form-fields endpoint.
 *
 * Falls back to legacy get_meta_keys() if oat_form_fields table has no rows
 * for the requested domain (backward compat during migration).
 *
 * @param string $domain_slug Domain slug.
 * @param string $context     Context: 'submit', 'review', 'escalate', 'resolve'.
 * @return array Array of field definition arrays.
 */
function owc_oat_get_form_fields( $domain_slug, $context = 'submit' ) {
    if ( owc_oat_is_local() ) {
        // Try DB-driven fields first.
        if ( class_exists( 'OAT_Form_Field' ) ) {
            $fields = OAT_Form_Field::get_fields( $domain_slug, $context );
            if ( ! empty( $fields ) ) {
                return $fields;
            }
        }

        // Fallback: legacy get_meta_keys() for domains not yet seeded.
        if ( 'submit' === $context && class_exists( 'OAT_Domain_Registry' ) ) {
            $domain = OAT_Domain_Registry::get_php_domain( $domain_slug );
            if ( $domain && method_exists( $domain, 'get_meta_keys' ) ) {
                $meta_keys = $domain->get_meta_keys();
                $fields = array();
                $order = 10;
                foreach ( $meta_keys as $key => $config ) {
                    $fields[] = array(
                        'key'         => $key,
                        'type'        => isset( $config['type'] ) ? $config['type'] : 'text',
                        'label'       => isset( $config['label'] ) ? $config['label'] : ucfirst( str_replace( '_', ' ', $key ) ),
                        'required'    => isset( $config['required'] ) ? (bool) $config['required'] : false,
                        'sort_order'  => $order,
                        'options'     => isset( $config['options'] ) ? $config['options'] : null,
                        'condition'   => isset( $config['condition'] ) ? $config['condition'] : null,
                        'placeholder' => isset( $config['placeholder'] ) ? $config['placeholder'] : '',
                        'help_text'   => isset( $config['description'] ) ? $config['description'] : null,
                        'default'     => isset( $config['default'] ) ? $config['default'] : '',
                        'validation'  => null,
                        'attributes'  => isset( $config['attributes'] ) ? $config['attributes'] : null,
                    );
                    $order += 10;
                }
                return $fields;
            }
        }

        return array();
    }

    // Remote mode: call the gateway.
    $result = owc_oat_request( 'form-fields', array(
        'domain'  => $domain_slug,
        'context' => $context,
    ) );

    if ( is_wp_error( $result ) ) {
        return array();
    }

    return isset( $result['fields'] ) ? $result['fields'] : array();
}

/**
 * Legacy wrapper — calls owc_oat_get_form_fields with 'submit' context.
 *
 * @param string $domain_slug
 * @return array
 */
function owc_oat_get_domain_fields( $domain_slug ) {
    return owc_oat_get_form_fields( $domain_slug, 'submit' );
}


/**
 * Compute available actions for a user on an entry.
 *
 * Used in local mode when OAT_Page_Entry class is not loaded.
 * Mirrors the gateway handler logic.
 *
 * @param object $entry
 * @param int    $user_id
 * @param array  $assignees Raw assignee objects.
 * @return array
 */
function owc_oat_compute_available_actions( $entry, $user_id, $assignees ) {
    $actions = array();

    if ( OAT_Constants::is_terminal_status( $entry->status ) ) {
        if ( $entry->status === OAT_Constants::STATUS_DENIED ) {
            if ( class_exists( 'OAT_Authorization' ) && OAT_Authorization::check( OAT_Constants::CAP_EXEC_OVERSIGHT ) ) {
                $actions[] = 'council_override';
            }
        }
        // Admin edit available even on terminal entries for data cleanup.
        if ( function_exists( 'owc_oat_is_super_user' ) && owc_oat_is_super_user( $user_id ) ) {
            $actions[] = 'admin_edit';
        }
        return $actions;
    }

    // Check explicit assignee row.
    $is_assignee = false;
    foreach ( $assignees as $a ) {
        if ( (int) $a->user_id === $user_id && $a->step === $entry->current_step && $a->status === 'pending' ) {
            $is_assignee = true;
            break;
        }
    }

    // Role-path-based: user holds the ASC role matching the step's assignee_role.
    if ( ! $is_assignee ) {
        $is_assignee = owc_oat_user_can_act_on_step( $entry, $user_id );
    }

    // Submission is the filer's own step: being assigned there (a request sent back) gives Resubmit, not a reviewer's buttons.
    if ( $is_assignee && 'submit' !== $entry->current_step ) {
        $actions[] = 'approve';
        $actions[] = 'deny';
        $actions[] = 'request_changes';
        $actions[] = 'reassign';
        $actions[] = 'delegate';
    }

    if ( (int) $entry->originator_id === $user_id ) {
        $actions[] = 'cancel';
        $actions[] = 'bump';
        // Originator can resubmit when entry is sent back to submit step.
        if ( $entry->current_step === 'submit' && $entry->status === 'pending' ) {
            $actions[] = 'submit';
        }
        // Self-approve: originator at archivist step with self-approve privilege.
        if ( $entry->current_step === 'archivist' && ! in_array( 'approve', $actions, true ) && owc_oat_can_self_approve( $user_id ) ) {
            $actions[] = 'approve';
            $actions[] = 'deny';
            $actions[] = 'request_changes';
        }
    }

    if ( class_exists( 'OAT_Authorization' ) && OAT_Authorization::check( OAT_Constants::CAP_EXEC_OVERSIGHT ) ) {
        $actions[] = 'hold';
        $actions[] = 'timer_extend';
    }

    if ( $entry->status === OAT_Constants::STATUS_HELD && ( $is_assignee || ( class_exists( 'OAT_Authorization' ) && OAT_Authorization::check( OAT_Constants::CAP_EXEC_OVERSIGHT ) ) ) ) {
        $actions[] = 'resume';
    }

    if ( $is_assignee && class_exists( 'OAT_Authorization' ) && OAT_Authorization::check( OAT_Constants::CAP_ARCHIVIST ) ) {
        $actions[] = 'record';
    }

    // Admin edit: WP Admin or exec/archivist/coordinator can edit any entry's meta.
    if ( function_exists( 'owc_oat_is_super_user' ) && owc_oat_is_super_user( $user_id ) ) {
        $actions[] = 'admin_edit';
    }

    return array_unique( $actions );
}

/**
 * Get a user's cached ASC role paths, lowercase-normalized.
 *
 * @param int $user_id WordPress user ID.
 * @return array Array of lowercase role path strings.
 */
function owc_oat_get_user_asc_roles( $user_id ) {
    if ( ! defined( 'OWC_ASC_CACHE_KEY' ) ) {
        return array();
    }
    $cached = get_user_meta( $user_id, OWC_ASC_CACHE_KEY, true );
    if ( ! is_array( $cached ) ) {
        return array();
    }
    return array_map( 'strtolower', $cached );
}

/**
 * Resolve a step's assignee_role pattern against entry data.
 *
 * Replaces {chronicle_slug} and {coordinator_genre} placeholders
 * with actual entry values.
 *
 * @param object $entry       Entry row object.
 * @param array  $step_config Step configuration array.
 * @return string Resolved lowercase role path, or empty string.
 */
function owc_oat_resolve_step_role( $entry, $step_config ) {
    $pattern = isset( $step_config['assignee_role'] ) ? $step_config['assignee_role'] : '';
    if ( empty( $pattern ) ) {
        return '';
    }
    $resolved = str_replace(
        array( '{chronicle_slug}', '{coordinator_genre}' ),
        array(
            isset( $entry->chronicle_slug ) ? $entry->chronicle_slug : '',
            isset( $entry->coordinator_genre ) ? $entry->coordinator_genre : '',
        ),
        $pattern
    );
    // Any other {field} token takes the value of that field on the request, as the workflow engine resolves it.
    if ( ! empty( $entry->id ) && class_exists( 'OAT_Entry_Meta' ) && preg_match_all( '/\{([a-z_]+)\}/', $resolved, $tokens ) ) {
        foreach ( array_unique( $tokens[1] ) as $key ) {
            $resolved = str_replace( '{' . $key . '}', (string) OAT_Entry_Meta::get( (int) $entry->id, $key ), $resolved );
        }
    }
    return strtolower( $resolved );
}

/**
 * Check if any of the user's roles grant archivist oversight.
 *
 * @param array $user_roles Lowercase-normalized role paths.
 * @return bool
 */
function owc_oat_is_archivist_oversight( $user_roles ) {
    $oversight_paths = apply_filters( 'oat_archivist_oversight_paths', array(
        'exec/archivist/coordinator',
        'exec/archivist/staff',
    ) );
    foreach ( $oversight_paths as $path ) {
        if ( in_array( strtolower( $path ), $user_roles, true ) ) {
            return true;
        }
    }
    return false;
}

/**
 * Check if a user qualifies as a "super user" for fast-track submissions.
 *
 * Super users: WP Admin, exec/archivist/coordinator, exec/web/coordinator, exec/admin/coordinator.
 *
 * @param int $user_id WordPress user ID.
 * @return bool
 */
function owc_oat_is_super_user( $user_id ) {
    $user = get_userdata( $user_id );
    if ( $user && $user->has_cap( 'manage_options' ) ) {
        return true;
    }
    $roles = owc_oat_get_user_asc_roles( $user_id );
    $super_roles = array(
        'exec/archivist/coordinator',
        'exec/archivist/staff',
        'exec/web/coordinator',
        'exec/admin/coordinator',
    );
    foreach ( $super_roles as $sr ) {
        if ( in_array( $sr, $roles, true ) ) {
            return true;
        }
    }
    return false;
}

/**
 * How a user reaches a request. 'staff': a site admin or an exec office that oversees OAT, anyone assigned to one of
 * its review steps, anyone holding its current step's role, its chronicle's staff, its Coordinator offices (including
 * offices flagged on a chronicle report) and, for Disciplinary Actions, anyone holding a staff, Coordinator or exec
 * role, as on the Reports page. 'player': its filer, its character's player, or the person a player step (a User/
 * role) is assigned to, when no staff path applies. '': neither.
 *
 * @param object $entry   Entry row.
 * @param int    $user_id WordPress user id.
 * @return string 'staff', 'player' or ''.
 */
function owc_oat_entry_access( $entry, $user_id ) {
    $user_id = (int) $user_id;
    if ( ! $entry || $user_id <= 0 ) {
        return '';
    }
    if ( owc_oat_is_super_user( $user_id ) ) {
        return 'staff';
    }
    $player = (int) $entry->originator_id === $user_id;
    if ( class_exists( 'OAT_Assignee' ) ) {
        foreach ( OAT_Assignee::for_entry( (int) $entry->id ) as $assignee ) {
            if ( (int) $assignee->user_id !== $user_id ) {
                continue;
            }
            if ( ! owc_oat_is_player_step( $entry, (string) $assignee->step ) ) {
                return 'staff';
            }
            $player = true;
        }
    }
    if ( $user_id === get_current_user_id() && class_exists( 'OAT_Authorization' ) ) {
        OAT_Authorization::get_user_roles();
    }
    $roles = owc_oat_get_user_asc_roles( $user_id );
    if ( owc_oat_is_archivist_oversight( $roles ) || owc_oat_user_can_act_on_step( $entry, $user_id ) ) {
        return 'staff';
    }
    $chronicle = strtolower( (string) $entry->chronicle_slug );
    $offices   = array();
    if ( ! empty( $entry->coordinator_genre ) ) {
        $offices[] = strtolower( (string) $entry->coordinator_genre );
    }
    if ( class_exists( 'OAT_Entry_Coordinator' ) && method_exists( 'OAT_Entry_Coordinator', 'slugs_for_entry' ) ) {
        foreach ( (array) OAT_Entry_Coordinator::slugs_for_entry( (int) $entry->id ) as $slug ) {
            $offices[] = strtolower( (string) $slug );
        }
    }
    if ( class_exists( 'OAT_Entry_Meta' ) ) {
        $flagged = OAT_Entry_Meta::get( (int) $entry->id, 'notify_coordinators' );
        if ( is_string( $flagged ) && '' !== $flagged ) {
            $decoded = json_decode( $flagged, true );
            $flagged = is_array( $decoded ) ? $decoded : array_map( 'trim', explode( ',', $flagged ) );
        }
        foreach ( (array) $flagged as $slug ) {
            $offices[] = sanitize_title( (string) $slug );
        }
    }
    $is_da = 'disciplinary_actions' === $entry->domain;
    foreach ( $roles as $role ) {
        if ( 'exec/archivist/staff' === $role || preg_match( '#^exec/(archivist|web|head-coordinator|ahc1|ahc2|admin|membership)/coordinator$#', $role ) ) {
            return 'staff';
        }
        if ( preg_match( '#^chronicle/([^/]+)/(hst|cm|staff|st|ast)$#', $role, $m ) ) {
            if ( ( '' !== $chronicle && $m[1] === $chronicle ) || ( $is_da && ! in_array( $m[2], array( 'ast', 'st' ), true ) ) ) {
                return 'staff';
            }
            continue;
        }
        if ( preg_match( '#^coordinator/([^/]+)/(coordinator|sub-coordinator)$#', $role, $m ) || preg_match( '#^exec/([^/]+)/coordinator$#', $role, $m ) ) {
            if ( $is_da || in_array( $m[1], $offices, true ) ) {
                return 'staff';
            }
        }
    }
    if ( ! $player && ! empty( $entry->character_id ) && class_exists( 'OAT_Character' ) ) {
        $character = OAT_Character::find( (int) $entry->character_id );
        $player    = $character && (int) $character->wp_user_id === $user_id;
    }
    return $player ? 'player' : '';
}

/**
 * Whether a user may see a request: owc_oat_entry_access() finds a way in.
 *
 * @param object $entry   Entry row.
 * @param int    $user_id WordPress user id.
 * @return bool
 */
function owc_oat_user_can_view_entry( $entry, $user_id ) {
    return '' !== owc_oat_entry_access( $entry, $user_id );
}

/**
 * Whether a step of a request belongs to a player rather than a reviewer: Submission and any other step with no
 * role (a request sent back there is assigned to its filer), or a step assigned to one person by account (a User/
 * role, as Binding Agreements' player comment step is).
 *
 * @param object $entry   Entry row.
 * @param string $step_id Step id.
 * @return bool
 */
function owc_oat_is_player_step( $entry, $step_id ) {
    if ( 'submit' === (string) $step_id ) {
        return true;
    }
    if ( ! class_exists( 'OAT_Workflow_Engine' ) ) {
        return false;
    }
    $config = OAT_Workflow_Engine::get_step_config( $entry, $step_id );
    $role   = is_array( $config ) && isset( $config['assignee_role'] ) ? trim( (string) $config['assignee_role'] ) : '';
    return '' === $role || 0 === stripos( $role, 'user/' );
}

/**
 * The most of a request's timeline a user sees: '' (none) when they reach the request only as a player, otherwise the
 * archivist, coordinator or staff tier their capabilities give them.
 *
 * @param object $entry   Entry row.
 * @param int    $user_id WordPress user id.
 * @return string Tier, or '' for no timeline.
 */
function owc_oat_entry_timeline_tier( $entry, $user_id ) {
    if ( ! class_exists( 'OAT_Constants' ) || 'staff' !== owc_oat_entry_access( $entry, $user_id ) ) {
        return '';
    }
    if ( user_can( (int) $user_id, OAT_Constants::CAP_ARCHIVIST ) ) {
        return OAT_Constants::TIER_ARCHIVIST;
    }
    if ( user_can( (int) $user_id, OAT_Constants::CAP_COORD_REVIEW ) ) {
        return OAT_Constants::TIER_COORDINATOR;
    }
    return OAT_Constants::TIER_STAFF;
}

/**
 * The latest send-back note on a request that is back at Submission (the same note its filer is emailed): note,
 * actor id and time, or null.
 *
 * @param object $entry Entry row.
 * @return array|null
 */
function owc_oat_entry_changes_note( $entry ) {
    if ( ! $entry || 'submit' !== (string) $entry->current_step || ! class_exists( 'OAT_Timeline' ) ) {
        return null;
    }
    global $wpdb;
    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}oat_timeline WHERE entry_id = %d AND action_type = 'request_changes' ORDER BY created_at DESC, id DESC LIMIT 1",
        (int) $entry->id
    ) );
    if ( ! $row || '' === trim( (string) $row->note ) ) {
        return null;
    }
    return array(
        'note'       => (string) $row->note,
        'actor_id'   => owc_oat_timeline_actor_id( $row ),
        'created_at' => $row->created_at,
    );
}

/**
 * Whether a user may take an action on a request: they can see it, and the request's page offers them that action.
 *
 * @param object $entry       Entry row.
 * @param int    $user_id     WordPress user id.
 * @param string $action_type Action slug.
 * @return bool
 */
function owc_oat_user_can_take_action( $entry, $user_id, $action_type ) {
    if ( ! owc_oat_user_can_view_entry( $entry, $user_id ) || ! class_exists( 'OAT_Assignee' ) ) {
        return false;
    }
    $allowed = owc_oat_compute_available_actions( $entry, (int) $user_id, OAT_Assignee::for_entry( (int) $entry->id ) );
    return in_array( (string) $action_type, $allowed, true );
}

/**
 * The fields of an approved Custom Content request that ccHub shows publicly.
 *
 * @param array $data Entry fields and meta.
 * @return array Only the fields the ccHub detail view displays.
 */
function owc_oat_cchub_public_fields( array $data ) {
    $keep = array( 'id', 'coordinator_genre', 'coordinator_title', 'chronicle_slug', 'chronicle_title', 'content_name', 'content_type', 'blood_magic_category', 'xp_cost', 'source_hst', 'archival_date', 'discipline_requirements', 'teachable_abilities', 'met_rules', 'summary' );
    return array_intersect_key( $data, array_flip( $keep ) );
}

/**
 * Check if a user can self-approve their own fast-tracked entries.
 *
 * Only WP Admin, exec/archivist/coordinator, and exec/archivist/staff can self-approve.
 * exec/web and exec/admin can fast-track but NOT self-approve.
 *
 * @param int $user_id WordPress user ID.
 * @return bool
 */
function owc_oat_can_self_approve( $user_id ) {
    $user = get_userdata( $user_id );
    if ( $user && $user->has_cap( 'manage_options' ) ) {
        return true;
    }
    $roles = owc_oat_get_user_asc_roles( $user_id );
    return in_array( 'exec/archivist/coordinator', $roles, true )
        || in_array( 'exec/archivist/staff', $roles, true );
}

/**
 * Check if the current user can create characters.
 *
 * Reads the oat_character_create_roles option (locally or via gateway).
 * If empty, all authenticated users are allowed.
 * Patterns support * as wildcard for a slug segment.
 *
 * @return bool
 */
function owc_oat_can_create_character() {
    if ( ! is_user_logged_in() ) {
        return false;
    }

    // WP admin always allowed.
    if ( current_user_can( 'manage_options' ) ) {
        return true;
    }

    $patterns = owc_oat_get_create_role_patterns();

    // The patterns could not be read: nobody but a site admin may create.
    if ( null === $patterns ) {
        return false;
    }

    // Empty = allow all authenticated users.
    if ( empty( $patterns ) ) {
        return true;
    }

    $user_id = get_current_user_id();
    $roles   = owc_oat_get_user_asc_roles( $user_id );
    if ( empty( $roles ) ) {
        return false;
    }

    foreach ( $patterns as $pattern ) {
        $pattern = strtolower( trim( $pattern ) );
        if ( '' === $pattern ) {
            continue;
        }
        // Convert wildcard pattern to regex: * matches any single slug segment.
        $regex = '#^' . str_replace( '\\*', '[^/]+', preg_quote( $pattern, '#' ) ) . '$#i';
        foreach ( $roles as $role ) {
            if ( preg_match( $regex, $role ) ) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Fetch the character creation allowed role patterns.
 *
 * Local: reads get_option directly.
 * Remote: fetches via gateway and caches in transient for 5 minutes; a failed fetch is
 * remembered for a minute and returns null.
 *
 * @return array|null Patterns, or null when they could not be read.
 */
function owc_oat_get_create_role_patterns() {
    if ( owc_oat_is_local() ) {
        $roles = get_option( 'oat_character_create_roles', array() );
        return is_array( $roles ) ? $roles : array();
    }

    // Remote: cache via transient.
    $cache_key = 'owc_oat_create_role_patterns';
    $cached    = get_transient( $cache_key );
    if ( is_array( $cached ) ) {
        return $cached;
    }
    if ( 'unavailable' === $cached ) {
        return null;
    }

    $response = owc_oat_request( 'settings/create-roles' );
    if ( is_wp_error( $response ) || ! isset( $response['roles'] ) ) {
        set_transient( $cache_key, 'unavailable', MINUTE_IN_SECONDS );
        return null;
    }

    $roles = is_array( $response['roles'] ) ? $response['roles'] : array();
    set_transient( $cache_key, $roles, 5 * MINUTE_IN_SECONDS );
    return $roles;
}

/**
 * Check if a user holds the resolved step role.
 *
 * @param array  $user_roles    Lowercase-normalized role paths.
 * @param string $resolved_role Resolved lowercase role path.
 * @return bool
 */
function owc_oat_user_has_step_role( $user_roles, $resolved_role ) {
    if ( empty( $resolved_role ) ) {
        return false;
    }
    return in_array( $resolved_role, $user_roles, true );
}

/**
 * Check if a user can act on the entry's current step based on
 * ASC role-path matching.
 *
 * @param object $entry   Entry row object.
 * @param int    $user_id WordPress user ID. Defaults to current user.
 * @return bool
 */
function owc_oat_user_can_act_on_step( $entry, $user_id = 0 ) {
    if ( ! class_exists( 'OAT_Workflow_Engine' ) ) {
        return false;
    }
    if ( ! $user_id ) {
        $user_id = get_current_user_id();
    }
    $user_roles = owc_oat_get_user_asc_roles( $user_id );
    if ( empty( $user_roles ) ) {
        return false;
    }
    if ( owc_oat_is_archivist_oversight( $user_roles ) ) {
        return true;
    }
    $step_config = OAT_Workflow_Engine::get_step_config( $entry );
    if ( ! $step_config ) {
        return false;
    }
    $resolved_role = owc_oat_resolve_step_role( $entry, $step_config );
    return owc_oat_user_has_step_role( $user_roles, $resolved_role );
}

/**
 * Get pending entries the user can act on based on ASC role-path matching.
 *
 * Queries all non-terminal entries, then filters to those whose current step's
 * resolved assignee_role matches one of the user's ASC roles.
 * Archivist oversight (exec/archivist/coordinator) sees all entries.
 *
 * @param int    $user_id       WordPress user ID.
 * @param string $domain_filter Optional domain slug filter.
 * @return array Array of entry row objects.
 */
function owc_oat_capability_inbox_entries( $user_id, $domain_filter = '' ) {
    if ( ! class_exists( 'OAT_Constants' ) || ! class_exists( 'OAT_Workflow_Engine' ) ) {
        return array();
    }

    $user_roles = owc_oat_get_user_asc_roles( $user_id );
    if ( empty( $user_roles ) ) {
        return array();
    }

    $is_archivist = owc_oat_is_archivist_oversight( $user_roles );

    // Query non-terminal entries.
    global $wpdb;
    $table = $wpdb->prefix . 'oat_entries';
    $terminal = array(
        OAT_Constants::STATUS_APPROVED,
        OAT_Constants::STATUS_DENIED,
        OAT_Constants::STATUS_CANCELLED,
        OAT_Constants::STATUS_AUTO_APPROVED,
        OAT_Constants::STATUS_AUTO_DENIED,
    );
    $placeholders = implode( ', ', array_fill( 0, count( $terminal ), '%s' ) );
    $sql = "SELECT * FROM {$table} WHERE status NOT IN ({$placeholders})";
    $args = $terminal;

    if ( $domain_filter ) {
        $sql .= ' AND domain = %s';
        $args[] = $domain_filter;
    }
    $sql .= ' ORDER BY created_at DESC';

    $entries = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
    if ( ! $entries ) {
        return array();
    }

    // Archivist oversight: return all non-terminal entries.
    if ( $is_archivist ) {
        return $entries;
    }

    // Filter to entries whose resolved step role matches user's ASC roles.
    $result     = array();
    $step_cache = array();

    foreach ( $entries as $entry ) {
        $cache_key = $entry->domain . '::' . $entry->current_step;
        if ( ! isset( $step_cache[ $cache_key ] ) ) {
            $step_cache[ $cache_key ] = OAT_Workflow_Engine::get_step_config( $entry );
        }
        $step_config = $step_cache[ $cache_key ];
        if ( ! $step_config ) {
            continue;
        }
        $resolved_role = owc_oat_resolve_step_role( $entry, $step_config );
        if ( owc_oat_user_has_step_role( $user_roles, $resolved_role ) ) {
            $result[] = $entry;
        }
    }

    return $result;
}

/**
 * Set regulation meta from linked rules.
 *
 * Determines requires_coord and regulation_level from highest rule priority.
 *
 * @param int   $entry_id
 * @param array $rule_ids
 * @return void
 */
function owc_oat_set_regulation_meta( $entry_id, $rule_ids ) {
    $requires_coord = '0';
    $regulation_level = '';

    // D3: Use pc_level or npc_level based on character's PC/NPC type.
    $pc_npc = 'pc';
    if ( class_exists( 'OAT_Entry_Meta' ) ) {
        $stored = OAT_Entry_Meta::get( $entry_id, 'pc_npc' );
        if ( $stored ) {
            $pc_npc = $stored;
        }
    }

    $priority = array(
        'council_vote'         => 4,
        'disallowed'           => 3,
        'coordinator_approval' => 2,
        'coordinator_notify'   => 1,
    );
    $highest = 0;

    foreach ( $rule_ids as $rule_id ) {
        // Skip free-text entries (super user): only linked rules affect routing.
        if ( is_array( $rule_id ) ) {
            continue;
        }
        $rule = OAT_Regulation_Rule::find( (int) $rule_id );
        if ( ! $rule ) {
            continue;
        }

        $level = ( 'npc' === $pc_npc && ! empty( $rule->npc_level ) ) ? $rule->npc_level : $rule->pc_level;
        if ( $level && isset( $priority[ $level ] ) && $priority[ $level ] > $highest ) {
            $highest = $priority[ $level ];
            $regulation_level = $level;
        }
    }

    if ( $highest >= 2 ) {
        $requires_coord = '1';
    }

    OAT_Entry_Meta::set( $entry_id, 'requires_coord', $requires_coord );
    if ( $regulation_level ) {
        OAT_Entry_Meta::set( $entry_id, 'regulation_level', $regulation_level );
    }
}


/**
 * Get entry counts for a user's dashboard.
 *
 * Returns:
 *   ['assigned' => int, 'submissions' => int, 'watching' => int]
 *
 * Local mode:  queries oat_assignees, oat_entries, oat_watchers directly.
 * Remote mode: POST /oat/dashboard-counts.
 *
 * @param int $user_id WordPress user ID.
 * @return array|WP_Error
 */
function owc_oat_get_dashboard_counts( $user_id ) {
    $user_id = (int) $user_id;

    if ( owc_oat_is_local() ) {
        global $wpdb;
        $prefix = $wpdb->prefix;

        $assigned = count( owc_oat_entries_waiting_on( $user_id ) );

        $submissions = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$prefix}oat_entries
             WHERE originator_id = %d AND status NOT IN ('approved','denied','cancelled')",
            $user_id
        ) );

        $watching = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$prefix}oat_watchers WHERE user_id = %d",
            $user_id
        ) );

        return array(
            'assigned'    => $assigned,
            'submissions' => $submissions,
            'watching'    => $watching,
        );
    }

    // Remote mode.
    $response = owc_oat_request( 'dashboard-counts', array( 'user_id' => $user_id ) );
    if ( is_wp_error( $response ) ) {
        return $response;
    }
    return isset( $response['counts'] ) ? $response['counts'] : $response;
}


/**
 * Get recent timeline activity visible to a user.
 *
 * Returns array of event arrays:
 *   [['entry_id', 'domain', 'domain_label', 'action_type', 'actor_name', 'note', 'created_at'], ...]
 *
 * Local mode:  joins oat_timeline + oat_entries, filters by user's accessible entries.
 * Remote mode: POST /oat/recent-activity.
 *
 * @param int    $user_id WordPress user ID.
 * @param int    $limit   Maximum number of events to return (default 10).
 * @param string $domain  Optional domain slug to filter by (empty = all).
 * @return array|WP_Error
 */
function owc_oat_get_recent_activity( $user_id, $limit = 10, $domain = '' ) {
    $user_id = (int) $user_id;
    $limit   = min( 100, max( 1, (int) $limit ) );
    $domain  = sanitize_key( $domain );

    if ( owc_oat_is_local() ) {
        global $wpdb;
        $prefix = $wpdb->prefix;

        // Collect entry IDs accessible to this user:
        //   - entries they originated
        //   - entries they are assigned to
        //   - entries they are watching
        $entry_ids_sql =
            "SELECT DISTINCT e.id FROM {$prefix}oat_entries e
             WHERE e.originator_id = {$user_id}
             UNION
             SELECT DISTINCT a.entry_id FROM {$prefix}oat_assignees a WHERE a.user_id = {$user_id}
             UNION
             SELECT DISTINCT w.entry_id FROM {$prefix}oat_watchers w WHERE w.user_id = {$user_id}";

        $domain_clause = $domain ? $wpdb->prepare( "AND e.domain = %s", $domain ) : '';

        // Events are for the request's staff and up: the archivist tier sees every event, Coordinators staff- and
        // coordinator-tier ones, everyone else staff-tier ones, and only on requests they reach as staff.
        if ( user_can( $user_id, OAT_Constants::CAP_ARCHIVIST ) ) {
            $tier_clause = '';
        } elseif ( user_can( $user_id, OAT_Constants::CAP_COORD_REVIEW ) ) {
            $tier_clause = "AND t.visibility_tier IN ('staff','coordinator')";
        } else {
            $tier_clause = "AND t.visibility_tier = 'staff'";
        }

        $candidates = $wpdb->get_results( $wpdb->prepare(
            "SELECT t.entry_id, e.domain, t.action_type, t.user_id AS actor_id, t.note, t.created_at
             FROM {$prefix}oat_timeline t
             INNER JOIN {$prefix}oat_entries e ON e.id = t.entry_id
             WHERE t.entry_id IN ({$entry_ids_sql})
               {$tier_clause}
               {$domain_clause}
             ORDER BY t.created_at DESC
             LIMIT %d",
            $limit * 5
        ), ARRAY_A );

        $rows     = array();
        $is_staff = array();
        foreach ( (array) $candidates as $row ) {
            $eid = (int) $row['entry_id'];
            if ( ! isset( $is_staff[ $eid ] ) ) {
                $is_staff[ $eid ] = 'staff' === owc_oat_entry_access( OAT_Entry::find( $eid ), $user_id );
            }
            if ( $is_staff[ $eid ] ) {
                $rows[] = $row;
                if ( count( $rows ) >= $limit ) {
                    break;
                }
            }
        }

        if ( ! $rows ) {
            return array();
        }

        // Resolve actor names.
        $actor_ids = array_unique( array_column( $rows, 'actor_id' ) );
        $actor_map = array();
        foreach ( $actor_ids as $aid ) {
            $u = get_user_by( 'id', $aid );
            $actor_map[ $aid ] = $u ? $u->display_name : '#' . $aid;
        }

        // Collect domain labels.
        $domain_labels = array();
        if ( function_exists( 'owc_oat_get_domains' ) ) {
            $domains = owc_oat_get_domains();
            foreach ( $domains as $d ) {
                $domain_labels[ $d['slug'] ] = $d['label'];
            }
        }

        $events = array();
        foreach ( $rows as $row ) {
            $events[] = array(
                'entry_id'     => (int) $row['entry_id'],
                'domain'       => $row['domain'],
                'domain_label' => isset( $domain_labels[ $row['domain'] ] ) ? $domain_labels[ $row['domain'] ] : ucfirst( str_replace( '_', ' ', $row['domain'] ) ),
                'action_type'  => $row['action_type'],
                'actor_name'   => isset( $actor_map[ $row['actor_id'] ] ) ? $actor_map[ $row['actor_id'] ] : '',
                'note'         => $row['note'],
                'created_at'   => owc_oat_format_date( $row['created_at'] ),
            );
        }

        return $events;
    }

    // Remote mode.
    $response = owc_oat_request( 'recent-activity', array(
        'user_id' => $user_id,
        'limit'   => $limit,
        'domain'  => $domain,
    ) );
    if ( is_wp_error( $response ) ) {
        return $response;
    }
    return isset( $response['events'] ) ? $response['events'] : $response;
}

/**
 * Get all active regulation rules, with transient caching.
 *
 * In local mode (OAT toolkit active), queries the DB directly.
 * In remote mode, fetches from archivist via /oat/rules and caches
 * the result in a transient for efficient client-side use.
 *
 * @param bool $force_refresh Skip the transient cache when true.
 * @return array Array of rule arrays (id, genre, category, subcategory,
 *               condition, pc_level, npc_level, coordinator, elevation).
 */
function owc_oat_get_regulation_rules( $force_refresh = false ) {
    $cache_key = 'owc_oat_rules_cache';

    if ( ! $force_refresh ) {
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }
    }

    if ( owc_oat_is_local() ) {
        if ( ! class_exists( 'OAT_Regulation_Rule' ) ) {
            return array();
        }
        $rows = OAT_Regulation_Rule::all( array( 'active' => 1, 'per_page' => 5000 ) );
        $data = array();
        foreach ( $rows as $rule ) {
            $data[ (int) $rule->id ] = array(
                'id'          => (int) $rule->id,
                'genre'       => $rule->genre,
                'category'    => $rule->category,
                'subcategory' => $rule->subcategory,
                'condition'   => $rule->condition_name,
                'pc_level'    => $rule->pc_level,
                'npc_level'   => $rule->npc_level,
                'coordinator' => $rule->controlling_coordinator,
                'elevation'   => (int) $rule->elevation,
            );
        }
    } else {
        $response = owc_oat_request( 'rules', array() );
        if ( is_wp_error( $response ) || ! is_array( $response ) ) {
            return array();
        }
        $data = array();
        foreach ( $response as $rule ) {
            $id = isset( $rule['id'] ) ? (int) $rule['id'] : 0;
            if ( $id ) {
                $data[ $id ] = $rule;
            }
        }
    }

    $ttl = defined( 'OWC_CACHE_TTL' ) ? (int) OWC_CACHE_TTL : 3600;
    if ( $ttl > 0 ) {
        set_transient( $cache_key, $data, $ttl );
    }

    return $data;
}

/**
 * Find a single regulation rule by ID, using the cached rule list.
 *
 * @param int $id Rule ID.
 * @return array|null Rule data array or null if not found.
 */
function owc_oat_find_cached_rule( $id ) {
    $id    = (int) $id;
    $rules = owc_oat_get_regulation_rules();
    return isset( $rules[ $id ] ) ? $rules[ $id ] : null;
}


// ── Registry Visibility API ─────────────────────────────────────────


/**
 * Fetch scoped registry for current user.
 *
 * Local mode: full scoped registry (own + chronicle + coordinator characters).
 * Remote mode: own characters only (My Characters).
 *
 * @param array $args Optional 'chronicle' and/or 'genre' (string or array, local mode only).
 * @return array|WP_Error
 */
function owc_oat_get_registry( $args = array() ) {
    if ( owc_oat_is_local() ) {
        $user_id = get_current_user_id();

        $chronicles = isset( $args['chronicle'] ) ? (array) $args['chronicle'] : array();
        $genres     = isset( $args['genre'] ) ? (array) $args['genre'] : array();

        if ( $chronicles || $genres ) {
            $characters = array();
            foreach ( $chronicles as $slug ) {
                foreach ( OAT_Registry::get_characters_for_chronicle( $slug ) as $c ) {
                    $characters[ $c->id ] = $c;
                }
            }
            foreach ( $genres as $genre ) {
                foreach ( OAT_Registry::get_characters_for_coordinator( $genre ) as $c ) {
                    $characters[ $c->id ] = $c;
                }
            }
            $characters = array_values( $characters );
            foreach ( $characters as $char ) {
                $char->entry_counts = OAT_Registry::get_entry_counts_by_domain( (int) $char->id );
            }
            return array( 'characters' => $characters, 'count' => count( $characters ) );
        }

        $characters = OAT_Registry::get_scoped_registry( $user_id );
        return array( 'characters' => $characters, 'count' => count( $characters ) );
    }

    $params = array();
    if ( ! empty( $args['chronicle'] ) ) {
        $params['chronicle'] = is_array( $args['chronicle'] ) ? implode( ',', $args['chronicle'] ) : $args['chronicle'];
    }
    if ( ! empty( $args['genre'] ) ) {
        $params['genre'] = is_array( $args['genre'] ) ? implode( ',', $args['genre'] ) : $args['genre'];
    }

    return owc_oat_request( 'registry', $params );
}

/**
 * Fetch registry section headers with counts for a scope.
 *
 * @param string $scope mine|chronicles|coordinators|decommissioned
 * @return array|WP_Error
 */
function owc_oat_get_registry_sections( $scope ) {
    if ( owc_oat_is_local() ) {
        $user_id = get_current_user_id();
        return OAT_Registry::get_registry_sections( $user_id, $scope );
    }
    return owc_oat_request( 'registry/sections', array( 'scope' => $scope ) );
}

/**
 * Fetch characters for a single registry section.
 *
 * @param string $section_key e.g. 'mine', 'chronicle-hartford', 'coordinator-vampire'
 * @return array|WP_Error
 */
function owc_oat_get_section_characters( $section_key ) {
    if ( owc_oat_is_local() ) {
        if ( ! function_exists( 'owc_oat_section_key_allowed' ) || ! owc_oat_section_key_allowed( $section_key ) ) {
            return new WP_Error( 'forbidden', 'You do not have access to that registry section.' );
        }
        $user_id    = get_current_user_id();
        $characters = OAT_Registry::get_section_characters( $user_id, $section_key );
        // Normalize to arrays for consistency with remote mode.
        return array( 'characters' => array_map( function( $c ) {
            return (array) $c;
        }, $characters ) );
    }
    return owc_oat_request( 'registry/section-characters', array( 'section_key' => $section_key ) );
}

/**
 * Search registry characters by name or chronicle slug.
 *
 * Scoped to current user's access — same visibility as registry sections.
 *
 * @param string $q Search term (min 2 chars).
 * @return array|WP_Error Array of character arrays.
 */
function owc_oat_registry_search( $q ) {
    if ( owc_oat_is_local() ) {
        $user_id    = get_current_user_id();
        $characters = OAT_Registry::search_characters( $user_id, $q );
        return array_map( function( $c ) { return (array) $c; }, $characters );
    }
    return owc_oat_request( 'registry/search', array( 'q' => $q ) );
}

/**
 * Fetch registry entries for one character.
 *
 * @param int $character_id
 * @return array|WP_Error
 */
function owc_oat_get_character_registry( $character_id, $show_all = false ) {
    if ( owc_oat_is_local() ) {
        $character = OAT_Character::find( $character_id );
        if ( ! $character ) {
            return new WP_Error( 'not_found', 'Character not found.' );
        }

        // Authorization: local mode must enforce the SAME per-character view gate
        // the REST endpoint applies (archivist / owner / staff-grant / coordinator-grant).
        // Without this, any logged-in user could read any character by ID (IDOR/PII leak).
        // Fail closed if the authorization class is unavailable.
        if ( ! class_exists( 'OAT_REST_Registry' )
            || ! method_exists( 'OAT_REST_Registry', 'can_view_character' )
            || ! OAT_REST_Registry::can_view_character( $character )
        ) {
            return new WP_Error( 'forbidden', 'You do not have permission to view this character.' );
        }

        $entries = OAT_Registry::get_registry_entries( $character_id );
        $grants  = OAT_Registry_Access::find_by_character( $character_id );

        // Apply the same coordinator ownership filter the REST endpoint uses.
        $ctx = class_exists( 'OAT_REST_Registry' )
            ? OAT_REST_Registry::owned_filter_context( $character, $show_all )
            : array( 'apply' => false, 'genres' => array(), 'can_show_all' => false );

        $out = array();
        foreach ( $entries as $entry ) {
            $coordinators = class_exists( 'OAT_Entry_Coordinator' )
                ? OAT_Entry_Coordinator::slugs_for_entry( (int) $entry->id )
                : array();
            if ( empty( $coordinators ) && ! empty( $entry->coordinator_genre ) ) {
                $coordinators = array( strtolower( $entry->coordinator_genre ) );
            }
            if ( $ctx['apply'] && ! array_intersect( $coordinators, $ctx['genres'] ) ) {
                continue;
            }
            $entry->coordinators = $coordinators;
            $out[] = $entry;
        }

        $character->wp_user_label = owc_oat_linked_user_label( $character->wp_user_id );

        return array(
            'character'    => $character,
            'grants'       => $grants,
            'entries'      => $out,
            'can_show_all' => $ctx['can_show_all'],
            'show_all'     => (bool) $show_all,
        );
    }

    $body = $show_all ? array( 'show_all' => 1 ) : array();
    return owc_oat_request( 'registry/character/' . (int) $character_id, $body );
}

/**
 * Fetch public registry fields for one character.
 *
 * @param int $character_id
 * @return array|WP_Error
 */
function owc_oat_get_public_registry( $character_id ) {
    if ( owc_oat_is_local() ) {
        $character = OAT_Character::find( $character_id );
        if ( ! $character ) {
            return new WP_Error( 'not_found', 'Character not found.' );
        }

        return array(
            'character_id'   => $character_id,
            'character_name' => $character->character_name,
            'public_fields'  => OAT_Registry::get_public_registry( $character_id ),
        );
    }

    return owc_oat_request( 'registry/public/' . (int) $character_id );
}

/**
 * Create an explicit grant for a character.
 *
 * @param int         $character_id
 * @param string      $grant_type  'chronicle' or 'coordinator'.
 * @param string      $grant_value Chronicle slug or genre slug.
 * @param int|null    $expires_at  Unix timestamp or null for permanent.
 * @return array|WP_Error
 */
function owc_oat_grant_access( $character_id, $grant_type, $grant_value, $expires_at = null ) {
    if ( owc_oat_is_local() ) {
        // Authorization: only someone who manages this character's grants
        // (archivist, or staff of the character's own chronicle) may create one.
        // Mirrors the REST create_grant gate. The form handler's nonce alone is
        // not character-scoped, so enforce here at the choke point. Fail closed.
        $character = OAT_Character::find( $character_id );
        if ( ! $character ) {
            return new WP_Error( 'not_found', 'Character not found.', array( 'status' => 404 ) );
        }
        if ( ! class_exists( 'OAT_REST_Registry' )
            || ! method_exists( 'OAT_REST_Registry', 'can_manage_grants' )
            || ! OAT_REST_Registry::can_manage_grants( $character )
        ) {
            return new WP_Error( 'forbidden', 'You do not have permission to manage grants for this character.', array( 'status' => 403 ) );
        }

        $grant_id = OAT_Registry_Access::ensure_grant(
            $character_id,
            $grant_type,
            $grant_value,
            get_current_user_id()
        );

        if ( $expires_at && $grant_id ) {
            global $wpdb;
            $wpdb->update(
                $wpdb->prefix . 'oat_registry_access',
                array( 'expires_at' => $expires_at ),
                array( 'id' => $grant_id ),
                array( '%d' ),
                array( '%d' )
            );
        }

        return array( 'success' => true, 'grant_id' => $grant_id );
    }

    return owc_oat_request( 'registry/grant', array(
        'character_id' => $character_id,
        'grant_type'   => $grant_type,
        'grant_value'  => $grant_value,
        'expires_at'   => $expires_at ?: 0,
    ) );
}

/**
 * Update a character's fields.
 *
 * @param int   $character_id
 * @param array $data Associative array of fields to update.
 * @return array|WP_Error
 */
function owc_oat_update_character( $character_id, $data ) {
    if ( owc_oat_is_local() ) {
        $character = OAT_Character::find( $character_id );
        if ( ! $character ) {
            return new WP_Error( 'not_found', 'Character not found.' );
        }

        $result = OAT_Character::update( $character_id, $data );
        if ( ! $result ) {
            return new WP_Error( 'update_failed', 'Character update failed.' );
        }

        return array( 'success' => true, 'character' => (array) OAT_Character::find( $character_id ) );
    }

    return owc_oat_request( 'registry/character/' . (int) $character_id . '/update', $data );
}

/**
 * Create a character from the create panel's fields, on archivist directly or through the gateway.
 *
 * @param array $input See owc_oat_create_character_record().
 * @return array|WP_Error uuid, character_name, chronicle_slug, pc_npc, linked.
 */
function owc_oat_create_character( array $input ) {
    if ( owc_oat_is_local() ) {
        return owc_oat_create_character_record( $input );
    }
    return owc_oat_request( 'registry/character/create', $input );
}

/**
 * Archivist accounts for the account pickers, on archivist directly or through the gateway,
 * so the ids are archivist ids on every site.
 *
 * @param string $term At least two characters.
 * @return array|WP_Error Arrays with id, label, value, type, display_name, email.
 */
function owc_oat_find_link_users( $term ) {
    if ( owc_oat_is_local() ) {
        return owc_oat_search_link_users( $term );
    }
    return owc_oat_request( 'users/search', array( 'term' => (string) $term ) );
}

/**
 * The creature taxonomy for the Genre / Faction / Type / Variant pickers: read from OAT on
 * archivist, fetched server-side through the gateway elsewhere and cached for an hour.
 *
 * @return array genres, factions, types, variants.
 */
function owc_oat_get_creature_taxonomy() {
    $empty = array( 'genres' => array(), 'factions' => array(), 'types' => array(), 'variants' => array() );
    if ( owc_oat_is_local() ) {
        return class_exists( 'OAT_Creature_Taxonomy' ) ? OAT_Creature_Taxonomy::get_picker_data() : $empty;
    }

    $cached = get_transient( 'owc_oat_creature_taxonomy' );
    if ( is_array( $cached ) ) {
        return $cached;
    }

    $response = owc_oat_request( 'creature-taxonomy' );
    if ( is_wp_error( $response ) || ! is_array( $response ) ) {
        return $empty;
    }
    $data = isset( $response['genres'] ) ? $response : ( isset( $response['data']['genres'] ) ? $response['data'] : null );
    if ( ! is_array( $data ) ) {
        return $empty;
    }

    set_transient( 'owc_oat_creature_taxonomy', $data, HOUR_IN_SECONDS );
    return $data;
}

/**
 * Strings the OAT scripts show, shared by the wp-admin and the front-end script settings.
 *
 * @return array<string,string>
 */
function owc_oat_js_i18n() {
    return array(
        'processing'      => __( 'Processing...', 'owbn-archivist' ),
        'submit'          => __( 'Submit', 'owbn-archivist' ),
        'watch'           => __( 'Watch', 'owbn-archivist' ),
        'unwatch'         => __( 'Unwatch', 'owbn-archivist' ),
        'watching'        => __( 'Watching', 'owbn-archivist' ),
        'creating'        => __( 'Creating...', 'owbn-archivist' ),
        'createCharacter' => __( 'Create Character', 'owbn-archivist' ),
        'charRequired'    => __( 'Character name is required.', 'owbn-archivist' ),
        'playerRequired'  => __( "A PC needs its player's name and email.", 'owbn-archivist' ),
        'emailInvalid'    => __( "That player email doesn't look right.", 'owbn-archivist' ),
        'requestFailed'   => __( 'Request failed.', 'owbn-archivist' ),
        'showTimeline'    => __( 'Show Timeline', 'owbn-archivist' ),
        'hideTimeline'    => __( 'Hide Timeline', 'owbn-archivist' ),
        'error'           => __( 'Error', 'owbn-archivist' ),
        'rulePrefix'      => __( 'Rule #', 'owbn-archivist' ),
        'searchRules'     => __( 'Search rules or type free text, then press Enter...', 'owbn-archivist' ),
        'addPrefix'       => __( 'Add: ', 'owbn-archivist' ),
        'notLinked'       => __( 'Not linked', 'owbn-archivist' ),
        'unlinkPending'   => __( 'Not linked (saved when you click Update Character)', 'owbn-archivist' ),
        'noAccounts'      => __( 'No account matches that.', 'owbn-archivist' ),
        'emailFirst'      => __( 'Enter a player email first.', 'owbn-archivist' ),
        'sectDefector'    => __( 'Sect Defector', 'owbn-archivist' ),
        'notOnList'       => __( 'not on this list', 'owbn-archivist' ),
    );
}

/**
 * Expire (revoke) a grant.
 *
 * @param int $grant_id
 * @return array|WP_Error
 */
function owc_oat_revoke_access( $grant_id ) {
    if ( owc_oat_is_local() ) {
        // Authorization: resolve the grant → its character, and require manage
        // rights on that character. Mirrors the REST revoke gate. The form nonce
        // is not grant-scoped, so enforce here at the choke point. Fail closed.
        $grant = OAT_Registry_Access::find( $grant_id );
        if ( ! $grant ) {
            return new WP_Error( 'not_found', 'Grant not found.', array( 'status' => 404 ) );
        }
        $character = OAT_Character::find( (int) $grant->character_id );
        if ( ! class_exists( 'OAT_REST_Registry' )
            || ! method_exists( 'OAT_REST_Registry', 'can_manage_grants' )
            || ! OAT_REST_Registry::can_manage_grants( $character )
        ) {
            return new WP_Error( 'forbidden', 'You do not have permission to revoke this grant.', array( 'status' => 403 ) );
        }

        OAT_Registry_Access::expire( $grant_id );
        return array( 'success' => true );
    }

    return owc_oat_request( 'registry/grant/' . (int) $grant_id . '/revoke' );
}


// ── ccHub Custom Content API ─────────────────────────────────────────


/**
 * Fetch ccHub content type categories with counts.
 *
 * @return array|WP_Error
 */
function owc_oat_get_cchub_categories() {
    if ( owc_oat_is_local() ) {
        global $wpdb;
        $entries = $wpdb->prefix . 'oat_entries';
        $meta    = $wpdb->prefix . 'oat_entry_meta';

        $rows = $wpdb->get_results( "
            SELECT m.meta_value as content_type, COUNT(DISTINCT e.id) as cnt
            FROM {$entries} e
            JOIN {$meta} m ON e.id = m.entry_id AND m.meta_key = 'content_type'
            WHERE e.domain = 'custom_content' AND e.status = 'approved'
            AND m.meta_value != ''
            GROUP BY m.meta_value
            ORDER BY m.meta_value ASC
        " );

        $out = array();
        foreach ( $rows as $cat ) {
            $out[] = array(
                'content_type' => $cat->content_type,
                'count'        => (int) $cat->cnt,
            );
        }
        return $out;
    }

    return owc_oat_request( 'cchub/categories' );
}


/**
 * Fetch ccHub browse data for a content type.
 *
 * Returns lightweight rows for table display (id, name, type, bm_cat, xp, coord, chron).
 *
 * @param string $type Content type filter (empty = all).
 * @return array|WP_Error
 */
function owc_oat_get_cchub_browse( $type = '' ) {
    if ( owc_oat_is_local() ) {
        global $wpdb;
        $entries = $wpdb->prefix . 'oat_entries';
        $meta    = $wpdb->prefix . 'oat_entry_meta';

        $where     = "e.domain = 'custom_content' AND e.status = 'approved'";
        $join_type = '';
        if ( $type ) {
            $join_type = $wpdb->prepare(
                "JOIN {$meta} mt ON e.id = mt.entry_id AND mt.meta_key = 'content_type' AND mt.meta_value = %s",
                $type
            );
        }

        $sql = "
            SELECT e.id, e.coordinator_genre, e.chronicle_slug,
                mn.meta_value as content_name,
                mx.meta_value as xp_cost,
                mct.meta_value as content_type,
                mbm.meta_value as bm_category
            FROM {$entries} e
            {$join_type}
            LEFT JOIN {$meta} mn ON e.id = mn.entry_id AND mn.meta_key = 'content_name'
            LEFT JOIN {$meta} mx ON e.id = mx.entry_id AND mx.meta_key = 'xp_cost'
            LEFT JOIN {$meta} mct ON e.id = mct.entry_id AND mct.meta_key = 'content_type'
            LEFT JOIN {$meta} mbm ON e.id = mbm.entry_id AND mbm.meta_key = 'blood_magic_category'
            WHERE {$where}
            ORDER BY mn.meta_value ASC
        ";
        $rows = $wpdb->get_results( $sql );

        $items = array();
        foreach ( $rows as $r ) {
            $items[] = array(
                'id'     => (int) $r->id,
                'name'   => $r->content_name ?: '(unnamed)',
                'type'   => $r->content_type ?: '',
                'bm_cat' => $r->bm_category ?: '',
                'xp'     => $r->xp_cost ?: '',
                'coord'  => $r->coordinator_genre ? ucfirst( $r->coordinator_genre ) : '',
                'chron'  => strtoupper( $r->chronicle_slug ?: '' ),
            );
        }
        return $items;
    }

    $body = array();
    if ( $type ) {
        $body['type'] = $type;
    }
    return owc_oat_request( 'cchub/browse', $body );
}


/**
 * Fetch a single ccHub entry with all meta and resolved titles.
 *
 * @param int $entry_id
 * @return array|WP_Error
 */
function owc_oat_get_cchub_entry( $entry_id ) {
    if ( owc_oat_is_local() ) {
        global $wpdb;
        $entries = $wpdb->prefix . 'oat_entries';
        $meta    = $wpdb->prefix . 'oat_entry_meta';

        $entry = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$entries} WHERE id = %d AND domain = 'custom_content' AND status = 'approved'",
            $entry_id
        ) );

        if ( ! $entry ) {
            return new WP_Error( 'not_found', 'Entry not found.' );
        }

        $meta_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT meta_key, meta_value FROM {$meta} WHERE entry_id = %d",
            $entry_id
        ) );

        $coord_slug  = $entry->coordinator_genre ?: '';
        $chron_slug  = $entry->chronicle_slug ?: '';
        $coord_title = '';
        $chron_title = '';
        if ( function_exists( 'owc_entity_get_title' ) ) {
            if ( $coord_slug ) { $coord_title = owc_entity_get_title( 'coordinator', $coord_slug ); }
            if ( $chron_slug ) { $chron_title = owc_entity_get_title( 'chronicle', $chron_slug ); }
        }

        $data = array(
            'id'                => (int) $entry->id,
            'coordinator_genre' => $coord_slug,
            'coordinator_title' => $coord_title ?: ucfirst( $coord_slug ),
            'chronicle_slug'    => $chron_slug,
            'chronicle_title'   => $chron_title ?: strtoupper( $chron_slug ),
        );
        foreach ( $meta_rows as $m ) {
            if ( strpos( $m->meta_key, '_oat_' ) === 0 || $m->meta_key === 'drupal_cc_id' ) {
                continue;
            }
            $data[ $m->meta_key ] = $m->meta_value;
        }
        return owc_oat_cchub_public_fields( $data );
    }

    return owc_oat_request( 'cchub/entry/' . (int) $entry_id );
}

/**
 * Resolve a URL language slug (e.g. 'pt') to a TranslatePress locale (e.g. 'pt_BR').
 * Returns the default locale if the slug is empty or doesn't match.
 *
 * @param string $slug URL slug like 'en' or 'pt'.
 * @return string Locale like 'en_US' or 'pt_BR'.
 */
function owc_oat_resolve_trp_language( $slug ) {
    if ( ! class_exists( 'TRP_Translate_Press' ) ) {
        return '';
    }
    $trp      = TRP_Translate_Press::get_trp_instance();
    $settings = $trp->get_component( 'settings' )->get_settings();
    $default  = $settings['default-language'] ?? 'en_US';
    if ( empty( $slug ) ) {
        return $default;
    }
    $url_slugs = $settings['url-slugs'] ?? array();
    foreach ( $url_slugs as $locale => $s ) {
        if ( strtolower( $s ) === strtolower( $slug ) ) {
            return $locale;
        }
    }
    return $default;
}

/**
 * Normalize a discipline_requirements meta value into a list of
 * { name, level } rows. Handles BOTH storage formats found in the data:
 *   - JSON array of objects: [{"name":"Fortitude","level":"2"}, ...]  (~1100 entries)
 *   - Plain text, one requirement per line:                            (~30 entries)
 *       "Fortitude 2\nPotence 2\nProtean 4"
 *     A trailing integer is treated as the level; freeform lines
 *     (e.g. "Must follow Path of Diamonds") render as name-only.
 *
 * Previously the preview modal only json_decode()'d the value, so text-format
 * entries silently showed no prerequisites even though the full page did.
 *
 * @param string $raw Stored meta value.
 * @return array List of [ 'name' => string, 'level' => string ].
 */
function owc_cchub_normalize_discipline_requirements( $raw ) {
    if ( ! is_string( $raw ) || $raw === '' ) {
        return array();
    }
    $rows = array();

    $decoded = json_decode( $raw, true );
    if ( is_array( $decoded ) && ! empty( $decoded ) ) {
        foreach ( $decoded as $r ) {
            if ( is_array( $r ) ) {
                $name  = trim( (string) ( $r['name'] ?? '' ) );
                $level = trim( (string) ( $r['level'] ?? '' ) );
            } else {
                $name  = trim( (string) $r );
                $level = '';
            }
            if ( $name !== '' || $level !== '' ) {
                $rows[] = array( 'name' => $name, 'level' => $level );
            }
        }
        return $rows;
    }

    // Plain-text fallback: one requirement per line.
    foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
        $line = trim( $line );
        if ( $line === '' ) {
            continue;
        }
        if ( preg_match( '/^(.*\S)\s+(\d+)$/', $line, $m ) ) {
            $rows[] = array( 'name' => $m[1], 'level' => $m[2] );
        } else {
            $rows[] = array( 'name' => $line, 'level' => '' );
        }
    }
    return $rows;
}

/**
 * Build the cchub modal entry HTML server-side. Replaces the JS-side
 * string concat so we can run the result through TranslatePress.
 *
 * @param array  $d           Entry data from owc_oat_get_cchub_entry().
 * @param string $lang_prefix URL prefix like '/pt' or '' for default language.
 * @return string HTML.
 */
function owc_cchub_render_entry_html( $d, $lang_prefix = '' ) {
    if ( ! is_array( $d ) ) return '';

    $h  = '<h2>' . esc_html( $d['content_name'] ?? '' ) . '</h2>';
    $h .= '<table style="width:100%;border-collapse:collapse;margin:12px 0;">';
    if ( ! empty( $d['content_type'] ) ) {
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;width:150px;">' . esc_html__( 'Category', 'owbn-archivist' ) . '</td><td>' . esc_html( $d['content_type'] ) . '</td></tr>';
    }
    if ( ! empty( $d['blood_magic_category'] ) ) {
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;">' . esc_html__( 'Tradition', 'owbn-archivist' ) . '</td><td>' . esc_html( $d['blood_magic_category'] ) . '</td></tr>';
    }
    if ( ! empty( $d['xp_cost'] ) ) {
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;">' . esc_html__( 'XP Cost', 'owbn-archivist' ) . '</td><td>' . esc_html( $d['xp_cost'] ) . '</td></tr>';
    }
    if ( ! empty( $d['coordinator_genre'] ) ) {
        $coord_url = $lang_prefix . '/coordinator-detail/?slug=' . rawurlencode( $d['coordinator_genre'] );
        $coord_lbl = $d['coordinator_title'] ?: $d['coordinator_genre'];
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;">' . esc_html__( 'Coordinator', 'owbn-archivist' ) . '</td><td><a href="' . esc_url( $coord_url ) . '" target="_blank" style="text-decoration:underline;">' . esc_html( $coord_lbl ) . ' &#x29C9;</a></td></tr>';
    }
    if ( ! empty( $d['chronicle_slug'] ) ) {
        $chron_url = $lang_prefix . '/chronicle-detail/?slug=' . rawurlencode( $d['chronicle_slug'] );
        $chron_lbl = $d['chronicle_title'] ?: $d['chronicle_slug'];
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;">' . esc_html__( 'Source Chronicle', 'owbn-archivist' ) . '</td><td><a href="' . esc_url( $chron_url ) . '" target="_blank" style="text-decoration:underline;">' . esc_html( $chron_lbl ) . ' &#x29C9;</a></td></tr>';
    }
    if ( ! empty( $d['source_hst'] ) ) {
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;">' . esc_html__( 'Source HST', 'owbn-archivist' ) . '</td><td>' . esc_html( $d['source_hst'] ) . '</td></tr>';
    }
    if ( ! empty( $d['archival_date'] ) ) {
        $h .= '<tr><td style="padding:3px 8px;font-weight:bold;">' . esc_html__( 'Archival Date', 'owbn-archivist' ) . '</td><td>' . esc_html( $d['archival_date'] ) . '</td></tr>';
    }
    $h .= '</table>';

    if ( ! empty( $d['discipline_requirements'] ) ) {
        $reqs = owc_cchub_normalize_discipline_requirements( $d['discipline_requirements'] );
        if ( ! empty( $reqs ) ) {
            $h .= '<h4>' . esc_html__( 'Discipline Requirements', 'owbn-archivist' ) . '</h4>';
            $h .= '<table style="width:100%;border-collapse:collapse;">';
            $h .= '<tr><th style="text-align:left;padding:3px 8px;border-bottom:1px solid #ddd;">' . esc_html__( 'Discipline', 'owbn-archivist' ) . '</th><th style="text-align:center;padding:3px 8px;border-bottom:1px solid #ddd;">' . esc_html__( 'Level', 'owbn-archivist' ) . '</th></tr>';
            foreach ( $reqs as $r ) {
                $h .= '<tr><td style="padding:3px 8px;">' . esc_html( $r['name'] ?? '' ) . '</td><td style="text-align:center;padding:3px 8px;">' . esc_html( $r['level'] ?? '' ) . '</td></tr>';
            }
            $h .= '</table>';
        }
    }

    if ( ! empty( $d['teachable_abilities'] ) ) {
        $ta = json_decode( $d['teachable_abilities'], true );
        if ( is_array( $ta ) && ! empty( $ta ) ) {
            $h .= '<p><strong>' . esc_html__( 'Teachable Abilities:', 'owbn-archivist' ) . '</strong> ' . esc_html( implode( ', ', $ta ) ) . '</p>';
        }
    }

    $nl2br_block = function ( $str ) {
        if ( $str === '' ) return '';
        if ( preg_match( '/<(p|div|br|ul|ol|h[1-6])\b/i', $str ) ) return $str;
        return nl2br( $str );
    };

    if ( ! empty( $d['met_rules'] ) ) {
        $h .= '<h4>' . esc_html__( 'MET Mechanics', 'owbn-archivist' ) . '</h4><div style="padding:8px;background:#f9f9f9;border:1px solid #eee;border-radius:4px;">' . wp_kses_post( $nl2br_block( $d['met_rules'] ) ) . '</div>';
    }
    if ( ! empty( $d['summary'] ) ) {
        $h .= '<h4>' . esc_html__( 'Summary', 'owbn-archivist' ) . '</h4><div style="padding:8px;background:#f9f9f9;border:1px solid #eee;border-radius:4px;">' . wp_kses_post( $nl2br_block( $d['summary'] ) ) . '</div>';
    }

    return $h;
}

/**
 * Run a snippet of HTML through TranslatePress for the given target locale.
 * No-op if TP is unavailable or target locale equals the default.
 *
 * @param string $html
 * @param string $target_locale e.g. 'pt_BR'.
 * @return string Possibly translated HTML.
 */
function owc_cchub_translate_html( $html, $target_locale ) {
    if ( ! class_exists( 'TRP_Translate_Press' ) || empty( $target_locale ) ) {
        return $html;
    }
    $trp      = TRP_Translate_Press::get_trp_instance();
    $settings = $trp->get_component( 'settings' )->get_settings();
    $default  = $settings['default-language'] ?? 'en_US';
    if ( $target_locale === $default ) {
        return $html;
    }
    $renderer = $trp->get_component( 'translation_render' );
    if ( ! is_object( $renderer ) || ! method_exists( $renderer, 'translate_page' ) ) {
        return $html;
    }
    global $TRP_LANGUAGE;
    $prev = $TRP_LANGUAGE;
    $TRP_LANGUAGE = $target_locale;
    try {
        $out = $renderer->translate_page( $html );
    } catch ( \Throwable $e ) {
        $out = $html;
    }
    $TRP_LANGUAGE = $prev;
    return $out;
}
