<?php

/**
 * OWBN-Client enqueue scripts
 * location: includes/admin/enqueue-scripts.php
 * @package OWBN-Client

 */

defined('ABSPATH') || exit;
