<?php
/**
 * OWBN Client Reports Page
 * location: includes/admin/reports.php
 *
 * Tab router for the Reports top-level menu.
 */

defined('ABSPATH') || exit;

function owc_get_reports_tabs() {
    $tabs = array(
        'chronicle-staff' => array(
            'label'   => __( 'Chronicle Staff', 'owbn-core' ),
            'icon'    => 'dashicons-groups',
            'partial' => __DIR__ . '/reports-tabs/tab-chronicle-staff.php',
        ),
        'conflicts' => array(
            'label'   => __( 'Conflicts', 'owbn-core' ),
            'icon'    => 'dashicons-warning',
            'partial' => __DIR__ . '/reports-tabs/tab-conflicts.php',
        ),
    );
    return apply_filters( 'owc_reports_tabs', $tabs );
}

function owc_render_reports_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'owbn-core' ) );
    }

    $client_id  = owc_get_client_id();
    $tabs       = owc_get_reports_tabs();
    $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'chronicle-staff';

    if ( ! isset( $tabs[ $active_tab ] ) ) {
        $active_tab = 'chronicle-staff';
    }

    $page_url = admin_url( 'admin.php?page=' . $client_id . '-owc-reports' );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'OWBN Reports', 'owbn-core' ); ?></h1>

        <div class="owc-settings-wrap">
            <ul class="owc-settings-tabs">
                <?php foreach ( $tabs as $slug => $tab ) :
                    $classes = array( 'owc-settings-tab' );
                    if ( $slug === $active_tab ) {
                        $classes[] = 'owc-settings-tab--active';
                    }
                ?>
                <li class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
                    <a href="<?php echo esc_url( add_query_arg( 'tab', $slug, $page_url ) ); ?>">
                        <span class="dashicons <?php echo esc_attr( $tab['icon'] ?? 'dashicons-admin-generic' ); ?>"></span>
                        <?php echo esc_html( $tab['label'] ); ?>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="owc-settings-content">
                <?php
                $tab_config = $tabs[ $active_tab ];
                if ( ! empty( $tab_config['partial'] ) && file_exists( $tab_config['partial'] ) ) {
                    include $tab_config['partial'];
                } else {
                    echo '<p>' . esc_html__( 'This report is not available.', 'owbn-core' ) . '</p>';
                }
                ?>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Write a chronicle's cm_info from an AccessSchema holder identified BY EMAIL.
 *
 * The report rows come from AccessSchema, whose `user_id` is the *SSO* user id,
 * NOT a local WP id. Storing that number as cm_info['user'] and then rendering
 * get_userdata() of it stamps whoever happens to hold that id locally — a wrong
 * person (the Aug-2026 "wrong CM" incident). So we resolve the holder by EMAIL,
 * store the LOCAL user id (or 0 when the CM has no local account), and take the
 * name/email from that resolution — never from a bare numeric id.
 *
 * @return array|WP_Error updated cm_info on success.
 */
function owc_cm_apply_cm_by_email( $post_id, $slug, $email, $fallback_name = '' ) {
    $email = sanitize_email( $email );
    if ( '' === $email ) {
        return new WP_Error( 'no_email', 'A CM email is required.' );
    }
    $wpu = get_user_by( 'email', $email ); // LOCAL user resolved by email (never an SSO id)

    $cm_info = get_post_meta( $post_id, 'cm_info', true );
    if ( ! is_array( $cm_info ) ) $cm_info = array();

    $cm_info['user']         = $wpu ? (int) $wpu->ID : 0; // local WP id or 0 — never a raw SSO id
    $cm_info['display_name'] = $wpu ? $wpu->display_name : ( '' !== $fallback_name ? $fallback_name : $email );
    $cm_info['actual_email'] = $email; // personal/external contact

    // display_email is locked to {slug}-cm@owbn.net (parent slug for satellites).
    $locked_email = function_exists( 'owbn_chronicle_cm_email' )
        ? owbn_chronicle_cm_email( $post_id )
        : '';
    if ( '' === $locked_email ) {
        $locked_email = $slug . '-cm@owbn.net';
    }
    $cm_info['display_email'] = $locked_email;

    update_post_meta( $post_id, 'cm_info', $cm_info );
    return $cm_info;
}

/**
 * AJAX: confirm a fuzzy CM match and write it back into the chronicle's
 * cm_info post meta. Also grants the ASC role so the two stay in sync.
 *
 * Resolves the CM BY EMAIL (the report row carries it). The legacy `user`
 * param — an SSO id — is intentionally ignored for storage.
 */
add_action( 'wp_ajax_owc_confirm_cm_match', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized.' );
    }
    $slug  = isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';
    $email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    $name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    check_ajax_referer( 'owc_confirm_cm_' . $slug, 'nonce' );

    if ( '' === $slug || '' === $email ) {
        wp_send_json_error( 'Missing parameters (slug and email required).' );
    }

    $posts = get_posts( array(
        'post_type'      => 'owbn_chronicle',
        'meta_key'       => 'chronicle_slug',
        'meta_value'     => $slug,
        'posts_per_page' => 1,
        'post_status'    => 'any',
    ) );
    if ( empty( $posts ) ) {
        wp_send_json_error( 'Chronicle not found.' );
    }
    $post_id = $posts[0]->ID;

    $cm_info = owc_cm_apply_cm_by_email( $post_id, $slug, $email, $name );
    if ( is_wp_error( $cm_info ) ) {
        wp_send_json_error( $cm_info->get_error_message() );
    }

    // Bust the report cache so a refresh shows the updated state.
    delete_transient( 'owc_cm_holders_map_v1' );

    // Grant the ASC role directly so ASC matches meta immediately.
    if ( function_exists( 'owc_asc_grant_role' ) ) {
        owc_asc_grant_role( 'ccs', $email, 'chronicle/' . $slug . '/cm' );
    }

    wp_send_json_success( array(
        'message' => sprintf( 'Confirmed: %s', $cm_info['display_name'] ),
    ) );
} );

/**
 * Decode a JSON-encoded `pairs` POST param into an array.
 *
 * Each pair must contain at minimum `slug` and `user`. Returns an empty array
 * on any decoding failure so callers can short-circuit cleanly.
 */
function owc_cm_decode_bulk_pairs() {
    if ( empty( $_POST['pairs'] ) ) return array();
    $raw = wp_unslash( $_POST['pairs'] );
    $arr = json_decode( $raw, true );
    if ( ! is_array( $arr ) ) return array();
    $out = array();
    foreach ( $arr as $row ) {
        if ( ! is_array( $row ) ) continue;
        $slug = isset( $row['slug'] ) ? sanitize_text_field( $row['slug'] ) : '';
        $uid  = isset( $row['user'] ) ? (int) $row['user'] : 0;
        if ( '' === $slug || $uid <= 0 ) continue;
        $out[] = array(
            'slug'  => $slug,
            'user'  => $uid,
            'email' => isset( $row['email'] ) ? sanitize_email( $row['email'] ) : '',
            'name'  => isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '',
            'role'  => isset( $row['role'] ) ? sanitize_text_field( $row['role'] ) : ( 'chronicle/' . $slug . '/cm' ),
        );
    }
    return $out;
}

/**
 * AJAX: bulk-confirm CM matches. Same effect as per-row Confirm-as-CM, run
 * for every selected (slug, user) pair.
 */
add_action( 'wp_ajax_owc_bulk_confirm_cm_match', function () {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized.' );
    check_ajax_referer( 'owc_cm_bulk', 'nonce' );

    $pairs = owc_cm_decode_bulk_pairs();
    if ( empty( $pairs ) ) wp_send_json_error( 'No pairs.' );

    $ok = 0; $fail = 0; $errors = array();
    foreach ( $pairs as $p ) {
        $posts = get_posts( array(
            'post_type'      => 'owbn_chronicle',
            'meta_key'       => 'chronicle_slug',
            'meta_value'     => $p['slug'],
            'posts_per_page' => 1,
            'post_status'    => 'any',
        ) );
        if ( empty( $posts ) ) { $fail++; $errors[] = $p['slug'] . ': not found'; continue; }
        $post_id = $posts[0]->ID;

        // Resolve BY EMAIL — never treat the row's numeric id (an SSO id) as a WP id.
        if ( empty( $p['email'] ) ) { $fail++; $errors[] = $p['slug'] . ': no email'; continue; }
        $cm_info = owc_cm_apply_cm_by_email( $post_id, $p['slug'], $p['email'], $p['name'] ?? '' );
        if ( is_wp_error( $cm_info ) ) { $fail++; $errors[] = $p['slug'] . ': ' . $cm_info->get_error_message(); continue; }

        if ( function_exists( 'owc_asc_grant_role' ) ) {
            owc_asc_grant_role( 'ccs', $p['email'], 'chronicle/' . $p['slug'] . '/cm' );
        }
        $ok++;
    }

    delete_transient( 'owc_cm_holders_map_v1' );

    wp_send_json_success( array(
        'message' => sprintf( __( '%1$d confirmed, %2$d failed', 'owbn-core' ), $ok, $fail ),
        'errors'  => $errors,
    ) );
} );

/**
 * AJAX: bulk-revoke chronicle/{slug}/cm tags from AccessSchema for selected
 * (slug, user_email) pairs. Local cm_info is untouched — this is for cleaning
 * up orphan ASC tags. Pre-revoke check: refuses to revoke a tag where local
 * cm_info still names this user (caller should adjust local cm_info first).
 */
add_action( 'wp_ajax_owc_bulk_revoke_cm_role', function () {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized.' );
    check_ajax_referer( 'owc_cm_bulk', 'nonce' );

    if ( ! function_exists( 'owc_asc_revoke_role' ) ) {
        wp_send_json_error( 'AccessSchema client unavailable.' );
    }

    $pairs = owc_cm_decode_bulk_pairs();
    if ( empty( $pairs ) ) wp_send_json_error( 'No pairs.' );

    $ok = 0; $fail = 0; $errors = array();
    foreach ( $pairs as $p ) {
        // Use the row's email directly — the numeric id is an SSO id, so resolving
        // it as a local WP user would target the wrong person's address.
        $email = ! empty( $p['email'] ) ? sanitize_email( $p['email'] ) : '';
        if ( empty( $email ) ) { $fail++; $errors[] = $p['slug'] . ': no email'; continue; }

        // Refuse if local cm_info still names this holder (compare BY EMAIL, not id).
        $posts = get_posts( array(
            'post_type'      => 'owbn_chronicle',
            'meta_key'       => 'chronicle_slug',
            'meta_value'     => $p['slug'],
            'posts_per_page' => 1,
            'post_status'    => 'any',
        ) );
        if ( ! empty( $posts ) ) {
            $local = get_post_meta( $posts[0]->ID, 'cm_info', true );
            if ( is_array( $local ) && strtolower( $local['actual_email'] ?? '' ) === strtolower( $email ) ) {
                $fail++; $errors[] = $p['slug'] . ': local CM still names this user';
                continue;
            }
        }

        $role = $p['role'] ?: ( 'chronicle/' . $p['slug'] . '/cm' );
        $result = owc_asc_revoke_role( 'ccs', $email, $role );
        if ( is_wp_error( $result ) ) {
            $fail++; $errors[] = $p['slug'] . ': ' . $result->get_error_message();
        } else {
            $ok++;
        }
    }

    delete_transient( 'owc_cm_holders_map_v1' );

    wp_send_json_success( array(
        'message' => sprintf( __( '%1$d revoked, %2$d failed', 'owbn-core' ), $ok, $fail ),
        'errors'  => $errors,
    ) );
} );

/**
 * AJAX: dismiss (slug, user_id) pairs so they no longer surface as red.
 * Stored in the option `owc_cm_match_ignored` keyed by "slug:uid" with a
 * timestamp. Auto-clears when the underlying status flips to green via the
 * normal save/grant flow.
 */
add_action( 'wp_ajax_owc_bulk_ignore_cm_match', function () {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized.' );
    check_ajax_referer( 'owc_cm_bulk', 'nonce' );

    $pairs = owc_cm_decode_bulk_pairs();
    if ( empty( $pairs ) ) wp_send_json_error( 'No pairs.' );

    $ignored = get_option( 'owc_cm_match_ignored', array() );
    if ( ! is_array( $ignored ) ) $ignored = array();

    $now = time();
    $ok = 0;
    foreach ( $pairs as $p ) {
        $ignored[ $p['slug'] . ':' . $p['user'] ] = $now;
        $ok++;
    }
    update_option( 'owc_cm_match_ignored', $ignored, false );

    wp_send_json_success( array(
        'message' => sprintf( __( '%d dismissed', 'owbn-core' ), $ok ),
    ) );
} );

/**
 * Decode the `keys` POST param (JSON array) for conflict-report dismissals.
 *
 * A conflict "key" is the person key the conflicts tab builds:
 *   "u:<id>" | "e:<email>" | "n:<name>". These are only ever used as array
 * keys for display suppression — never in a query or as executable output —
 * but we still validate the shape and drop anything that doesn't match.
 */
function owc_conflict_decode_keys() {
    if ( empty( $_POST['keys'] ) ) {
        return array();
    }
    $arr = json_decode( wp_unslash( $_POST['keys'] ), true );
    if ( ! is_array( $arr ) ) {
        return array();
    }
    $out = array();
    foreach ( $arr as $k ) {
        $k = sanitize_text_field( (string) $k );
        if ( preg_match( '/^(u:\d+|e:.+|n:.+)$/', $k ) ) {
            $out[] = $k;
        }
    }
    return array_values( array_unique( $out ) );
}

/**
 * AJAX: acknowledge (dismiss) selected staffing conflicts so they drop out of
 * the active list. DISPLAY-ONLY — writes the per-site option `owc_conflict_ack`
 * (key => timestamp); no ASC roles or chronicle meta are touched. Reversible
 * via owc_bulk_unack_conflict.
 */
add_action( 'wp_ajax_owc_bulk_ack_conflict', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized.' );
    }
    check_ajax_referer( 'owc_conflict_bulk', 'nonce' );

    $keys = owc_conflict_decode_keys();
    if ( empty( $keys ) ) {
        wp_send_json_error( 'No conflicts selected.' );
    }

    $ack = get_option( 'owc_conflict_ack', array() );
    if ( ! is_array( $ack ) ) {
        $ack = array();
    }
    $now = time();
    $n   = 0;
    foreach ( $keys as $k ) {
        $ack[ $k ] = $now;
        $n++;
    }
    update_option( 'owc_conflict_ack', $ack, false );

    wp_send_json_success( array(
        'message' => sprintf( __( '%d acknowledged', 'owbn-core' ), $n ),
    ) );
} );

/**
 * AJAX: restore (un-acknowledge) selected conflicts back into the active list.
 */
add_action( 'wp_ajax_owc_bulk_unack_conflict', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized.' );
    }
    check_ajax_referer( 'owc_conflict_bulk', 'nonce' );

    $keys = owc_conflict_decode_keys();
    if ( empty( $keys ) ) {
        wp_send_json_error( 'No conflicts selected.' );
    }

    $ack = get_option( 'owc_conflict_ack', array() );
    if ( ! is_array( $ack ) ) {
        $ack = array();
    }
    $n = 0;
    foreach ( $keys as $k ) {
        if ( isset( $ack[ $k ] ) ) {
            unset( $ack[ $k ] );
            $n++;
        }
    }
    update_option( 'owc_conflict_ack', $ack, false );

    wp_send_json_success( array(
        'message' => sprintf( __( '%d restored', 'owbn-core' ), $n ),
    ) );
} );
