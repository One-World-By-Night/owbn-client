<?php

/**
 * OWBN-Client Coordinators Dashboard
 *
 * Shows data source, cache status, record count, and gateway registration
 * for the Coordinators data type. Provides cache clear/refresh actions.
 *
 */

defined('ABSPATH') || exit;

function owc_render_coordinators_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    // ── Cache actions ──────────────────────────────────────────────────────────
    if (isset($_POST['owc_clear_coordinators_cache']) && check_admin_referer('owc_coordinators_cache_action')) {
        delete_transient('owc_coordinators_cache');
        add_settings_error('owc_coordinators', 'cache_cleared', __('Coordinators cache cleared.', 'owbn-core'), 'success');
    }

    if (isset($_POST['owc_refresh_coordinators_cache']) && check_admin_referer('owc_coordinators_cache_action')) {
        delete_transient('owc_coordinators_cache');
        $result = owc_get_coordinators(true);
        if (is_wp_error($result)) {
            add_settings_error('owc_coordinators', 'refresh_failed', $result->get_error_message(), 'error');
        } else {
            add_settings_error('owc_coordinators', 'cache_refreshed', __('Coordinators cache refreshed.', 'owbn-core'), 'success');
        }
    }

    // ── Status data ────────────────────────────────────────────────────────────
    $is_local    = owc_manager_active() && owc_coordinators_enabled();
    $remote_base = owc_get_remote_base();
    $cache       = get_transient('owc_coordinators_cache');
    $cache_ttl   = owc_get_cache_ttl();

    $gw_enabled = (bool) get_option('owbn_gateway_enabled', false);
    $gw_sources = apply_filters('owbn_gateway_data_sources', []);
    $gw_has_type = false;
    foreach ($gw_sources as $source) {
        if (isset($source['types']) && in_array('coordinator', $source['types'], true)) {
            $gw_has_type = true;
            break;
        }
    }

    if ($is_local) {
        $source_label = __('Local (Chronicle Manager active)', 'owbn-core');
    } elseif ($remote_base) {
        $source_label = sprintf(__('Remote: %s', 'owbn-core'), rtrim($remote_base, '/'));
    } else {
        $source_label = __('Not configured', 'owbn-core');
    }

    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Coordinators', 'owbn-core'); ?></h1>

        <?php settings_errors('owc_coordinators'); ?>

        <table class="widefat striped" style="max-width:640px; margin-top:16px;">
            <tbody>
                <tr>
                    <th style="width:180px;"><?php esc_html_e('Data Source', 'owbn-core'); ?></th>
                    <td><?php echo esc_html($source_label); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Records', 'owbn-core'); ?></th>
                    <td><?php
                        if (is_array($cache)) {
                            echo absint(count($cache)) . ' ' . esc_html__('coordinators cached', 'owbn-core');
                        } else {
                            esc_html_e('No cached data', 'owbn-core');
                        }
                    ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Cache TTL', 'owbn-core'); ?></th>
                    <td><?php echo absint($cache_ttl); ?> <?php esc_html_e('seconds', 'owbn-core'); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Gateway', 'owbn-core'); ?></th>
                    <td><?php
                        if ($gw_enabled && $gw_has_type) {
                            echo '<span style="color:#4CAF50; font-weight:600;">&#10003; ' . esc_html__('Registered', 'owbn-core') . '</span>';
                        } elseif ($gw_enabled) {
                            esc_html_e('Enabled — no coordinator source registered', 'owbn-core');
                        } else {
                            esc_html_e('Gateway disabled', 'owbn-core');
                        }
                    ?></td>
                </tr>
            </tbody>
        </table>

        <h2 style="margin-top:24px;"><?php esc_html_e('Cache Actions', 'owbn-core'); ?></h2>
        <form method="post" style="display:inline-block; margin-right:8px;">
            <?php wp_nonce_field('owc_coordinators_cache_action'); ?>
            <?php submit_button(__('Clear Cache', 'owbn-core'), 'secondary', 'owc_clear_coordinators_cache', false); ?>
        </form>
        <form method="post" style="display:inline-block;">
            <?php wp_nonce_field('owc_coordinators_cache_action'); ?>
            <?php submit_button(__('Refresh Cache', 'owbn-core'), 'secondary', 'owc_refresh_coordinators_cache', false); ?>
        </form>
    </div>
    <?php
}
